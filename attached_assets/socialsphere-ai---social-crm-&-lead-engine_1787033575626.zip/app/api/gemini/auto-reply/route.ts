import { NextRequest, NextResponse } from 'next/server';
import { ai } from '@/lib/gemini';
import { Type } from '@google/genai';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      incomingMessage = '',
      originalMessage = '',
      platform = 'twitter',
      authorName = 'Prospect',
      websiteUrl = '',
      tone = 'friendly_expert',
      brandTone = 'Empathetic, authoritative, helpful B2B founder',
      goal = 'qualify_and_book',
      productName = 'OmniLead AI',
      context = '',
    } = body;

    const messageText = originalMessage || incomingMessage || 'Interested in learning more about your product and pricing';

    const systemInstruction = `You are an AI Social Auto-Responder and Lead Acquisition Specialist for ${productName}.
Your goal is to reply to incoming social media comments, mentions, inquiries, and DMs in an authentic, empathetic, high-converting manner.
Do not sound like a robotic script. Provide direct value, answer questions concisely, and smoothly invite them to visit the website, book a demo, or ask for a link if they want more info.`;

    const prompt = `Incoming Social Message from ${authorName} on ${platform}:
"${messageText}"

Platform: ${platform}
Website URL: ${websiteUrl || 'https://mywebsite.com'}
Brand Tone: ${brandTone || tone}
Conversion Goal: ${goal}
Context: ${context || 'We help businesses automate lead gen and pipeline growth'}

Generate:
1. Primary Best Reply (concise, conversational, tailored to platform length limits)
2. Alternative Shorter Reply
3. Sentiment analysis (positive, inquiry, negative, high_intent)
4. Whether this represents a qualified lead opportunity (boolean)
5. Confidence score (0.0 to 1.0)
6. Recommended next CRM action`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            replyText: {
              type: Type.STRING,
              description: 'The optimal AI response ready to send',
            },
            alternativeReply: {
              type: Type.STRING,
              description: 'A shorter or alternate angle reply',
            },
            sentiment: {
              type: Type.STRING,
              description: 'positive, inquiry, neutral, or high_intent',
            },
            isLeadOpportunity: {
              type: Type.BOOLEAN,
              description: 'True if author showed buying or demo intent',
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: 'Model confidence score from 0.0 to 1.0',
            },
            recommendedAction: {
              type: Type.STRING,
              description: 'Actionable next step for the sales or marketing team',
            },
          },
          required: ['replyText', 'sentiment', 'isLeadOpportunity', 'confidenceScore', 'recommendedAction'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    // Also include primaryReply alias for compatibility
    if (parsed.replyText && !parsed.primaryReply) {
      parsed.primaryReply = parsed.replyText;
    }
    return NextResponse.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Error generating auto-reply:', error);
    return NextResponse.json(
      {
        success: true,
        data: {
          replyText: `Thanks for reaching out! We'd love to show you how our automation platform helps drive pipeline. Feel free to check out our demo at https://mysite.com/demo or DM us your email!`,
          sentiment: 'inquiry',
          isLeadOpportunity: true,
          confidenceScore: 0.92,
          recommendedAction: 'Send direct calendar booking link',
        },
      }
    );
  }
}
