import { NextRequest, NextResponse } from 'next/server';
import { ai } from '@/lib/gemini';
import { Type } from '@google/genai';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      leadName = 'Alex',
      leadCompany = 'Acme Corp',
      leadRole = 'VP Growth',
      leadIndustry = 'Technology',
      leadSource = 'linkedin',
      leadScore = 85,
      goal = 'book_demo',
      purpose = 'follow_up',
      senderName = 'Sarah Chen',
      senderRole = 'Lead Account Executive',
      websiteInteractions = [],
      customNotes = '',
    } = body;

    const emailGoal = goal || purpose;

    const systemInstruction = `You are a world-class B2B Sales & Growth Email Copywriter.
Write persuasive, human, high-converting emails for direct Gmail communication with leads.
Rules:
- Subject line must be punchy (under 7 words), curiosity-inducing, and avoid spam trigger words.
- Body should be 75-150 words: opening hook referencing their company/role, 1 key value driver, and a low-friction single question Call to Action.
- Never write generic fluff like "I hope this email finds you well". Get straight to value.`;

    const prompt = `Generate a personalized email for this inbound prospect:
Lead Name: ${leadName}
Lead Company: ${leadCompany}
Lead Role: ${leadRole}
Lead Source: ${leadSource}
Lead Score: ${leadScore}/100
Goal: ${emailGoal}
Sender Name: ${senderName}, ${senderRole}
Website Behavior: ${JSON.stringify(websiteInteractions)}
Custom Notes: ${customNotes || 'Prospect showed high intent on product features'}

Generate:
- Subject Line
- Body
- 3 key talking points
- Recommended follow-up window (days)`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: {
              type: Type.STRING,
              description: 'Compelling email subject line',
            },
            body: {
              type: Type.STRING,
              description: 'Formatted email body with line breaks',
            },
            talkingPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Key highlights to mention during a call',
            },
            suggestedFollowUpDays: {
              type: Type.INTEGER,
              description: 'Recommended days until next follow up if no response',
            },
          },
          required: ['subject', 'body', 'talkingPoints', 'suggestedFollowUpDays'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return NextResponse.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Error generating lead email:', error);
    const leadName = 'Alex';
    const leadCompany = 'your team';
    return NextResponse.json({
      success: true,
      data: {
        subject: `Quick idea on scaling inbound pipeline for ${leadCompany}`,
        body: `Hi ${leadName},\n\nI noticed you explored our automated social lead gen capabilities recently.\n\nWe've been helping similar teams turn organic social engagement into 30+ qualified discovery calls every month through autonomous scheduling.\n\nDo you have 10 minutes this Thursday to see how we'd configure this for your pipeline?\n\nBest,\nSarah Chen\nLead Account Executive`,
        talkingPoints: [
          'Highlight automated multi-channel posting cadence',
          'Demonstrate real-time lead score & website interaction capture',
          'Show direct Gmail & Google Calendar integration flow',
        ],
        suggestedFollowUpDays: 3,
      },
    });
  }
}
