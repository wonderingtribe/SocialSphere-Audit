'use client';

import React, { useState } from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import { Navbar } from '@/components/Navbar';
import { BottomNav } from '@/components/BottomNav';
import { DashboardView } from '@/components/DashboardView';
import { CampaignsView } from '@/components/CampaignsView';
import { LeadsView } from '@/components/LeadsView';
import { CommunicationsView } from '@/components/CommunicationsView';
import { CalendarView } from '@/components/CalendarView';
import { TeamView } from '@/components/TeamView';
import { IntegrationsView } from '@/components/IntegrationsView';
import { NewPostModal } from '@/components/NewPostModal';
import { NewCampaignModal } from '@/components/NewCampaignModal';
import { AutoReplyModal } from '@/components/AutoReplyModal';
import { ScheduleModal } from '@/components/ScheduleModal';
import { EmailModal } from '@/components/EmailModal';
import { ApkModal } from '@/components/ApkModal';
import {
  Smartphone,
  Wifi,
  Battery,
  Signal,
  Sparkles,
  Zap,
} from 'lucide-react';

function AppContent() {
  const {
    activeTab,
    viewMode,
    selectedLeadId,
    setSelectedLeadId,
  } = useApp();

  // Modal visibility states
  const [isNewPostOpen, setIsNewPostOpen] = useState(false);
  const [isNewCampaignOpen, setIsNewCampaignOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [autoReplyState, setAutoReplyState] = useState<{
    isOpen: boolean;
    author: string;
    platform: string;
    message: string;
  }>({
    isOpen: false,
    author: 'Victoria Howard',
    platform: 'linkedin',
    message: '',
  });

  const [modalLeadTarget, setModalLeadTarget] = useState<string | null>(null);

  const handleOpenAutoReply = (author: string, platform: string, message: string) => {
    setAutoReplyState({
      isOpen: true,
      author,
      platform,
      message,
    });
  };

  const handleOpenEmail = (leadId?: string) => {
    setModalLeadTarget(leadId || null);
    setIsEmailModalOpen(true);
  };

  const handleOpenSchedule = (leadId?: string) => {
    setModalLeadTarget(leadId || null);
    setIsScheduleModalOpen(true);
  };

  const renderActiveTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            onOpenNewPost={() => setIsNewPostOpen(true)}
            onOpenNewCampaign={() => setIsNewCampaignOpen(true)}
            onOpenAutoReply={handleOpenAutoReply}
            onSelectLead={(id) => setSelectedLeadId(id)}
          />
        );
      case 'campaigns':
        return (
          <CampaignsView
            onOpenNewPost={() => setIsNewPostOpen(true)}
            onOpenNewCampaign={() => setIsNewCampaignOpen(true)}
          />
        );
      case 'leads':
        return (
          <LeadsView
            onOpenEmailModal={handleOpenEmail}
            onOpenScheduleModal={handleOpenSchedule}
            selectedLeadId={selectedLeadId}
            onSelectLead={(id) => setSelectedLeadId(id)}
          />
        );
      case 'messages':
        return (
          <CommunicationsView
            initialLeadId={modalLeadTarget}
            onOpenEmailModal={handleOpenEmail}
          />
        );
      case 'calendar':
        return <CalendarView onOpenScheduleModal={handleOpenSchedule} />;
      case 'team':
        return <TeamView />;
      case 'integrations':
        return <IntegrationsView />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0D11] text-slate-300 font-sans flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Top Main Navigation */}
      <Navbar
        onOpenNewPost={() => setIsNewPostOpen(true)}
        onOpenNewCampaign={() => setIsNewCampaignOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
      />

      {/* Main Content Area: Responsive Desktop vs APK Mobile Shell */}
      {viewMode === 'mobile_apk' ? (
        /* Mobile Device Frame Simulation */
        <main className="flex-1 flex items-center justify-center p-2 sm:p-6 bg-[#0B0D11] overflow-x-hidden">
          <div className="relative w-full max-w-[420px] h-[850px] bg-[#12151C] border-[8px] border-slate-800 rounded-[40px] shadow-[0_0_60px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden ring-1 ring-slate-800">
            {/* Phone Speaker & Dynamic Island */}
            <div className="absolute top-0 left-0 right-0 h-8 bg-[#12151C] z-50 flex items-center justify-between px-6 text-slate-400 text-[10px] font-semibold">
              <span>9:41</span>
              <div className="h-4 w-28 bg-[#0B0D11] rounded-full flex items-center justify-center">
                <div className="h-2 w-2 rounded-full bg-slate-800" />
              </div>
              <div className="flex items-center gap-1.5">
                <Signal className="h-3 w-3" />
                <Wifi className="h-3 w-3" />
                <Battery className="h-3.5 w-3.5" />
              </div>
            </div>

            {/* Scrollable Mobile Screen Content */}
            <div className="flex-1 overflow-y-auto pt-8 pb-18 px-3 custom-scrollbar bg-[#0B0D11]">
              {renderActiveTabContent()}
            </div>

            {/* Mobile Bottom Docked Navigation */}
            <BottomNav />

            {/* Bottom Home Indicator */}
            <div className="absolute bottom-1 left-0 right-0 flex justify-center pointer-events-none z-50">
              <div className="w-32 h-1 bg-slate-700 rounded-full" />
            </div>
          </div>
        </main>
      ) : (
        /* Full-Width Desktop Workspace */
        <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-5 pb-20 lg:pb-10">
          {renderActiveTabContent()}
          <BottomNav />
        </main>
      )}

      {/* Interactive Floating Modals */}
      <NewPostModal isOpen={isNewPostOpen} onClose={() => setIsNewPostOpen(false)} />
      <NewCampaignModal isOpen={isNewCampaignOpen} onClose={() => setIsNewCampaignOpen(false)} />
      <AutoReplyModal
        isOpen={autoReplyState.isOpen}
        onClose={() => setAutoReplyState({ ...autoReplyState, isOpen: false })}
        initialAuthor={autoReplyState.author}
        initialPlatform={autoReplyState.platform}
        initialMessage={autoReplyState.message}
      />
      <ScheduleModal
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        initialLeadId={modalLeadTarget}
      />
      <EmailModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        initialLeadId={modalLeadTarget}
      />
      <ApkModal isOpen={isApkModalOpen} onClose={() => setIsApkModalOpen(false)} />
    </div>
  );
}

export default function Page() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
