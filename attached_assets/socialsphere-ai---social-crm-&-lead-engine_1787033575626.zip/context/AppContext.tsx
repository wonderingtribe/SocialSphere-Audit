'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Lead,
  SocialPost,
  Campaign,
  EmailMessage,
  CalendarFollowUp,
  TeamMember,
  SocialAccountConnection,
  PerformanceDayMetric,
  LiveActivityFeedItem,
  LeadStatus,
  SocialPlatform,
} from '@/types';
import {
  INITIAL_LEADS,
  INITIAL_POSTS,
  INITIAL_CAMPAIGNS,
  INITIAL_EMAILS,
  INITIAL_FOLLOW_UPS,
  INITIAL_TEAM_MEMBERS,
  INITIAL_SOCIAL_ACCOUNTS,
  INITIAL_METRICS_HISTORY,
  INITIAL_ACTIVITY_FEED,
} from '@/lib/storage';
import confetti from 'canvas-confetti';

interface AppContextType {
  leads: Lead[];
  posts: SocialPost[];
  campaigns: Campaign[];
  emails: EmailMessage[];
  followUps: CalendarFollowUp[];
  teamMembers: TeamMember[];
  socialAccounts: SocialAccountConnection[];
  metricsHistory: PerformanceDayMetric[];
  activityFeed: LiveActivityFeedItem[];
  activeTab: 'dashboard' | 'campaigns' | 'leads' | 'messages' | 'calendar' | 'team' | 'integrations';
  setActiveTab: (tab: 'dashboard' | 'campaigns' | 'leads' | 'messages' | 'calendar' | 'team' | 'integrations') => void;
  viewMode: 'desktop' | 'mobile_apk';
  setViewMode: (mode: 'desktop' | 'mobile_apk') => void;
  isLiveSimulating: boolean;
  setIsLiveSimulating: (sim: boolean) => void;
  selectedLeadId: string | null;
  setSelectedLeadId: (id: string | null) => void;
  
  // Actions
  addLead: (lead: Omit<Lead, 'id' | 'createdAt' | 'notes' | 'websiteInteractions'>) => Lead;
  updateLeadStatus: (leadId: string, status: LeadStatus) => void;
  assignLead: (leadId: string, memberId: string) => void;
  addLeadNote: (leadId: string, content: string, authorId?: string) => void;
  deleteLead: (leadId: string) => void;
  
  addPost: (post: Omit<SocialPost, 'id' | 'createdAt' | 'engagement'>) => SocialPost;
  updatePost: (id: string, updates: Partial<SocialPost>) => void;
  deletePost: (id: string) => void;
  publishPostNow: (id: string) => void;
  togglePostAutopilot: (id: string) => void;
  
  addCampaign: (campaign: Omit<Campaign, 'id' | 'createdAt' | 'metrics'>, initialPosts?: Omit<SocialPost, 'id' | 'createdAt' | 'engagement'>[]) => Campaign;
  updateCampaignStatus: (id: string, status: Campaign['status']) => void;
  deleteCampaign: (id: string) => void;

  sendEmail: (leadId: string, subject: string, body: string, senderEmail?: string) => EmailMessage;
  markEmailRead: (emailId: string) => void;
  
  addFollowUp: (followUp: Omit<CalendarFollowUp, 'id'>) => CalendarFollowUp;
  updateFollowUpStatus: (id: string, status: CalendarFollowUp['status']) => void;
  deleteFollowUp: (id: string) => void;
  
  toggleAccountConnection: (platform: SocialPlatform) => void;
  updateSocialAccount: (platform: SocialPlatform, updates: Partial<SocialAccountConnection>) => void;
  
  triggerCelebration: () => void;
  resetToDefaultData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LEADS: 'omnilead_leads_v1',
  POSTS: 'omnilead_posts_v1',
  CAMPAIGNS: 'omnilead_campaigns_v1',
  EMAILS: 'omnilead_emails_v1',
  FOLLOW_UPS: 'omnilead_followups_v1',
  TEAM: 'omnilead_team_v1',
  ACCOUNTS: 'omnilead_accounts_v1',
  METRICS: 'omnilead_metrics_v1',
  FEED: 'omnilead_feed_v1',
  VIEW_MODE: 'omnilead_viewmode_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [leads, setLeads] = useState<Lead[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.LEADS);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_LEADS;
  });

  const [posts, setPosts] = useState<SocialPost[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.POSTS);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_POSTS;
  });

  const [campaigns, setCampaigns] = useState<Campaign[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.CAMPAIGNS);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_CAMPAIGNS;
  });

  const [emails, setEmails] = useState<EmailMessage[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.EMAILS);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_EMAILS;
  });

  const [followUps, setFollowUps] = useState<CalendarFollowUp[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.FOLLOW_UPS);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_FOLLOW_UPS;
  });

  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.TEAM);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_TEAM_MEMBERS;
  });

  const [socialAccounts, setSocialAccounts] = useState<SocialAccountConnection[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return INITIAL_SOCIAL_ACCOUNTS;
  });

  const [metricsHistory, setMetricsHistory] = useState<PerformanceDayMetric[]>(INITIAL_METRICS_HISTORY);
  const [activityFeed, setActivityFeed] = useState<LiveActivityFeedItem[]>(INITIAL_ACTIVITY_FEED);
  
  const [activeTab, setActiveTab] = useState<'dashboard' | 'campaigns' | 'leads' | 'messages' | 'calendar' | 'team' | 'integrations'>('dashboard');
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile_apk'>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEYS.VIEW_MODE);
        if (saved === 'desktop' || saved === 'mobile_apk') return saved;
      } catch (e) {
        console.warn('Storage read error:', e);
      }
    }
    return 'desktop';
  });
  const [isLiveSimulating, setIsLiveSimulating] = useState<boolean>(true);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(true);

  // Save to LocalStorage
  useEffect(() => {
    if (!isLoaded) return;
    try {
      localStorage.setItem(STORAGE_KEYS.LEADS, JSON.stringify(leads));
      localStorage.setItem(STORAGE_KEYS.POSTS, JSON.stringify(posts));
      localStorage.setItem(STORAGE_KEYS.CAMPAIGNS, JSON.stringify(campaigns));
      localStorage.setItem(STORAGE_KEYS.EMAILS, JSON.stringify(emails));
      localStorage.setItem(STORAGE_KEYS.FOLLOW_UPS, JSON.stringify(followUps));
      localStorage.setItem(STORAGE_KEYS.TEAM, JSON.stringify(teamMembers));
      localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(socialAccounts));
      localStorage.setItem(STORAGE_KEYS.VIEW_MODE, viewMode);
    } catch (e) {
      console.warn('Storage write error:', e);
    }
  }, [leads, posts, campaigns, emails, followUps, teamMembers, socialAccounts, viewMode, isLoaded]);

  // Real-time live simulation engine (produces occasional organic engagement and lead touches)
  useEffect(() => {
    if (!isLiveSimulating) return;

    const interval = setInterval(() => {
      // 30% chance every 25 seconds to generate a simulated live interaction
      const rand = Math.random();
      if (rand < 0.4) {
        const platforms: SocialPlatform[] = ['twitter', 'linkedin', 'instagram', 'tiktok'];
        const randomPlatform = platforms[Math.floor(Math.random() * platforms.length)];
        const simulatedCompanies = ['CloudMatrix AI', 'ApexVelocity', 'Lumina Health', 'Quantum Scale', 'Beacon Media'];
        const randomCompany = simulatedCompanies[Math.floor(Math.random() * simulatedCompanies.length)];
        
        const newFeedItem: LiveActivityFeedItem = {
          id: `act-${Date.now()}`,
          type: 'high_engagement',
          title: `Viral Spike on ${randomPlatform.toUpperCase()}`,
          description: `Post gained +120 impressions and 14 new profile clicks from ${randomCompany}.`,
          timestamp: 'Just now',
          platform: randomPlatform,
        };

        setActivityFeed((prev) => [newFeedItem, ...prev.slice(0, 19)]);
        
        // Boost metrics slightly
        setPosts((prevPosts) => {
          return prevPosts.map((p) => {
            if (p.status === 'published' && p.platform === randomPlatform) {
              return {
                ...p,
                engagement: {
                  ...p.engagement,
                  impressions: p.engagement.impressions + Math.floor(Math.random() * 80) + 20,
                  clicks: p.engagement.clicks + Math.floor(Math.random() * 8) + 1,
                  likes: p.engagement.likes + Math.floor(Math.random() * 5) + 1,
                },
              };
            }
            return p;
          });
        });
      }
    }, 25000);

    return () => clearInterval(interval);
  }, [isLiveSimulating]);

  const triggerCelebration = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#3b82f6', '#10b981', '#6366f1', '#f59e0b'],
      });
    } catch (e) {
      console.log('Confetti triggered');
    }
  };

  // Lead actions
  const addLead = (leadData: Omit<Lead, 'id' | 'createdAt' | 'notes' | 'websiteInteractions'>): Lead => {
    const newLead: Lead = {
      ...leadData,
      id: `lead-${Date.now()}`,
      createdAt: new Date().toISOString(),
      notes: [],
      websiteInteractions: [
        { page: '/direct-inbound', timeSpentSeconds: 95, visitedAt: new Date().toISOString() },
      ],
    };

    setLeads((prev) => [newLead, ...prev]);

    // Add activity feed item
    const feedItem: LiveActivityFeedItem = {
      id: `act-${Date.now()}`,
      type: 'lead_captured',
      title: 'New Lead Generated',
      description: `${newLead.name} (${newLead.role}, ${newLead.company}) captured from ${newLead.sourcePlatform}.`,
      timestamp: 'Just now',
      platform: newLead.sourcePlatform as SocialPlatform,
      leadId: newLead.id,
      avatar: newLead.avatar,
      value: newLead.estimatedValue,
    };
    setActivityFeed((prev) => [feedItem, ...prev]);

    return newLead;
  };

  const updateLeadStatus = (leadId: string, status: LeadStatus) => {
    setLeads((prev) =>
      prev.map((lead) => {
        if (lead.id === leadId) {
          if (status === 'won' && lead.status !== 'won') {
            triggerCelebration();
            const feedItem: LiveActivityFeedItem = {
              id: `act-${Date.now()}`,
              type: 'deal_won',
              title: 'Deal Won! 🚀',
              description: `${lead.name} (${lead.company}) closed for $${lead.estimatedValue.toLocaleString()}.`,
              timestamp: 'Just now',
              leadId: lead.id,
              avatar: lead.avatar,
              value: lead.estimatedValue,
            };
            setActivityFeed((f) => [feedItem, ...f]);
          }
          return { ...lead, status, updatedAt: new Date().toISOString() };
        }
        return lead;
      })
    );
  };

  const assignLead = (leadId: string, memberId: string) => {
    const member = teamMembers.find((m) => m.id === memberId);
    if (!member) return;

    setLeads((prev) =>
      prev.map((lead) => {
        if (lead.id === leadId) {
          return { ...lead, assignedTo: member.id, assignedToName: member.name };
        }
        return lead;
      })
    );
  };

  const addLeadNote = (leadId: string, content: string, authorId: string = 'team-1') => {
    const author = teamMembers.find((m) => m.id === authorId) || teamMembers[0];
    const newNote = {
      id: `note-${Date.now()}`,
      authorId: author.id,
      authorName: author.name,
      authorAvatar: author.avatar,
      content,
      createdAt: new Date().toISOString(),
    };

    setLeads((prev) =>
      prev.map((lead) => {
        if (lead.id === leadId) {
          return { ...lead, notes: [newNote, ...lead.notes] };
        }
        return lead;
      })
    );
  };

  const deleteLead = (leadId: string) => {
    setLeads((prev) => prev.filter((l) => l.id !== leadId));
    if (selectedLeadId === leadId) setSelectedLeadId(null);
  };

  // Post Actions
  const addPost = (postData: Omit<SocialPost, 'id' | 'createdAt' | 'engagement'>): SocialPost => {
    const newPost: SocialPost = {
      ...postData,
      id: `post-${Date.now()}`,
      createdAt: new Date().toISOString(),
      engagement: {
        impressions: 0,
        likes: 0,
        reposts: 0,
        comments: 0,
        clicks: 0,
        leadsGenerated: 0,
      },
    };

    setPosts((prev) => [newPost, ...prev]);
    return newPost;
  };

  const updatePost = (id: string, updates: Partial<SocialPost>) => {
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
  };

  const deletePost = (id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  const publishPostNow = (id: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const published: SocialPost = {
            ...p,
            status: 'published',
            publishedAt: new Date().toISOString(),
            engagement: {
              impressions: Math.floor(Math.random() * 450) + 120,
              likes: Math.floor(Math.random() * 25) + 4,
              reposts: Math.floor(Math.random() * 8) + 1,
              comments: Math.floor(Math.random() * 6) + 1,
              clicks: Math.floor(Math.random() * 32) + 5,
              leadsGenerated: Math.floor(Math.random() * 2),
            },
          };

          const feedItem: LiveActivityFeedItem = {
            id: `act-${Date.now()}`,
            type: 'post_published',
            title: `Post Published to ${p.platform.toUpperCase()}`,
            description: `"${p.content.slice(0, 60)}..." is now live on social network.`,
            timestamp: 'Just now',
            platform: p.platform,
          };
          setActivityFeed((f) => [feedItem, ...f]);

          return published;
        }
        return p;
      })
    );
  };

  const togglePostAutopilot = (id: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, autoPilot: !p.autoPilot } : p))
    );
  };

  // Campaign Actions
  const addCampaign = (
    campaignData: Omit<Campaign, 'id' | 'createdAt' | 'metrics'>,
    initialPosts?: Omit<SocialPost, 'id' | 'createdAt' | 'engagement'>[]
  ): Campaign => {
    const campaignId = `camp-${Date.now()}`;
    const newCampaign: Campaign = {
      ...campaignData,
      id: campaignId,
      createdAt: new Date().toISOString(),
      metrics: {
        totalImpressions: 0,
        totalClicks: 0,
        leadsCaptured: 0,
        conversions: 0,
        conversionRate: 0,
        revenueGenerated: 0,
      },
    };

    setCampaigns((prev) => [newCampaign, ...prev]);

    if (initialPosts && initialPosts.length > 0) {
      const createdPosts: SocialPost[] = initialPosts.map((p, idx) => ({
        ...p,
        id: `post-${Date.now()}-${idx}`,
        campaignId,
        campaignTitle: newCampaign.title,
        createdAt: new Date().toISOString(),
        engagement: {
          impressions: 0,
          likes: 0,
          reposts: 0,
          comments: 0,
          clicks: 0,
          leadsGenerated: 0,
        },
      }));
      setPosts((prev) => [...createdPosts, ...prev]);
    }

    return newCampaign;
  };

  const updateCampaignStatus = (id: string, status: Campaign['status']) => {
    setCampaigns((prev) => prev.map((c) => (c.id === id ? { ...c, status } : c)));
  };

  const deleteCampaign = (id: string) => {
    setCampaigns((prev) => prev.filter((c) => c.id !== id));
  };

  // Email Actions
  const sendEmail = (
    leadId: string,
    subject: string,
    body: string,
    senderEmail: string = 'sarah.chen@leadflow.ai'
  ): EmailMessage => {
    const lead = leads.find((l) => l.id === leadId);
    const leadName = lead ? lead.name : 'Prospect';
    const leadEmail = lead ? lead.email : 'lead@example.com';

    const newEmail: EmailMessage = {
      id: `email-${Date.now()}`,
      leadId,
      leadName,
      leadEmail,
      sender: senderEmail,
      recipient: leadEmail,
      subject,
      body,
      isIncoming: false,
      timestamp: new Date().toISOString(),
      read: true,
      status: 'sent',
      threadId: `thread-${leadId}`,
    };

    setEmails((prev) => [newEmail, ...prev]);

    // Update lead lastContactedAt and status if 'new'
    setLeads((prev) =>
      prev.map((l) => {
        if (l.id === leadId) {
          return {
            ...l,
            lastContactedAt: new Date().toISOString(),
            status: l.status === 'new' ? 'contacted' : l.status,
          };
        }
        return l;
      })
    );

    return newEmail;
  };

  const markEmailRead = (emailId: string) => {
    setEmails((prev) => prev.map((e) => (e.id === emailId ? { ...e, read: true } : e)));
  };

  // Calendar Follow-Up Actions
  const addFollowUp = (followUpData: Omit<CalendarFollowUp, 'id'>): CalendarFollowUp => {
    const newFollowUp: CalendarFollowUp = {
      ...followUpData,
      id: `event-${Date.now()}`,
    };

    setFollowUps((prev) => [newFollowUp, ...prev]);

    // Update lead status to 'meeting_scheduled' if scheduled
    if (newFollowUp.type === 'discovery_call' || newFollowUp.type === 'demo') {
      updateLeadStatus(newFollowUp.leadId, 'meeting_scheduled');
    }

    const feedItem: LiveActivityFeedItem = {
      id: `act-${Date.now()}`,
      type: 'meeting_booked',
      title: 'Follow-Up / Meeting Scheduled',
      description: `${newFollowUp.title} with ${newFollowUp.leadName} (${newFollowUp.leadCompany}).`,
      timestamp: 'Just now',
    };
    setActivityFeed((f) => [feedItem, ...f]);

    return newFollowUp;
  };

  const updateFollowUpStatus = (id: string, status: CalendarFollowUp['status']) => {
    setFollowUps((prev) => prev.map((f) => (f.id === id ? { ...f, status } : f)));
  };

  const deleteFollowUp = (id: string) => {
    setFollowUps((prev) => prev.filter((f) => f.id !== id));
  };

  // Social Account Integrations
  const toggleAccountConnection = (platform: SocialPlatform) => {
    setSocialAccounts((prev) =>
      prev.map((acc) => {
        if (acc.platform === platform) {
          return {
            ...acc,
            connected: !acc.connected,
            lastSync: !acc.connected ? 'Just now' : acc.lastSync,
          };
        }
        return acc;
      })
    );
  };

  const updateSocialAccount = (platform: SocialPlatform, updates: Partial<SocialAccountConnection>) => {
    setSocialAccounts((prev) =>
      prev.map((acc) => (acc.platform === platform ? { ...acc, ...updates } : acc))
    );
  };

  const resetToDefaultData = () => {
    setLeads(INITIAL_LEADS);
    setPosts(INITIAL_POSTS);
    setCampaigns(INITIAL_CAMPAIGNS);
    setEmails(INITIAL_EMAILS);
    setFollowUps(INITIAL_FOLLOW_UPS);
    setTeamMembers(INITIAL_TEAM_MEMBERS);
    setSocialAccounts(INITIAL_SOCIAL_ACCOUNTS);
    setMetricsHistory(INITIAL_METRICS_HISTORY);
    setActivityFeed(INITIAL_ACTIVITY_FEED);
    localStorage.clear();
  };

  return (
    <AppContext.Provider
      value={{
        leads,
        posts,
        campaigns,
        emails,
        followUps,
        teamMembers,
        socialAccounts,
        metricsHistory,
        activityFeed,
        activeTab,
        setActiveTab,
        viewMode,
        setViewMode,
        isLiveSimulating,
        setIsLiveSimulating,
        selectedLeadId,
        setSelectedLeadId,
        addLead,
        updateLeadStatus,
        assignLead,
        addLeadNote,
        deleteLead,
        addPost,
        updatePost,
        deletePost,
        publishPostNow,
        togglePostAutopilot,
        addCampaign,
        updateCampaignStatus,
        deleteCampaign,
        sendEmail,
        markEmailRead,
        addFollowUp,
        updateFollowUpStatus,
        deleteFollowUp,
        toggleAccountConnection,
        updateSocialAccount,
        triggerCelebration,
        resetToDefaultData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
