'use client';

import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  Terminal,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
  Zap,
  Globe,
  Layers,
  Sparkles,
} from 'lucide-react';

interface ApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkModal: React.FC<ApkModalProps> = ({ isOpen, onClose }) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (cmd: string, id: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D11]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-4 sm:p-5 shadow-2xl space-y-4 text-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Smartphone className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">OmniLead AI Android APK & Mobile Suite</h3>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Ready to Package
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Native Android APK binary builder & Progressive Web Application (PWA)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded bg-[#12151C] border border-slate-800 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        </div>

        {/* Overview Banner */}
        <div className="bg-[#12151C] border border-slate-800 rounded-lg p-3 text-xs space-y-1.5">
          <div className="flex items-center gap-2">
            <Zap className="h-3.5 w-3.5 text-blue-400" />
            <strong className="text-white font-bold text-xs">Native Mobile Capabilities Built-In</strong>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            OmniLead AI is fully responsive and engineered with mobile-first viewport meta tags, offline storage caching, touch gesture controls, and native Capacitor Android build configurations.
          </p>
        </div>

        {/* Build Options */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5 uppercase tracking-wide">
            <Terminal className="h-3.5 w-3.5 text-blue-400" />
            1. Compile to Android APK via Capacitor CLI
          </h4>

          <div className="bg-[#0B0D11] border border-slate-800 rounded-lg p-3 font-mono text-xs text-slate-300 space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-[11px] pb-1 border-b border-slate-800">
              <span>Run in terminal to compile .apk:</span>
              <button
                onClick={() =>
                  handleCopy(
                    'npm i -g @capacitor/cli @capacitor/core @capacitor/android && npx cap init "OmniLead AI" "com.omnilead.app" --web-dir out && npm run build && npx cap add android && npx cap build android',
                    'cap-cmd'
                  )
                }
                className="flex items-center gap-1 text-blue-400 hover:text-blue-300 cursor-pointer font-sans text-xs"
              >
                {copiedCmd === 'cap-cmd' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedCmd === 'cap-cmd' ? 'Copied' : 'Copy Commands'}</span>
              </button>
            </div>
            <pre className="text-[11px] text-blue-300 overflow-x-auto leading-relaxed">
{`# 1. Initialize Capacitor Android wrapper
npm i @capacitor/core @capacitor/android
npx cap init "OmniLead AI" "com.omnilead.app"

# 2. Build Next.js static asset bundle
npm run build

# 3. Add Android platform & assemble debug APK
npx cap add android
npx cap copy
npx cap build android`}
            </pre>
          </div>
        </div>

        {/* Instant Mobile Installation (PWA) */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5 uppercase tracking-wide">
            <Globe className="h-3.5 w-3.5 text-blue-400" />
            2. Install Instantly as Mobile App (PWA on Android / iOS)
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="p-2.5 bg-[#12151C] rounded-lg border border-slate-800 space-y-1">
              <strong className="text-emerald-400 block font-bold">On Android (Chrome / Brave):</strong>
              <p className="text-slate-400 text-[11px]">
                Open this app in Chrome, tap the <strong>⋮ Menu</strong> at the top right, and select <strong>&quot;Install App&quot;</strong> or <strong>&quot;Add to Home Screen&quot;</strong>.
              </p>
            </div>

            <div className="p-2.5 bg-[#12151C] rounded-lg border border-slate-800 space-y-1">
              <strong className="text-blue-400 block font-bold">On iPhone / iPad (Safari):</strong>
              <p className="text-slate-400 text-[11px]">
                Open in Safari, tap the <strong>Share</strong> button, and tap <strong>&quot;Add to Home Screen&quot;</strong> for full-screen native execution.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2.5 border-t border-slate-800 text-xs">
          <span className="text-slate-500 font-mono text-[11px]">Package Version: 1.0.4-release</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
