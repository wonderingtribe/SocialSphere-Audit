'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { SocialPlatform } from '@/types';
import {
  Sparkles,
  Bot,
  MessageSquare,
  Send,
  CheckCircle2,
  ThumbsUp,
  AlertCircle,
} from 'lucide-react';

interface AutoReplyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialAuthor?: string;
  initialPlatform?: string;
  initialMessage?: string;
}

export const AutoReplyModal: React.FC<AutoReplyModalProps> = ({
  isOpen,
  onClose,
  initialAuthor = 'Victoria Howard',
  initialPlatform = 'linkedin',
  initialMessage = 'How does the lead generation automation integrate with existing HubSpot CRMs and calendar tools?',
}) => {
  const { addPost } = useApp();

  const [authorName, setAuthorName] = useState(initialAuthor);
  const [platform, setPlatform] = useState<SocialPlatform>(initialPlatform as SocialPlatform);
  const [originalMessage, setOriginalMessage] = useState(initialMessage);
  const [goal, setGoal] = useState<'qualify_and_book' | 'answer_and_link' | 'polite_support' | 'defuse_objection'>('qualify_and_book');
  const [isGenerating, setIsGenerating] = useState(false);
  const [replyResult, setReplyResult] = useState<{
    replyText: string;
    sentiment: string;
    isLeadOpportunity: boolean;
    confidenceScore: number;
  } | null>(null);

  if (!isOpen) return null;

  const handleGenerateReply = async () => {
    if (!originalMessage.trim()) return;
    setIsGenerating(true);

    try {
      const res = await fetch('/api/gemini/auto-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform,
          originalMessage,
          authorName,
          goal,
          productName: 'OmniLead AI',
          brandTone: 'Empathetic, authoritative, helpful B2B founder',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setReplyResult(data.data);
      }
    } catch (e) {
      console.error('Failed to generate auto-reply', e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSendReply = () => {
    alert(`AI response sent to ${authorName} on ${platform.toUpperCase()}!`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D11]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-xl p-4 sm:p-5 shadow-2xl space-y-4 text-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
              <Bot className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Social AI Auto-Responder</h3>
              <p className="text-[11px] text-slate-400">
                Qualify incoming comments and direct messages into qualified CRM leads
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded bg-[#12151C] border border-slate-800 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        </div>

        {/* Interaction Form */}
        <div className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Author / Prospect Name</label>
              <input
                type="text"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Platform</label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value as SocialPlatform)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 capitalize"
              >
                {['linkedin', 'twitter', 'instagram', 'tiktok', 'facebook'].map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Incoming Message Text */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">
              Incoming Comment or DM Text *
            </label>
            <textarea
              rows={3}
              value={originalMessage}
              onChange={(e) => setOriginalMessage(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Response Goal */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Response Objective</label>
            <select
              value={goal}
              onChange={(e) => setGoal(e.target.value as any)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 capitalize"
            >
              <option value="qualify_and_book">Qualify Lead & Invite to Demo</option>
              <option value="answer_and_link">Answer Query with Resource Link</option>
              <option value="polite_support">Polite Customer Support</option>
              <option value="defuse_objection">Address Objection & Provide Social Proof</option>
            </select>
          </div>

          {/* Generate Button */}
          <button
            type="button"
            onClick={handleGenerateReply}
            disabled={isGenerating || !originalMessage.trim()}
            className="w-full py-2 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            <Sparkles className={`h-3.5 w-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Analyzing Sentiment & Synthesizing...' : 'Generate Auto-Response with Gemini'}</span>
          </button>

          {/* Result preview */}
          {replyResult && (
            <div className="space-y-2.5 pt-3 border-t border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold uppercase text-[10px] text-slate-400">Sentiment:</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase">
                    {replyResult.sentiment}
                  </span>
                </div>
                <span className="text-emerald-400 font-mono text-[11px]">
                  Confidence: {Math.round(replyResult.confidenceScore * 100)}%
                </span>
              </div>

              <textarea
                rows={4}
                value={replyResult.replyText}
                onChange={(e) =>
                  setReplyResult({ ...replyResult, replyText: e.target.value })
                }
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
              />

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSendReply}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
                >
                  <Send className="h-3 w-3" />
                  <span>Send Reply via API</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
