'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Sparkles,
  Smartphone,
  Monitor,
  Activity,
  Plus,
  RefreshCw,
  Zap,
  Download,
  Share2,
  Bell,
  CheckCircle2,
} from 'lucide-react';

interface NavbarProps {
  onOpenNewPost: () => void;
  onOpenNewCampaign: () => void;
  onOpenApkModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenNewPost,
  onOpenNewCampaign,
  onOpenApkModal,
}) => {
  const {
    activeTab,
    setActiveTab,
    viewMode,
    setViewMode,
    isLiveSimulating,
    setIsLiveSimulating,
    resetToDefaultData,
    activityFeed,
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0D11]/90 backdrop-blur border-b border-slate-800 text-slate-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-sm">
            N
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white tracking-tight text-sm sm:text-base">
                NEXUS<span className="text-blue-400"> AI</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-600/10 text-blue-400 border border-blue-500/20">
                APK & CRM
              </span>
            </div>
            <div className="hidden md:flex items-center gap-2 text-[11px] text-slate-400">
              <span>System Status: <span className="text-green-400 font-medium">Optimal</span></span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-400">4 APIs Active</span>
            </div>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden lg:flex items-center gap-1 bg-[#12151C] p-1 rounded-lg border border-slate-800">
          <button
            id="nav-tab-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Dashboard
          </button>
          <button
            id="nav-tab-campaigns"
            onClick={() => setActiveTab('campaigns')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'campaigns'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Campaigns
          </button>
          <button
            id="nav-tab-leads"
            onClick={() => setActiveTab('leads')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'leads'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Lead Manager
          </button>
          <button
            id="nav-tab-messages"
            onClick={() => setActiveTab('messages')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'messages'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Gmail & Inbox
          </button>
          <button
            id="nav-tab-calendar"
            onClick={() => setActiveTab('calendar')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'calendar'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Schedule
          </button>
          <button
            id="nav-tab-team"
            onClick={() => setActiveTab('team')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'team'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Team
          </button>
          <button
            id="nav-tab-integrations"
            onClick={() => setActiveTab('integrations')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'integrations'
                ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Integrations
          </button>
        </nav>

        {/* Right Actions: View Mode, Sim Toggle, Quick Action */}
        <div className="flex items-center gap-2">
          {/* Mobile Frame Toggle */}
          <button
            id="toggle-view-mode"
            onClick={() => setViewMode(viewMode === 'desktop' ? 'mobile_apk' : 'desktop')}
            title={viewMode === 'desktop' ? 'Switch to APK Mobile Phone Frame' : 'Switch to Full Desktop View'}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors border ${
              viewMode === 'mobile_apk'
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-[#1A1E26] text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            {viewMode === 'desktop' ? (
              <>
                <Smartphone className="h-3.5 w-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Mobile Frame</span>
              </>
            ) : (
              <>
                <Monitor className="h-3.5 w-3.5 text-blue-400" />
                <span className="hidden sm:inline">Desktop</span>
              </>
            )}
          </button>

          {/* Real-Time Live Feed Pill */}
          <button
            id="toggle-live-simulation"
            onClick={() => setIsLiveSimulating(!isLiveSimulating)}
            title={isLiveSimulating ? 'Live Social Tracking Active' : 'Live Tracking Paused'}
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              isLiveSimulating
                ? 'bg-blue-600/10 border-blue-500/30 text-blue-400'
                : 'bg-[#1A1E26] border-slate-800 text-slate-400 hover:bg-slate-800'
            }`}
          >
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                isLiveSimulating ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
              }`}
            />
            <span className="text-[11px]">{isLiveSimulating ? 'Live Sync' : 'Sync Paused'}</span>
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              id="notifications-button"
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 rounded-lg bg-[#1A1E26] text-slate-300 hover:text-white border border-slate-800 hover:bg-slate-800 transition-colors relative"
            >
              <Bell className="h-3.5 w-3.5" />
              <span className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full bg-blue-600 text-[9px] font-bold flex items-center justify-center text-white">
                {activityFeed.length}
              </span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#1A1E26] border border-slate-800 rounded-xl shadow-2xl p-3 z-50 text-slate-200">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Activity className="h-3.5 w-3.5 text-blue-400" />
                    Live Activity Stream
                  </span>
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Real-time</span>
                </div>
                <div className="max-h-64 overflow-y-auto space-y-1.5 py-2">
                  {activityFeed.slice(0, 6).map((item) => (
                    <div
                      key={item.id}
                      className="p-2 rounded-lg bg-[#12151C] border border-slate-800/80 text-xs hover:bg-slate-800/50 transition-colors"
                    >
                      <div className="font-semibold text-slate-200 flex items-center justify-between">
                        <span>{item.title}</span>
                        <span className="text-[10px] text-slate-500 font-normal">{item.timestamp}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{item.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* APK Modal button */}
          <button
            id="open-apk-export"
            onClick={onOpenApkModal}
            className="p-2 rounded-lg bg-[#1A1E26] text-slate-300 hover:text-white border border-slate-800 hover:bg-slate-800 transition-colors"
            title="Download APK / PWA Configuration"
          >
            <Download className="h-3.5 w-3.5 text-cyan-400" />
          </button>

          {/* Quick Create AI Action */}
          <div className="flex items-center gap-1">
            <button
              id="quick-new-post"
              onClick={onOpenNewPost}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">AI Post</span>
            </button>
            <button
              id="quick-new-campaign"
              onClick={onOpenNewCampaign}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1A1E26] hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5 text-slate-400" />
              <span>Campaign</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
