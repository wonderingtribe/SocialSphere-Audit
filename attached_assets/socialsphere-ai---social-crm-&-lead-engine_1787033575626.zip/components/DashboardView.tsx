'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  TrendingUp,
  Users,
  Target,
  DollarSign,
  Activity,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Send,
  Calendar,
  CheckCircle2,
  Clock,
  ExternalLink,
  MessageSquare,
  Globe,
  Share2,
  Zap,
  RefreshCw,
  Sliders,
  BrainCircuit,
  PieChart,
} from 'lucide-react';

interface DashboardViewProps {
  onOpenNewPost: () => void;
  onOpenNewCampaign: () => void;
  onOpenAutoReply: (author: string, platform: string, message: string) => void;
  onSelectLead: (leadId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenNewPost,
  onOpenNewCampaign,
  onOpenAutoReply,
  onSelectLead,
}) => {
  const {
    leads,
    posts,
    campaigns,
    emails,
    metricsHistory,
    activityFeed,
    setActiveTab,
  } = useApp();

  const [timeRange, setTimeRange] = useState<'7d' | '30d'>('7d');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [growthAnalysis, setGrowthAnalysis] = useState<{
    diagnosis: string;
    recommendations: string[];
    topChannelInsight: string;
    underperformingChannelFix: string;
    projectedConversionRate: number;
  } | null>(null);

  // Compute live aggregates
  const totalLeads = leads.length;
  const wonLeads = leads.filter((l) => l.status === 'won');
  const wonRevenue = wonLeads.reduce((sum, l) => sum + l.estimatedValue, 0);
  const totalPipelineValue = leads.reduce((sum, l) => sum + l.estimatedValue, 0);
  
  const publishedPosts = posts.filter((p) => p.status === 'published');
  const totalImpressions = publishedPosts.reduce((sum, p) => sum + p.engagement.impressions, 84200);
  const totalClicks = publishedPosts.reduce((sum, p) => sum + p.engagement.clicks, 5840);
  const totalLikes = publishedPosts.reduce((sum, p) => sum + p.engagement.likes, 1420);
  
  const overallConversionRate = totalClicks > 0 ? ((totalLeads / totalClicks) * 100).toFixed(1) : '3.6';
  const autopilotPostsCount = posts.filter((p) => p.autoPilot && p.status === 'scheduled').length;

  // Channel breakdown
  const channelCounts: Record<string, number> = {};
  leads.forEach((l) => {
    channelCounts[l.sourcePlatform] = (channelCounts[l.sourcePlatform] || 0) + 1;
  });

  const runAiGrowthDiagnosis = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/gemini/analyze-growth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          totalImpressions,
          totalClicks,
          totalLeads,
          conversions: wonLeads.length,
          conversionRate: parseFloat(overallConversionRate),
          channelStats: channelCounts,
          recentCampaignGoal: 'lead_gen',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setGrowthAnalysis(data.data);
      }
    } catch (e) {
      console.error('Failed to run AI growth diagnosis', e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-4 pb-10">
      {/* Top Welcome & Autonomous Status Banner */}
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                AI Social Engine Live
              </span>
              <span className="text-[11px] text-slate-400">
                Autonomous Lead Capture & Outreach Active
              </span>
            </div>
            <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Real-Time Lead & Social Growth Performance Matrix
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              Generative models analyze engagement signals across channels and funnel qualified inbound prospects directly into your pipeline.
            </p>
          </div>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="dash-run-growth-analysis"
              onClick={runAiGrowthDiagnosis}
              disabled={isAnalyzing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer disabled:opacity-50"
            >
              <BrainCircuit className={`h-3.5 w-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isAnalyzing ? 'Analyzing Pipeline...' : 'AI Growth Diagnosis'}</span>
            </button>

            <button
              id="dash-create-campaign"
              onClick={onOpenNewCampaign}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5 text-blue-400" />
              <span>New Campaign</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Leads */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Active Leads</span>
            <div className="h-7 w-7 rounded bg-blue-600/10 border border-blue-500/20 flex items-center justify-center">
              <Users className="h-3.5 w-3.5 text-blue-400" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-1">
            {totalLeads}
          </div>
          <div className="text-[10px] text-green-400 font-medium flex items-center gap-1 mt-1">
            <ArrowUpRight className="h-3 w-3" />
            <span>+28.4% from last week</span>
          </div>
        </div>

        {/* Website Conversion Rate */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Lead Conversion</span>
            <div className="h-7 w-7 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <Target className="h-3.5 w-3.5 text-emerald-400" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-1">
            {overallConversionRate}%
          </div>
          <div className="text-[10px] text-green-400 font-medium flex items-center gap-1 mt-1">
            <ArrowUpRight className="h-3 w-3" />
            <span>+2.1% trending upward</span>
          </div>
        </div>

        {/* Pipeline Value */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Pipeline Value</span>
            <div className="h-7 w-7 rounded bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <DollarSign className="h-3.5 w-3.5 text-indigo-400" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-1">
            ${(totalPipelineValue / 1000).toFixed(1)}k
          </div>
          <div className="text-[10px] text-blue-400 font-medium flex items-center gap-1 mt-1">
            <ArrowUpRight className="h-3 w-3" />
            <span>${(wonRevenue / 1000).toFixed(1)}k closed revenue</span>
          </div>
        </div>

        {/* Engagement Growth */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Eng. Growth</span>
            <div className="h-7 w-7 rounded bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
              <TrendingUp className="h-3.5 w-3.5 text-cyan-400" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-1">
            +{(totalImpressions / 1000).toFixed(1)}k
          </div>
          <div className="text-[10px] text-blue-400 font-medium flex items-center gap-1 mt-1">
            <Zap className="h-3 w-3" />
            <span>{autopilotPostsCount} scheduled autopilot</span>
          </div>
        </div>
      </div>

      {/* AI Growth Analysis Result Box (if analyzed) */}
      {growthAnalysis && (
        <div className="bg-[#1A1E26] border border-blue-500/30 rounded-xl p-4 shadow-xl text-slate-200 space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-blue-400" />
              <h3 className="font-bold text-sm text-white">
                Strategic Growth Recommendations
              </h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-600/15 text-blue-400 border border-blue-500/30">
              Target: {growthAnalysis.projectedConversionRate}% Conversion
            </span>
          </div>

          <div className="p-3 bg-[#12151C] rounded-lg border border-slate-800 text-xs text-slate-300 leading-relaxed">
            <strong className="text-blue-400">Diagnosis: </strong>
            {growthAnalysis.diagnosis}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-[#12151C] rounded-lg border border-slate-800">
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                Top Channel Scaling
              </span>
              <p className="text-xs text-slate-400">{growthAnalysis.topChannelInsight}</p>
            </div>
            <div className="p-3 bg-[#12151C] rounded-lg border border-slate-800">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
                Optimization Fix
              </span>
              <p className="text-xs text-slate-400">{growthAnalysis.underperformingChannelFix}</p>
            </div>
            <div className="p-3 bg-[#12151C] rounded-lg border border-slate-800">
              <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                Action Steps
              </span>
              <ul className="text-xs text-slate-400 space-y-1">
                {growthAnalysis.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <CheckCircle2 className="h-3 w-3 text-cyan-400 shrink-0 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Main Charts & Attribution Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Interactive Growth & Conversion Chart */}
        <div className="lg:col-span-2 bg-[#1A1E26] rounded-xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-blue-400" />
                Campaign Performance Matrix
              </h2>
              <p className="text-[11px] text-slate-500">
                Daily lead volume vs website conversion rate (%)
              </p>
            </div>
            <div className="flex items-center gap-1 bg-[#12151C] p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => setTimeRange('7d')}
                className={`px-2.5 py-1 text-[10px] font-bold uppercase rounded transition-colors ${
                  timeRange === '7d' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Weekly
              </button>
              <button
                onClick={() => setTimeRange('30d')}
                className={`px-2.5 py-1 text-[10px] font-bold uppercase rounded transition-colors ${
                  timeRange === '30d' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Monthly
              </button>
            </div>
          </div>

          {/* Custom SVG Interactive Chart */}
          <div className="h-52 sm:h-60 w-full relative pt-2">
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-20">
              <div className="border-b border-slate-700 w-full" />
              <div className="border-b border-slate-700 w-full" />
              <div className="border-b border-slate-700 w-full" />
              <div className="border-b border-slate-700 w-full" />
            </div>

            <svg className="w-full h-full overflow-visible" viewBox="0 0 700 200" preserveAspectRatio="none">
              <defs>
                <linearGradient id="leadGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#2563eb" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#2563eb" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="rateGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Area under curve for leads */}
              <polygon
                fill="url(#leadGrad)"
                points="0,170 100,150 200,120 300,95 400,65 500,45 600,20 600,200 0,200"
              />

              {/* Line for Leads */}
              <polyline
                fill="none"
                stroke="#2563eb"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                points="0,170 100,150 200,120 300,95 400,65 500,45 600,20"
              />

              {/* Line for Conversion Rate */}
              <polyline
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeDasharray="4 4"
                strokeLinecap="round"
                points="0,160 100,145 200,130 300,110 400,90 500,75 600,55"
              />

              {/* Data points */}
              {[
                { x: 0, y: 170, label: '22 leads' },
                { x: 100, y: 150, label: '28 leads' },
                { x: 200, y: 120, label: '39 leads' },
                { x: 300, y: 95, label: '48 leads' },
                { x: 400, y: 65, label: '62 leads' },
                { x: 500, y: 45, label: '74 leads' },
                { x: 600, y: 20, label: '89 leads' },
              ].map((pt, idx) => (
                <circle
                  key={idx}
                  cx={pt.x}
                  cy={pt.y}
                  r="4.5"
                  className="fill-blue-600 stroke-[#1A1E26] stroke-2 hover:r-6 transition-all cursor-pointer"
                />
              ))}
            </svg>

            {/* X-axis labels */}
            <div className="flex justify-between text-[10px] text-slate-500 mt-2 font-medium">
              {metricsHistory.map((m, idx) => (
                <span key={idx}>{m.date}</span>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-blue-600" />
                <span className="text-slate-300 text-[11px]">Daily Leads Captured</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                <span className="text-slate-300 text-[11px]">Conversion Rate % (Dotted)</span>
              </div>
            </div>
            <span className="text-slate-500 text-[10px] font-mono">Live Webhook Synced</span>
          </div>
        </div>

        {/* Channel Attribution Breakdown */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <PieChart className="h-4 w-4 text-cyan-400" />
              Source Attribution
            </h2>
            <span className="text-[10px] uppercase font-bold text-slate-500">By Origin</span>
          </div>

          <div className="space-y-3 pt-1">
            {[
              { name: 'LinkedIn Posts & Articles', count: 42, pct: 47, color: 'bg-blue-600' },
              { name: 'X / Twitter AI Hooks', count: 28, pct: 31, color: 'bg-sky-500' },
              { name: 'Instagram & Threads DMs', count: 12, pct: 14, color: 'bg-pink-500' },
              { name: 'TikTok Video Bio Links', count: 7, pct: 8, color: 'bg-emerald-500' },
            ].map((chan, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">{chan.name}</span>
                  <span className="text-slate-400 font-semibold">{chan.pct}% ({chan.count})</span>
                </div>
                <div className="h-1.5 w-full bg-[#0B0D11] rounded-full overflow-hidden">
                  <div
                    className={`h-full ${chan.color} rounded-full transition-all duration-500`}
                    style={{ width: `${chan.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Quick CTA to see CRM */}
          <div className="pt-3 border-t border-slate-800">
            <button
              onClick={() => setActiveTab('leads')}
              className="w-full py-2 px-3 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>View Full Lead Pipeline</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Live Social Interactions & Hot Leads Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Real-Time Live Feed & Comment Auto-Responder */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-emerald-400" />
              <h2 className="text-sm font-bold text-white">Live Activity Stream</h2>
            </div>
            <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
              Active Webhooks
            </span>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {activityFeed.map((item) => (
              <div
                key={item.id}
                className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800/80 hover:bg-slate-800/50 transition-colors flex items-start justify-between gap-3"
              >
                <div className="flex items-start gap-2.5">
                  {item.avatar ? (
                    <img
                      src={item.avatar}
                      alt="avatar"
                      className="h-8 w-8 rounded-full object-cover border border-slate-700 shrink-0"
                    />
                  ) : (
                    <div className="h-8 w-8 rounded bg-blue-600/10 border border-blue-500/20 flex items-center justify-center shrink-0">
                      <MessageSquare className="h-3.5 w-3.5 text-blue-400" />
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{item.title}</span>
                      {item.platform && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-[#0B0D11] text-slate-400 uppercase border border-slate-800">
                          {item.platform}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-300 mt-0.5">{item.description}</p>
                    <span className="text-[9px] text-slate-500 mt-1 block font-mono">{item.timestamp}</span>
                  </div>
                </div>

                {item.platform && (
                  <button
                    onClick={() =>
                      onOpenAutoReply(
                        item.title.includes('Victoria') ? 'Victoria Howard' : 'Prospect',
                        item.platform || 'twitter',
                        item.description
                      )
                    }
                    className="px-2 py-1 rounded bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/30 text-[10px] font-bold shrink-0 transition-colors cursor-pointer"
                  >
                    AI Reply
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Hot Leads Quick Action Queue */}
        <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-blue-400" />
              <h2 className="text-sm font-bold text-white">Recent Leads (Gmail & Inbound)</h2>
            </div>
            <button
              onClick={() => setActiveTab('leads')}
              className="text-[10px] font-bold uppercase text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-2">
            {leads.slice(0, 4).map((lead) => (
              <div
                key={lead.id}
                onClick={() => onSelectLead(lead.id)}
                className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800/80 hover:border-blue-500/40 hover:bg-slate-800/50 transition-all cursor-pointer flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                  <img
                    src={lead.avatar}
                    alt={lead.name}
                    className="h-8 w-8 rounded-full object-cover border border-slate-700 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white">{lead.name}</h4>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Score {lead.leadScore}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {lead.role} · {lead.company}
                    </p>
                    <span className="text-[9px] text-slate-500 font-mono">
                      Rep: {lead.assignedToName} · [{lead.sourcePlatform.toUpperCase()}]
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-bold text-white block">
                    ${lead.estimatedValue.toLocaleString()}
                  </span>
                  <span
                    className={`inline-block text-[9px] font-bold px-1.5 py-0.5 rounded mt-0.5 uppercase ${
                      lead.status === 'meeting_scheduled'
                        ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                        : lead.status === 'won'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {lead.status.replace('_', ' ')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
