'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { SocialPlatform } from '@/types';
import {
  Sparkles,
  Megaphone,
  Bot,
  Calendar,
  Layers,
  CheckCircle2,
  Sliders,
  Zap,
} from 'lucide-react';

interface NewCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewCampaignModal: React.FC<NewCampaignModalProps> = ({ isOpen, onClose }) => {
  const { addCampaign } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [goal, setGoal] = useState<'lead_gen' | 'brand_awareness' | 'product_launch' | 'event_registration' | 'retargeting'>('lead_gen');
  const [platforms, setPlatforms] = useState<SocialPlatform[]>(['linkedin', 'twitter', 'instagram']);
  const [durationDays, setDurationDays] = useState(7);
  const [customInstructions, setCustomInstructions] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const togglePlatform = (p: SocialPlatform) => {
    if (platforms.includes(p)) {
      if (platforms.length > 1) {
        setPlatforms(platforms.filter((item) => item !== p));
      }
    } else {
      setPlatforms([...platforms, p]);
    }
  };

  const handleGenerateCampaign = async () => {
    if (!title.trim() || !description.trim()) return;
    setIsGenerating(true);

    try {
      const res = await fetch('/api/gemini/generate-campaign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          targetAudience: targetAudience || 'Founders, Marketing Directors & Agency Owners',
          goal,
          platforms,
          durationDays: Number(durationDays),
          customInstructions,
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        const campaignResult = data.data;

        const scheduledStartDate = new Date().toISOString().split('T')[0];
        const scheduledEndDate = new Date(Date.now() + durationDays * 86400000)
          .toISOString()
          .split('T')[0];

        const initialPosts = campaignResult.posts.map((p: any) => ({
          platform: p.platform,
          content: p.content,
          hashtags: p.hashtags || [],
          ctaUrl: p.ctaUrl,
          status: 'scheduled' as const,
          scheduledFor: new Date(Date.now() + (p.dayOffset || 1) * 86400000).toISOString(),
          autoPilot: true,
        }));

        addCampaign(
          {
            title,
            description: campaignResult.strategyOverview || description,
            targetAudience: targetAudience || 'B2B Decision Makers',
            goal,
            platforms,
            status: 'active',
            scheduledStartDate,
            scheduledEndDate,
            customInstructions,
          },
          initialPosts
        );

        onClose();
        setTitle('');
        setDescription('');
        setCustomInstructions('');
      }
    } catch (e) {
      console.error('Failed to generate campaign', e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D11]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-4 sm:p-5 shadow-2xl space-y-4 text-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
              <Megaphone className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Create Multi-Channel AI Campaign</h3>
              <p className="text-[11px] text-slate-400">
                Custom prompt instructions generate a coordinated multi-day publishing schedule
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded bg-[#12151C] border border-slate-800 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        </div>

        {/* Form Controls */}
        <div className="space-y-3.5 text-xs">
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">
              Campaign Title *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Q3 Growth Marketing Autopilot Launch"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">
              Product / Offer Description *
            </label>
            <textarea
              rows={3}
              required
              placeholder="e.g. Launching a new AI social tool that generates 50+ qualified inbound leads per week for B2B tech companies."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Target Audience</label>
              <input
                type="text"
                placeholder="e.g. SaaS Founders, Marketing Directors"
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Campaign Goal</label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value as any)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500 capitalize"
              >
                <option value="lead_gen">Direct Lead Generation</option>
                <option value="product_launch">Product / Feature Launch</option>
                <option value="event_registration">Webinar / Demo Registration</option>
                <option value="brand_awareness">Brand Awareness & Reach</option>
              </select>
            </div>
          </div>

          {/* Platforms Selector */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Target Social Channels</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'linkedin', label: 'LinkedIn' },
                { id: 'twitter', label: 'X / Twitter' },
                { id: 'instagram', label: 'Instagram' },
                { id: 'tiktok', label: 'TikTok' },
              ].map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => togglePlatform(p.id as SocialPlatform)}
                  className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center ${
                    platforms.includes(p.id as SocialPlatform)
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-[#12151C] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Text Prompt Instructions */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">
              Custom Prompt Instructions & Copywriting Rules (Optional)
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Include case study statistics, keep hooks contrarian, emphasize the 14-day free trial, and include a clear call-to-action link to https://myproduct.com/demo on every 2nd post."
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none font-mono"
            />
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-2 pt-2.5 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-400"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleGenerateCampaign}
              disabled={isGenerating || !title.trim() || !description.trim()}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`h-3.5 w-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'Synthesizing 7-Day Campaign...' : 'Generate Full Campaign with Gemini'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
