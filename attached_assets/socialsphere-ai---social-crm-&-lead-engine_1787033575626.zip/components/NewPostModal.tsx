'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { SocialPlatform } from '@/types';
import {
  Sparkles,
  Bot,
  Send,
  Calendar,
  Globe,
  Sliders,
  CheckCircle2,
  Copy,
  Check,
} from 'lucide-react';

interface NewPostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewPostModal: React.FC<NewPostModalProps> = ({ isOpen, onClose }) => {
  const { addPost, publishPostNow } = useApp();

  const [platform, setPlatform] = useState<SocialPlatform>('twitter');
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState<'authoritative' | 'casual' | 'provocative' | 'educational' | 'storytelling'>('educational');
  const [goal, setGoal] = useState<'lead_gen' | 'engagement' | 'brand_awareness' | 'conversion'>('lead_gen');
  const [ctaUrl, setCtaUrl] = useState('https://mysite.com/demo');
  const [customInstructions, setCustomInstructions] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [generatedHashtags, setGeneratedHashtags] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [publishImmediately, setPublishImmediately] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setIsGenerating(true);
    try {
      const res = await fetch('/api/gemini/generate-post', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform,
          topic,
          tone,
          goal,
          targetAudience: 'Growth Marketers, Founders & Sales Leaders',
          ctaUrl,
          customInstructions,
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setGeneratedContent(data.data.content);
        setGeneratedHashtags(data.data.hashtags || []);
      }
    } catch (e) {
      console.error('Failed to generate post', e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (!generatedContent.trim()) return;

    const newPost = addPost({
      platform,
      content: generatedContent,
      hashtags: generatedHashtags,
      ctaUrl: ctaUrl || undefined,
      status: publishImmediately ? 'published' : 'scheduled',
      scheduledFor: new Date(Date.now() + 3600000 * 4).toISOString(),
      autoPilot: true,
      publishedAt: publishImmediately ? new Date().toISOString() : undefined,
    });

    if (publishImmediately) {
      publishPostNow(newPost.id);
    }

    onClose();
    // Reset state
    setGeneratedContent('');
    setTopic('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D11]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto p-4 sm:p-5 shadow-2xl space-y-4 text-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
              <Sparkles className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Create AI Social Post</h3>
              <p className="text-[11px] text-slate-400">
                Generate high-converting copy tuned for specific social algorithms
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded bg-[#12151C] border border-slate-800 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        </div>

        {/* Form Controls */}
        <div className="space-y-3.5 text-xs">
          {/* Platform Selector */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Target Platform</label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              {[
                { id: 'twitter', label: 'X / Twitter' },
                { id: 'linkedin', label: 'LinkedIn' },
                { id: 'instagram', label: 'Instagram' },
                { id: 'tiktok', label: 'TikTok' },
                { id: 'facebook', label: 'Facebook' },
                { id: 'threads', label: 'Threads' },
              ].map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => setPlatform(p.id as SocialPlatform)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold border transition-all cursor-pointer text-center ${
                    platform === p.id
                      ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                      : 'bg-[#12151C] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Topic & Core Message */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">
              Topic, Hook, or Core Value Proposition *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. 5 reasons why traditional cold calling is dead and AI lead gen is 10x faster"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Tone & Goal row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Tone of Voice</label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value as any)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500 capitalize"
              >
                <option value="educational">Educational & Actionable</option>
                <option value="authoritative">Authoritative & Analytical</option>
                <option value="provocative">Provocative & Bold</option>
                <option value="storytelling">Storytelling & Vulnerable</option>
                <option value="casual">Casual & Relatable</option>
              </select>
            </div>

            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Primary Conversion Goal</label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value as any)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500 capitalize"
              >
                <option value="lead_gen">Direct Lead Generation</option>
                <option value="conversion">Free Trial / Website Signup</option>
                <option value="engagement">High Viral Engagement / Comments</option>
                <option value="brand_awareness">Brand Authority</option>
              </select>
            </div>
          </div>

          {/* CTA URL */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Call to Action Link (CTA)</label>
            <input
              type="text"
              placeholder="https://yourwebsite.com/free-demo"
              value={ctaUrl}
              onChange={(e) => setCtaUrl(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>

          {/* Generate Button */}
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating || !topic.trim()}
            className="w-full py-2 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            <Sparkles className={`h-3.5 w-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Synthesizing with Gemini 3.7...' : 'Generate Post Copy with Gemini AI'}</span>
          </button>

          {/* Generated Result Preview */}
          {generatedContent && (
            <div className="space-y-3 pt-3 border-t border-slate-800">
              <label className="font-bold uppercase text-[10px] text-emerald-400 block">
                Generated Preview ({platform.toUpperCase()} Optimized)
              </label>

              <textarea
                rows={5}
                value={generatedContent}
                onChange={(e) => setGeneratedContent(e.target.value)}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
              />

              <div className="flex flex-wrap gap-1.5">
                {generatedHashtags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-mono"
                  >
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Publish Options */}
              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={publishImmediately}
                    onChange={(e) => setPublishImmediately(e.target.checked)}
                    className="rounded bg-[#12151C] border-slate-800 text-blue-600"
                  />
                  <span>Publish to social network API immediately</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
                  >
                    {publishImmediately ? 'Publish Now' : 'Schedule to Queue'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
