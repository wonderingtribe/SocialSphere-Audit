'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Mail,
  Sparkles,
  Send,
  User,
  Building,
  Bot,
  Globe,
  Paperclip,
} from 'lucide-react';

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialLeadId?: string | null;
}

export const EmailModal: React.FC<EmailModalProps> = ({
  isOpen,
  onClose,
  initialLeadId,
}) => {
  const { leads, sendEmail } = useApp();

  const [leadId, setLeadId] = useState(() => initialLeadId || (leads[0]?.id || ''));
  const selectedLead = leads.find((l) => l.id === leadId) || leads[0];

  const [subject, setSubject] = useState(() =>
    selectedLead ? `Accelerating pipeline growth for ${selectedLead.company}` : ''
  );
  const [body, setBody] = useState('');
  const [goal, setGoal] = useState<'follow_up' | 'book_demo' | 'share_pricing' | 'introduce_features'>('book_demo');
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const handleGenerateAiEmail = async () => {
    if (!selectedLead) return;
    setIsGenerating(true);

    try {
      const res = await fetch('/api/gemini/lead-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leadName: selectedLead.name,
          leadCompany: selectedLead.company,
          leadRole: selectedLead.role,
          leadSource: selectedLead.sourcePlatform,
          goal,
          websiteInteractions: selectedLead.websiteInteractions,
          senderName: 'Sarah Chen',
          senderRole: 'Lead Account Executive',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setSubject(data.data.subject);
        setBody(data.data.body);
      }
    } catch (e) {
      console.error('Failed to generate AI lead email', e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLead || !subject.trim() || !body.trim()) return;

    sendEmail(selectedLead.id, subject, body);
    onClose();
    setSubject('');
    setBody('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D11]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <form
        onSubmit={handleSend}
        className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-xl max-h-[92vh] overflow-y-auto p-4 sm:p-5 shadow-2xl space-y-3.5 text-slate-200"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
              <Mail className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Compose Gmail Message</h3>
              <p className="text-[11px] text-slate-400">
                Personalized lead outreach sent directly through connected Gmail API
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded bg-[#12151C] border border-slate-800 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        </div>

        <div className="space-y-3 text-xs">
          {/* Select Lead */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">To (Prospect Lead) *</label>
            <select
              value={leadId}
              onChange={(e) => {
                const newId = e.target.value;
                setLeadId(newId);
                const l = leads.find((item) => item.id === newId);
                if (l) setSubject(`Accelerating pipeline growth for ${l.company}`);
              }}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              {leads.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.email}) — {l.company} [{l.sourcePlatform.toUpperCase()}]
                </option>
              ))}
            </select>
          </div>

          {/* AI Outreach Assistant Generator Bar */}
          <div className="bg-[#12151C] p-2.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-[11px] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-blue-400" />
                Gemini Personalization Engine
              </span>
              <span className="text-[9px] text-slate-500 font-mono">
                Leverages website interaction history
              </span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value as any)}
                className="flex-1 bg-[#0B0D11] border border-slate-800 text-xs text-slate-200 rounded px-2 py-1.5 focus:outline-none"
              >
                <option value="book_demo">Invite to 15-Min Demo</option>
                <option value="follow_up">Gentle Follow-Up</option>
                <option value="share_pricing">Share Enterprise Pricing</option>
                <option value="introduce_features">Introduce Core Automations</option>
              </select>

              <button
                type="button"
                onClick={handleGenerateAiEmail}
                disabled={isGenerating}
                className="px-2.5 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm cursor-pointer disabled:opacity-50"
              >
                <Bot className={`h-3.5 w-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
                <span>{isGenerating ? 'Drafting...' : 'Draft with AI'}</span>
              </button>
            </div>
          </div>

          {/* Subject Line */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Subject Line *</label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Body */}
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Email Body *</label>
            <textarea
              rows={6}
              required
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Hi [Name], I noticed you checked out our platform..."
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none leading-relaxed font-sans"
            />
          </div>

          {/* Footer controls */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-[10px] text-slate-500 font-mono">
              From: sarah.chen@leadflow.ai
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-400"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!subject.trim() || !body.trim()}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
                <span>Send Email</span>
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
