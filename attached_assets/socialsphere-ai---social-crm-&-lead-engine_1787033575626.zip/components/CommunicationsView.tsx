'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { EmailMessage } from '@/types';
import {
  Mail,
  Send,
  Sparkles,
  Inbox,
  SendHorizontal,
  Clock,
  User,
  Plus,
  Search,
  CheckCircle2,
  Trash2,
  Paperclip,
  ExternalLink,
  Bot,
  MessageSquare,
  Zap,
} from 'lucide-react';

interface CommunicationsViewProps {
  initialLeadId?: string | null;
  onOpenEmailModal: (leadId: string) => void;
}

export const CommunicationsView: React.FC<CommunicationsViewProps> = ({
  initialLeadId,
  onOpenEmailModal,
}) => {
  const { emails, leads, sendEmail, markEmailRead } = useApp();

  const [activeFolder, setActiveFolder] = useState<'inbox' | 'sent'>('inbox');
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(
    emails.length > 0 ? emails[0].id : null
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [replyBody, setReplyBody] = useState('');
  const [isGeneratingAiEmail, setIsGeneratingAiEmail] = useState(false);
  const [aiGoal, setAiGoal] = useState<'follow_up' | 'book_demo' | 'share_pricing' | 'introduce_features'>('follow_up');

  const filteredEmails = emails.filter((e) => {
    const matchesFolder = activeFolder === 'inbox' ? e.isIncoming : !e.isIncoming;
    const matchesSearch =
      e.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.leadName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.body.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFolder && matchesSearch;
  });

  const selectedEmail = emails.find((e) => e.id === selectedEmailId) || filteredEmails[0];
  const activeLead = selectedEmail ? leads.find((l) => l.id === selectedEmail.leadId) : null;

  const handleGenerateAiResponse = async () => {
    if (!activeLead) return;
    setIsGeneratingAiEmail(true);
    try {
      const res = await fetch('/api/gemini/lead-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leadName: activeLead.name,
          leadCompany: activeLead.company,
          leadRole: activeLead.role,
          leadSource: activeLead.sourcePlatform,
          goal: aiGoal,
          websiteInteractions: activeLead.websiteInteractions,
          senderName: 'Sarah Chen',
          senderRole: 'Lead Account Executive',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setReplyBody(data.data.body);
      }
    } catch (e) {
      console.error('Failed to generate AI email', e);
    } finally {
      setIsGeneratingAiEmail(false);
    }
  };

  const handleSendReply = () => {
    if (!selectedEmail || !replyBody.trim()) return;
    sendEmail(
      selectedEmail.leadId,
      selectedEmail.subject.startsWith('Re:') ? selectedEmail.subject : `Re: ${selectedEmail.subject}`,
      replyBody
    );
    setReplyBody('');
  };

  return (
    <div className="space-y-4 pb-10">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-red-500/10 text-red-400 border border-red-500/20">
              Gmail & Direct Lead Inbox
            </span>
            <span className="text-[11px] text-slate-400">
              Direct Two-Way Messaging with Prospects
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-1">
            Gmail Direct Communication Hub
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Send AI-personalized follow-ups, reply directly from your connected inbox, and auto-sync message threads to your CRM.
          </p>
        </div>

        {leads.length > 0 && (
          <button
            onClick={() => onOpenEmailModal(leads[0].id)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 text-blue-200" />
            <span>Compose Email</span>
          </button>
        )}
      </div>

      {/* Main Split-Screen Inbox Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 bg-[#1A1E26] border border-slate-800 rounded-xl overflow-hidden shadow-sm min-h-[560px]">
        {/* Sidebar Folders & Threads List (5 Cols) */}
        <div className="lg:col-span-5 border-r border-slate-800 flex flex-col bg-[#12151C]">
          {/* Top Folder Toggles */}
          <div className="p-3 border-b border-slate-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1 bg-[#0B0D11] p-1 rounded-lg border border-slate-800 w-full">
              <button
                onClick={() => setActiveFolder('inbox')}
                className={`flex-1 py-1 rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1.5 transition-colors ${
                  activeFolder === 'inbox' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Inbox className="h-3.5 w-3.5" />
                <span>Inbox ({emails.filter((e) => e.isIncoming).length})</span>
              </button>
              <button
                onClick={() => setActiveFolder('sent')}
                className={`flex-1 py-1 rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1.5 transition-colors ${
                  activeFolder === 'sent' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <SendHorizontal className="h-3.5 w-3.5" />
                <span>Sent ({emails.filter((e) => !e.isIncoming).length})</span>
              </button>
            </div>
          </div>

          {/* Search Box */}
          <div className="p-3 border-b border-slate-800 bg-[#12151C]">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search mail threads..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Email Item Rows */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80 max-h-[500px]">
            {filteredEmails.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs font-mono">
                No emails in this folder.
              </div>
            ) : (
              filteredEmails.map((email) => {
                const lead = leads.find((l) => l.id === email.leadId);
                const isSelected = selectedEmail?.id === email.id;

                return (
                  <div
                    key={email.id}
                    onClick={() => {
                      setSelectedEmailId(email.id);
                      markEmailRead(email.id);
                    }}
                    className={`p-3 transition-colors cursor-pointer space-y-1 ${
                      isSelected
                        ? 'bg-blue-600/10 border-l-2 border-blue-500'
                        : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-white truncate max-w-[130px]">
                          {email.leadName}
                        </span>
                        {lead && (
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            Score {lead.leadScore}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(email.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <h4 className="text-xs font-semibold text-slate-200 truncate">
                      {email.subject}
                    </h4>

                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                      {email.body}
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Selected Email Message & AI Copilot (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between p-4 sm:p-5 space-y-4 bg-[#1A1E26]">
          {selectedEmail ? (
            <div className="space-y-4 flex-1 flex flex-col justify-between">
              {/* Message Header */}
              <div className="space-y-2.5 pb-3 border-b border-slate-800">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-sm font-bold text-white tracking-tight">
                      {selectedEmail.subject}
                    </h2>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                      <span>From: <strong className="text-slate-200">{selectedEmail.sender}</strong></span>
                      <span>•</span>
                      <span>To: <strong className="text-slate-200">{selectedEmail.recipient}</strong></span>
                    </div>
                  </div>

                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(selectedEmail.timestamp).toLocaleString()}
                  </span>
                </div>

                {activeLead && (
                  <div className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <img
                        src={activeLead.avatar}
                        alt={activeLead.name}
                        className="h-6 w-6 rounded-full object-cover border border-slate-700"
                      />
                      <span>
                        <strong className="text-white">{activeLead.name}</strong> ({activeLead.role}, {activeLead.company})
                      </span>
                    </div>
                    <span className="text-blue-400 font-bold uppercase text-[10px]">
                      Source: {activeLead.sourcePlatform}
                    </span>
                  </div>
                )}
              </div>

              {/* Message Body Content */}
              <div className="p-3.5 rounded-lg bg-[#12151C] border border-slate-800 text-xs text-slate-200 leading-relaxed whitespace-pre-line overflow-y-auto max-h-52 font-sans">
                {selectedEmail.body}
              </div>

              {/* AI Copilot & Reply Composer */}
              <div className="space-y-2.5 pt-2.5 border-t border-slate-800">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5 text-blue-400" />
                    <span className="text-[11px] font-bold text-white uppercase tracking-wider">AI Reply Assistant:</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <select
                      value={aiGoal}
                      onChange={(e) => setAiGoal(e.target.value as any)}
                      className="bg-[#12151C] border border-slate-800 text-xs text-slate-300 rounded px-2 py-1 focus:outline-none"
                    >
                      <option value="follow_up">Gentle Follow-Up</option>
                      <option value="book_demo">Invite to 15-Min Demo</option>
                      <option value="share_pricing">Send Enterprise Pricing</option>
                      <option value="introduce_features">Highlight Core Features</option>
                    </select>

                    <button
                      onClick={handleGenerateAiResponse}
                      disabled={isGeneratingAiEmail}
                      className="flex items-center gap-1 px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer disabled:opacity-50"
                    >
                      <Bot className={`h-3 w-3 ${isGeneratingAiEmail ? 'animate-spin' : ''}`} />
                      <span>{isGeneratingAiEmail ? 'Drafting...' : 'Draft with AI'}</span>
                    </button>
                  </div>
                </div>

                {/* Reply Textarea */}
                <div className="space-y-2">
                  <textarea
                    rows={3}
                    placeholder="Type your reply or use AI copilot above..."
                    value={replyBody}
                    onChange={(e) => setReplyBody(e.target.value)}
                    className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
                  />

                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 font-mono">
                      Sending via: <strong className="text-slate-300">sarah.chen@leadflow.ai</strong>
                    </span>

                    <button
                      onClick={handleSendReply}
                      disabled={!replyBody.trim()}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors disabled:opacity-40 cursor-pointer"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>Send Email</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-slate-500 text-xs font-mono">
              <Mail className="h-8 w-8 text-slate-700 mb-2" />
              <p>Select an email to view thread details.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
