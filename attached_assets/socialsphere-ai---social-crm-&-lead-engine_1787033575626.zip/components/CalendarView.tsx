'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { CalendarFollowUp } from '@/types';
import {
  Calendar as CalendarIcon,
  Clock,
  Plus,
  CheckCircle2,
  Video,
  Phone,
  Mail,
  User,
  Trash2,
  AlertCircle,
  Sparkles,
  ArrowRight,
  ExternalLink,
  Bot,
  CalendarCheck,
} from 'lucide-react';

interface CalendarViewProps {
  onOpenScheduleModal: (leadId?: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ onOpenScheduleModal }) => {
  const { followUps, updateFollowUpStatus, deleteFollowUp, leads } = useApp();

  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filteredFollowUps = followUps.filter((f) => {
    if (typeFilter === 'all') return true;
    return f.type === typeFilter;
  });

  const pendingCount = followUps.filter((f) => f.status === 'pending').length;
  const completedCount = followUps.filter((f) => f.status === 'completed').length;

  const getTypeBadge = (type: CalendarFollowUp['type']) => {
    switch (type) {
      case 'discovery_call':
        return { label: 'Discovery Call', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' };
      case 'demo':
        return { label: 'Product Demo', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
      case 'contract_review':
        return { label: 'Contract / Closing', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'automated_checkin':
        return { label: 'AI Auto-Checkin', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' };
      default:
        return { label: 'Email Follow-up', color: 'bg-slate-700 text-slate-300' };
    }
  };

  return (
    <div className="space-y-4 pb-10">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-purple-500/10 text-purple-400 border border-purple-500/20">
              Google Calendar & Automated Follow-Ups
            </span>
            <span className="text-[11px] text-slate-400">
              {pendingCount} Upcoming Scheduled Events
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-1">
            Follow-Up Cadence & Meeting Manager
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated calendar reminders, Google Meet demo appointments, and AI-scheduled pipeline follow-ups.
          </p>
        </div>

        <button
          onClick={() => onOpenScheduleModal()}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
        >
          <Plus className="h-3.5 w-3.5 text-blue-200" />
          <span>Schedule Follow-Up</span>
        </button>
      </div>

      {/* Calendar Metrics & Filters */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] uppercase font-bold text-slate-500">Pending Actions</span>
          <span className="text-lg font-bold text-white block mt-0.5 font-mono">{pendingCount}</span>
        </div>
        <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] uppercase font-bold text-slate-500">Completed Sessions</span>
          <span className="text-lg font-bold text-emerald-400 block mt-0.5 font-mono">{completedCount}</span>
        </div>
        <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] uppercase font-bold text-slate-500">Automated Cadence</span>
          <span className="text-lg font-bold text-cyan-400 block mt-0.5">Active</span>
        </div>
        <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-3">
          <span className="text-[10px] uppercase font-bold text-slate-500">Sync Provider</span>
          <span className="text-lg font-bold text-blue-400 block mt-0.5 truncate">Google Workspace</span>
        </div>
      </div>

      {/* Events List & Automated Cadence Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Scheduled List (2 Cols) */}
        <div className="lg:col-span-2 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm space-y-3.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
            <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <CalendarCheck className="h-3.5 w-3.5 text-blue-400" />
              Upcoming Follow-Up Schedule
            </h2>

            <div className="flex items-center gap-1 overflow-x-auto">
              {['all', 'discovery_call', 'demo', 'automated_checkin'].map((type) => (
                <button
                  key={type}
                  onClick={() => setTypeFilter(type)}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap transition-colors ${
                    typeFilter === type
                      ? 'bg-blue-600 text-white'
                      : 'bg-[#12151C] text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {type.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2.5">
            {filteredFollowUps.map((event) => {
              const badge = getTypeBadge(event.type);

              return (
                <div
                  key={event.id}
                  className="p-3 rounded-lg bg-[#12151C] border border-slate-800 hover:border-slate-700 transition-all space-y-2 shadow-sm"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase border ${badge.color}`}>
                          {badge.label}
                        </span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                            event.status === 'completed'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}
                        >
                          {event.status}
                        </span>
                      </div>

                      <h3 className="font-bold text-white text-xs mt-1.5">{event.title}</h3>
                      <p className="text-[11px] text-slate-400">
                        Lead: <strong className="text-white">{event.leadName}</strong> ({event.leadCompany})
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      {event.status === 'pending' && (
                        <button
                          onClick={() => updateFollowUpStatus(event.id, 'completed')}
                          className="flex items-center gap-1 px-2 py-1 rounded bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold cursor-pointer"
                        >
                          <CheckCircle2 className="h-3 w-3" />
                          <span>Mark Done</span>
                        </button>
                      )}
                      <button
                        onClick={() => deleteFollowUp(event.id)}
                        className="p-1 rounded bg-[#1A1E26] hover:bg-red-500/20 hover:text-red-300 text-slate-400 border border-slate-800 cursor-pointer"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  </div>

                  {/* Notes / Agenda */}
                  <p className="text-xs text-slate-400 bg-[#1A1E26] p-2.5 rounded-lg border border-slate-800">
                    {event.notes}
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-slate-400">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-slate-300 font-mono">
                        <Clock className="h-3 w-3 text-blue-400" />
                        {new Date(event.scheduledAt).toLocaleString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}{' '}
                        ({event.durationMinutes}m)
                      </span>
                      {event.meetingLink && (
                        <a
                          href={event.meetingLink}
                          target="_blank"
                          rel="noreferrer"
                          className="text-cyan-400 hover:underline flex items-center gap-1 font-medium"
                        >
                          <Video className="h-3 w-3" />
                          Join Meet
                        </a>
                      )}
                    </div>

                    <span className="text-[10px] text-slate-500 font-mono">
                      Rep: {event.assignedToName}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Automated Follow-Up Rules Engine (1 Col) */}
        <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm space-y-3.5">
          <div className="flex items-center gap-2">
            <Bot className="h-4 w-4 text-blue-400" />
            <h2 className="text-xs font-bold text-white uppercase tracking-wider">Automated Cadence Rules</h2>
          </div>
          <p className="text-xs text-slate-400">
            Rules governing real-time AI autonomous follow-up and booking triggers.
          </p>

          <div className="space-y-2.5">
            {[
              {
                title: 'High-Intent Inbound Fast Response',
                trigger: 'When lead score >= 80 from website form',
                action: 'AI sends personalized email within 5 minutes & suggests 2 calendar times.',
                active: true,
              },
              {
                title: 'Social DM Auto-Qualifier',
                trigger: 'When prospect asks about pricing on LinkedIn/X',
                action: 'AI replies with pricing link and captures email address.',
                active: true,
              },
              {
                title: 'Post-Demo Follow-Up Sequence',
                trigger: '24 hours after demo completion',
                action: 'AI sends recap deck and enterprise agreement draft.',
                active: true,
              },
              {
                title: 'Dormant Lead Re-engagement',
                trigger: '14 days of inactivity',
                action: 'AI shares latest case study & industry benchmark.',
                active: false,
              },
            ].map((rule, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800 space-y-1 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{rule.title}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[8px] font-bold uppercase ${
                      rule.active
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {rule.active ? 'ENABLED' : 'PAUSED'}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px]">
                  <strong className="text-blue-400 font-medium">Trigger:</strong> {rule.trigger}
                </p>
                <p className="text-slate-300 text-[11px]">
                  <strong className="text-cyan-400 font-medium">Action:</strong> {rule.action}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
