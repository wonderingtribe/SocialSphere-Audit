'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { SocialPlatform, SocialPost, Campaign } from '@/types';
import {
  Sparkles,
  Megaphone,
  Plus,
  Clock,
  Send,
  Calendar,
  Layers,
  Trash2,
  Edit,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Share2,
  ExternalLink,
  Bot,
  Zap,
  Globe,
  Sliders,
  Copy,
  Check,
} from 'lucide-react';

interface CampaignsViewProps {
  onOpenNewPost: () => void;
  onOpenNewCampaign: () => void;
}

export const CampaignsView: React.FC<CampaignsViewProps> = ({
  onOpenNewPost,
  onOpenNewCampaign,
}) => {
  const {
    campaigns,
    posts,
    publishPostNow,
    deletePost,
    togglePostAutopilot,
    deleteCampaign,
    updateCampaignStatus,
  } = useApp();

  const [activePlatformFilter, setActivePlatformFilter] = useState<string>('all');
  const [copiedPostId, setCopiedPostId] = useState<string | null>(null);

  const filteredPosts = posts.filter((p) => {
    if (activePlatformFilter === 'all') return true;
    return p.platform === activePlatformFilter;
  });

  const scheduledCount = posts.filter((p) => p.status === 'scheduled').length;
  const publishedCount = posts.filter((p) => p.status === 'published').length;

  const handleCopyContent = (postId: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedPostId(postId);
    setTimeout(() => setCopiedPostId(null), 2000);
  };

  const getPlatformIconColor = (platform: SocialPlatform) => {
    switch (platform) {
      case 'twitter':
        return 'bg-sky-500/20 text-sky-400 border-sky-500/30';
      case 'linkedin':
        return 'bg-blue-600/20 text-blue-400 border-blue-600/30';
      case 'instagram':
        return 'bg-pink-500/20 text-pink-400 border-pink-500/30';
      case 'tiktok':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'facebook':
        return 'bg-indigo-600/20 text-indigo-400 border-indigo-600/30';
      case 'threads':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'youtube':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-slate-700 text-slate-300';
    }
  };

  return (
    <div className="space-y-4 pb-10">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-600/10 text-blue-400 border border-blue-500/20">
              Omnichannel Strategy
            </span>
            <span className="text-[11px] text-slate-400">
              Generative AI Post Queue & Custom Prompt Campaigns
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-1">
            Social Campaigns & Scheduled Content Queue
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure prompt instructions, scheduled intervals, and autonomous social media posting across all connected channels.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="campaigns-new-post"
            onClick={onOpenNewPost}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 text-blue-200" />
            <span>AI Quick Post</span>
          </button>

          <button
            id="campaigns-new-campaign"
            onClick={onOpenNewCampaign}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 text-slate-400" />
            <span>New Campaign</span>
          </button>
        </div>
      </div>

      {/* Active Campaigns Overview Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Megaphone className="h-4 w-4 text-blue-400" />
            Active Campaigns ({campaigns.length})
          </h2>
          <span className="text-[10px] uppercase font-bold text-slate-500">Targeted lead acquisition</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {campaigns.map((camp) => (
            <div
              key={camp.id}
              className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 shadow-sm space-y-3"
            >
              <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2.5">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm">{camp.title}</h3>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                        camp.status === 'active'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {camp.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Target: <strong className="text-slate-200">{camp.targetAudience}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() =>
                      updateCampaignStatus(
                        camp.id,
                        camp.status === 'active' ? 'paused' : 'active'
                      )
                    }
                    className="px-2 py-1 rounded bg-[#12151C] hover:bg-slate-800 text-[10px] font-bold text-slate-300 border border-slate-800 cursor-pointer"
                  >
                    {camp.status === 'active' ? 'Pause' : 'Resume'}
                  </button>
                  <button
                    onClick={() => deleteCampaign(camp.id)}
                    className="p-1 rounded bg-[#12151C] hover:bg-red-500/20 hover:text-red-300 text-slate-400 border border-slate-800 cursor-pointer"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </div>

              {camp.customInstructions && (
                <div className="p-2 rounded-lg bg-[#12151C] border border-slate-800 text-xs text-slate-300 leading-relaxed">
                  <span className="text-blue-400 font-bold text-[10px] uppercase tracking-wider block mb-0.5">
                    Prompt Strategy Instructions:
                  </span>
                  &ldquo;{camp.customInstructions}&rdquo;
                </div>
              )}

              {/* Campaign Stats Matrix */}
              <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                <div className="p-2 rounded bg-[#12151C] border border-slate-800/80">
                  <span className="text-[9px] text-slate-500 font-bold uppercase block">Impressions</span>
                  <span className="text-xs font-bold text-white mt-0.5 block">
                    {(camp.metrics.totalImpressions / 1000).toFixed(1)}k
                  </span>
                </div>
                <div className="p-2 rounded bg-[#12151C] border border-slate-800/80">
                  <span className="text-[9px] text-slate-500 font-bold uppercase block">Clicks</span>
                  <span className="text-xs font-bold text-blue-400 mt-0.5 block">
                    {camp.metrics.totalClicks.toLocaleString()}
                  </span>
                </div>
                <div className="p-2 rounded bg-[#12151C] border border-slate-800/80">
                  <span className="text-[9px] text-slate-500 font-bold uppercase block">Leads</span>
                  <span className="text-xs font-bold text-emerald-400 mt-0.5 block">
                    {camp.metrics.leadsCaptured}
                  </span>
                </div>
                <div className="p-2 rounded bg-[#12151C] border border-slate-800/80">
                  <span className="text-[9px] text-slate-500 font-bold uppercase block">Revenue</span>
                  <span className="text-xs font-bold text-indigo-400 mt-0.5 block">
                    ${(camp.metrics.revenueGenerated / 1000).toFixed(1)}k
                  </span>
                </div>
              </div>

              {/* Target Platforms */}
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/80">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Channels:</span>
                  {camp.platforms.map((plat) => (
                    <span
                      key={plat}
                      className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase border ${getPlatformIconColor(
                        plat
                      )}`}
                    >
                      {plat}
                    </span>
                  ))}
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  {camp.scheduledStartDate} → {camp.scheduledEndDate}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Content Scheduling Queue Section */}
      <div className="bg-[#1A1E26] rounded-xl border border-slate-800 p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="h-4 w-4 text-emerald-400" />
              Automated Publishing Queue ({posts.length})
            </h2>
            <p className="text-[11px] text-slate-500">
              {scheduledCount} scheduled for release · {publishedCount} live on social networks
            </p>
          </div>

          {/* Platform Filters */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 max-w-full">
            {['all', 'twitter', 'linkedin', 'instagram', 'tiktok', 'facebook', 'threads'].map(
              (plat) => (
                <button
                  key={plat}
                  onClick={() => setActivePlatformFilter(plat)}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase whitespace-nowrap transition-colors ${
                    activePlatformFilter === plat
                      ? 'bg-blue-600 text-white'
                      : 'bg-[#12151C] text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {plat}
                </button>
              )
            )}
          </div>
        </div>

        {/* Posts List */}
        <div className="space-y-2.5">
          {filteredPosts.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">
              No posts found for this platform filter.
            </div>
          ) : (
            filteredPosts.map((post) => (
              <div
                key={post.id}
                className="p-3.5 rounded-lg bg-[#12151C] border border-slate-800 hover:border-slate-700 transition-all space-y-2.5"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase border ${getPlatformIconColor(
                        post.platform
                      )}`}
                    >
                      {post.platform}
                    </span>
                    {post.campaignTitle && (
                      <span className="text-[11px] text-slate-400 font-medium">
                        Campaign: <strong className="text-slate-200">{post.campaignTitle}</strong>
                      </span>
                    )}
                    <span
                      className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                        post.status === 'published'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                      }`}
                    >
                      {post.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Autopilot toggle */}
                    <button
                      onClick={() => togglePostAutopilot(post.id)}
                      title={post.autoPilot ? 'Autopilot Enabled' : 'Autopilot Disabled'}
                      className={`px-2 py-1 rounded text-[9px] font-bold uppercase border flex items-center gap-1 transition-colors cursor-pointer ${
                        post.autoPilot
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : 'bg-[#0B0D11] text-slate-400 border-slate-800'
                      }`}
                    >
                      <Bot className="h-3 w-3" />
                      <span>{post.autoPilot ? 'Autopilot' : 'Manual'}</span>
                    </button>

                    {/* Publish Now if scheduled */}
                    {post.status === 'scheduled' && (
                      <button
                        onClick={() => publishPostNow(post.id)}
                        className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold uppercase flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Send className="h-3 w-3" />
                        <span>Post Now</span>
                      </button>
                    )}

                    {/* Copy button */}
                    <button
                      onClick={() => handleCopyContent(post.id, post.content)}
                      className="p-1 rounded bg-[#0B0D11] hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
                      title="Copy Post Content"
                    >
                      {copiedPostId === post.id ? (
                        <Check className="h-3 w-3 text-emerald-400" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </button>

                    {/* Delete button */}
                    <button
                      onClick={() => deletePost(post.id)}
                      className="p-1 rounded bg-[#0B0D11] hover:bg-red-500/20 hover:text-red-300 text-slate-400 border border-slate-800 cursor-pointer"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>

                {/* Post Content */}
                <div className="text-xs text-slate-300 whitespace-pre-line leading-relaxed bg-[#0B0D11] p-3 rounded border border-slate-800">
                  {post.content}
                </div>

                {/* Hashtags & CTA Link */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-400">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {post.hashtags.map((ht, idx) => (
                      <span key={idx} className="text-blue-400 font-semibold">
                        #{ht}
                      </span>
                    ))}
                    {post.ctaUrl && (
                      <span className="text-emerald-400 flex items-center gap-1 ml-2 font-mono">
                        <Globe className="h-3 w-3" />
                        {post.ctaUrl}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    {post.status === 'published' ? (
                      <div className="flex items-center gap-3 text-slate-400 font-medium">
                        <span>👁️ {post.engagement.impressions.toLocaleString()}</span>
                        <span>❤️ {post.engagement.likes}</span>
                        <span>🔄 {post.engagement.reposts}</span>
                        <span>🎯 {post.engagement.clicks} clicks</span>
                        <span className="text-emerald-400 font-bold">
                          +{post.engagement.leadsGenerated} leads
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 text-slate-500 font-mono">
                        <Clock className="h-3 w-3 text-blue-400" />
                        <span>Scheduled: {new Date(post.scheduledFor).toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
