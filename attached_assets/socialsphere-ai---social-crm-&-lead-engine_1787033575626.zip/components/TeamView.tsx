'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import {
  Users,
  Shield,
  Clock,
  DollarSign,
  TrendingUp,
  Award,
  CheckCircle2,
  Mail,
  Zap,
  UserPlus,
} from 'lucide-react';

export const TeamView: React.FC = () => {
  const { teamMembers, leads } = useApp();

  return (
    <div className="space-y-4 pb-10">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Team Collaboration & Sales Routing
            </span>
            <span className="text-[11px] text-slate-400">
              {teamMembers.length} Active Team Members
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-1">
            Team Workspace & Lead Allocation
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Round-robin lead routing, real-time workload balancing, speed-to-lead benchmarks, and team performance.
          </p>
        </div>

        <button
          onClick={() => alert('Invite member modal triggered')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
        >
          <UserPlus className="h-3.5 w-3.5 text-blue-200" />
          <span>Invite Member</span>
        </button>
      </div>

      {/* Team Directory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {teamMembers.map((member) => {
          const assignedLeads = leads.filter((l) => l.assignedTo === member.id);
          const closedWon = assignedLeads.filter((l) => l.status === 'won');
          const totalWonValue = closedWon.reduce((sum, l) => sum + l.estimatedValue, 0);

          return (
            <div
              key={member.id}
              className="bg-[#1A1E26] border border-slate-800 rounded-xl p-4 shadow-sm hover:border-slate-700 transition-all space-y-3"
            >
              <div className="flex items-center gap-3">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="h-10 w-10 rounded-full object-cover border border-slate-700"
                />
                <div>
                  <h3 className="font-bold text-white text-xs">{member.name}</h3>
                  <p className="text-[11px] text-slate-400">{member.role}</p>
                  <span className="text-[9px] text-blue-400 font-mono">{member.email}</span>
                </div>
              </div>

              {/* Performance Stats */}
              <div className="grid grid-cols-2 gap-1.5 text-xs pt-2 border-t border-slate-800">
                <div className="p-2 rounded bg-[#12151C] border border-slate-800">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Assigned</span>
                  <span className="text-xs font-bold text-white mt-0.5 block font-mono">
                    {assignedLeads.length} leads
                  </span>
                </div>

                <div className="p-2 rounded bg-[#12151C] border border-slate-800">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Closed</span>
                  <span className="text-xs font-bold text-emerald-400 mt-0.5 block font-mono">
                    {closedWon.length} ({member.dealsClosed})
                  </span>
                </div>

                <div className="p-2 rounded bg-[#12151C] border border-slate-800">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Avg Speed</span>
                  <span className="text-xs font-bold text-blue-300 mt-0.5 block font-mono">
                    {member.avgResponseTime}
                  </span>
                </div>

                <div className="p-2 rounded bg-[#12151C] border border-slate-800">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Conversion</span>
                  <span className="text-xs font-bold text-amber-400 mt-0.5 block font-mono">
                    {member.conversionRate}%
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500 text-[10px] uppercase font-bold">Total Closed:</span>
                <span className="text-white font-bold text-xs">${(totalWonValue / 1000).toFixed(1)}k</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Auto-Routing Configuration */}
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm space-y-3">
        <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Zap className="h-3.5 w-3.5 text-amber-400" />
          Lead Distribution & Routing Rules
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-lg bg-[#12151C] border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-xs">Round-Robin Distribution</span>
              <span className="px-1.5 py-0.2 rounded text-[8px] font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Inbound social leads and website webhook contacts are systematically distributed sequentially among active sales representatives.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-[#12151C] border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-xs">Enterprise Routing</span>
              <span className="px-1.5 py-0.2 rounded text-[8px] font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Leads with estimated value exceeding $15,000 or lead scores above 90 are automatically assigned to Senior Account Executives.
            </p>
          </div>

          <div className="p-3.5 rounded-lg bg-[#12151C] border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-xs">Speed-to-Lead SLA</span>
              <span className="px-1.5 py-0.2 rounded text-[8px] font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              If an inbound lead is uncontacted within 15 minutes, an urgent AI push notification is dispatched and reallocated to the on-call rep.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
