'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { SocialPlatform } from '@/types';
import {
  Key,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Copy,
  Check,
  Code,
  Globe,
  Zap,
  ExternalLink,
  Lock,
} from 'lucide-react';

export const IntegrationsView: React.FC = () => {
  const { socialAccounts, toggleAccountConnection } = useApp();
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [testingPlatform, setTestingPlatform] = useState<string | null>(null);

  const webhookUrl = 'https://api.omnilead.ai/v1/webhooks/inbound/wh_live_79a48f0e2b91';

  const handleCopyWebhook = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    setTimeout(() => setCopiedWebhook(false), 2000);
  };

  const handleTestConnection = (platform: string) => {
    setTestingPlatform(platform);
    setTimeout(() => {
      setTestingPlatform(null);
    }, 1200);
  };

  return (
    <div className="space-y-4 pb-10">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Secure API Gateway
            </span>
            <span className="text-[11px] text-slate-400">
              OAuth 2.0 & High-Throughput REST Connectors
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-1">
            Social APIs & Website Integration Center
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Connect your official social media developer credentials, Gmail inbox, Google Calendar, and website lead capture webhooks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20 font-mono">
            <ShieldCheck className="h-4 w-4" />
            256-Bit Encrypted
          </span>
        </div>
      </div>

      {/* Website Inbound Lead Capture Webhook */}
      <div className="bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-blue-400" />
            <h2 className="text-xs font-bold text-white uppercase tracking-wider">Website Inbound Lead Webhook</h2>
          </div>
          <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1.5 font-mono">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Gateway Active
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Connect your website contact forms (Webflow, WordPress, Next.js, Framer, Typeform). Any submission is scored by Gemini and immediately assigned to your sales reps.
        </p>

        {/* Endpoint Box */}
        <div className="flex items-center gap-2 bg-[#0B0D11] border border-slate-800 rounded-lg p-2 font-mono text-xs text-blue-400">
          <span className="text-emerald-400 font-bold text-[10px] px-1.5 py-0.5 bg-emerald-500/10 rounded">POST</span>
          <span className="flex-1 truncate text-slate-300">{webhookUrl}</span>
          <button
            onClick={handleCopyWebhook}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#1A1E26] hover:bg-slate-800 text-slate-200 rounded text-xs font-sans transition-colors cursor-pointer border border-slate-800"
          >
            {copiedWebhook ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copiedWebhook ? 'Copied!' : 'Copy'}</span>
          </button>
        </div>

        {/* cURL Example */}
        <details className="text-xs text-slate-400">
          <summary className="cursor-pointer hover:text-white font-medium text-[11px]">
            View Example JSON Payload
          </summary>
          <pre className="mt-2 p-3 bg-[#0B0D11] rounded-lg border border-slate-800 text-[11px] text-slate-300 overflow-x-auto font-mono">
{`curl -X POST ${webhookUrl} \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "Sarah Connor",
    "email": "sarah@cyberdyne.io",
    "company": "Cyberdyne",
    "message": "Interested in enterprise social automation pipeline",
    "source": "website_contact_form"
  }'`}
          </pre>
        </details>
      </div>

      {/* Social Network Connectors Grid */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Zap className="h-3.5 w-3.5 text-blue-400" />
          Connected Social Networks & Workspace APIs
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {socialAccounts.map((acc) => (
            <div
              key={acc.platform}
              className="bg-[#1A1E26] border border-slate-800 rounded-xl p-4 shadow-sm hover:border-slate-700 transition-all space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-xs capitalize">{acc.platform} API</h3>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[8px] font-bold uppercase ${
                        acc.connected
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-slate-800 text-slate-500 border border-slate-800'
                      }`}
                    >
                      {acc.connected ? 'CONNECTED' : 'DISCONNECTED'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 font-mono">{acc.handle}</p>
                </div>

                <button
                  onClick={() => toggleAccountConnection(acc.platform)}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                    acc.connected
                      ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20'
                      : 'bg-blue-600 hover:bg-blue-500 text-white'
                  }`}
                >
                  {acc.connected ? 'Disconnect' : 'Connect'}
                </button>
              </div>

              {/* Scope permissions */}
              <div className="space-y-1 pt-2 border-t border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Granted Scopes:</span>
                <div className="flex flex-wrap gap-1">
                  {acc.scopes.map((s, idx) => (
                    <span
                      key={idx}
                      className="px-1.5 py-0.2 rounded bg-[#12151C] border border-slate-800 text-slate-300 text-[9px] font-mono"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom status & test button */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                <span className="text-slate-500 text-[10px] font-mono">Synced: {acc.lastSync}</span>
                <button
                  onClick={() => handleTestConnection(acc.platform)}
                  disabled={testingPlatform === acc.platform}
                  className="text-blue-400 hover:text-blue-300 text-xs font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`h-3 w-3 ${testingPlatform === acc.platform ? 'animate-spin' : ''}`} />
                  <span>{testingPlatform === acc.platform ? 'Verifying...' : 'Ping Test'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
