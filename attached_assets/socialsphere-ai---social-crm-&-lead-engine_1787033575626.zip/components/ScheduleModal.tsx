'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { CalendarFollowUp } from '@/types';
import {
  Calendar,
  Clock,
  Video,
  User,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface ScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialLeadId?: string | null;
}

export const ScheduleModal: React.FC<ScheduleModalProps> = ({
  isOpen,
  onClose,
  initialLeadId,
}) => {
  const { leads, addFollowUp, teamMembers } = useApp();

  const [leadId, setLeadId] = useState(initialLeadId || (leads[0]?.id || ''));
  const [title, setTitle] = useState('15-Min Lead Discovery & Solution Walkthrough');
  const [type, setType] = useState<CalendarFollowUp['type']>('discovery_call');
  const [scheduledAt, setScheduledAt] = useState(() => {
    return new Date(Date.now() + 86400000).toISOString().slice(0, 16);
  });
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [notes, setNotes] = useState(
    'Review inbound requirements, demonstrate automated campaign capabilities, and align on timeline.'
  );
  const [assignedTo, setAssignedTo] = useState(teamMembers[0]?.id || 'team-1');

  if (!isOpen) return null;

  const selectedLead = leads.find((l) => l.id === leadId);
  const selectedMember = teamMembers.find((m) => m.id === assignedTo);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLead) return;

    addFollowUp({
      leadId: selectedLead.id,
      leadName: selectedLead.name,
      leadCompany: selectedLead.company,
      title,
      type,
      scheduledAt: new Date(scheduledAt).toISOString(),
      durationMinutes: Number(durationMinutes),
      assignedTo,
      assignedToName: selectedMember ? selectedMember.name : 'Sarah Chen',
      status: 'pending',
      meetingLink: 'https://meet.google.com/omn-lead-demo',
      notes,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D11]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-lg p-4 sm:p-5 shadow-2xl space-y-3.5 text-slate-200"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
              <Calendar className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Schedule Lead Follow-Up</h3>
              <p className="text-[11px] text-slate-400">
                Syncs directly to Google Calendar and updates CRM status
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded bg-[#12151C] border border-slate-800 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Select Lead *</label>
            <select
              value={leadId}
              onChange={(e) => setLeadId(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              {leads.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name} — {l.company} (${l.estimatedValue.toLocaleString()})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Meeting / Event Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Follow-Up Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="discovery_call">Discovery Call</option>
                <option value="demo">Product Demo</option>
                <option value="contract_review">Contract Review</option>
                <option value="automated_checkin">Automated Check-in</option>
                <option value="email_followup">Email Touchpoint</option>
              </select>
            </div>

            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Duration (Minutes)</label>
              <input
                type="number"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Date & Time *</label>
              <input
                type="datetime-local"
                required
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Assigned Sales Rep</label>
              <select
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {teamMembers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="font-bold uppercase text-[10px] text-slate-400 block mb-1">Agenda & Internal Notes</label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#12151C] border border-slate-800 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
            >
              Save to Calendar
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
