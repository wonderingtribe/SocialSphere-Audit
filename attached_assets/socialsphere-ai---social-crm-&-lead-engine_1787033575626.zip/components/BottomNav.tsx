'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import {
  LayoutDashboard,
  Megaphone,
  Users,
  Mail,
  Calendar,
  Layers,
  Key,
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, emails, leads } = useApp();

  const unreadEmails = emails.filter((e) => !e.read).length;
  const newLeads = leads.filter((l) => l.status === 'new').length;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0B0D11]/95 backdrop-blur-lg border-t border-slate-800 lg:hidden text-slate-400">
      <div className="flex items-center justify-around h-14 max-w-lg mx-auto px-2">
        <button
          id="mobile-tab-dashboard"
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'dashboard' ? 'text-blue-400 font-semibold' : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <LayoutDashboard className="h-4 w-4" />
          <span className="text-[10px] mt-0.5 font-medium">Metrics</span>
        </button>

        <button
          id="mobile-tab-campaigns"
          onClick={() => setActiveTab('campaigns')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'campaigns' ? 'text-blue-400 font-semibold' : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Megaphone className="h-4 w-4" />
          <span className="text-[10px] mt-0.5 font-medium">Social</span>
        </button>

        <button
          id="mobile-tab-leads"
          onClick={() => setActiveTab('leads')}
          className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
            activeTab === 'leads' ? 'text-blue-400 font-semibold' : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Users className="h-4 w-4" />
          {newLeads > 0 && (
            <span className="absolute top-1 right-3 h-2 w-2 rounded-full bg-emerald-400" />
          )}
          <span className="text-[10px] mt-0.5 font-medium">CRM</span>
        </button>

        <button
          id="mobile-tab-messages"
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
            activeTab === 'messages' ? 'text-blue-400 font-semibold' : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Mail className="h-4 w-4" />
          {unreadEmails > 0 && (
            <span className="absolute top-1 right-3 h-3.5 w-3.5 rounded-full bg-blue-600 text-white text-[9px] font-bold flex items-center justify-center">
              {unreadEmails}
            </span>
          )}
          <span className="text-[10px] mt-0.5 font-medium">Gmail</span>
        </button>

        <button
          id="mobile-tab-calendar"
          onClick={() => setActiveTab('calendar')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'calendar' ? 'text-blue-400 font-semibold' : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span className="text-[10px] mt-0.5 font-medium">Schedule</span>
        </button>

        <button
          id="mobile-tab-integrations"
          onClick={() => setActiveTab('integrations')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'integrations' ? 'text-blue-400 font-semibold' : 'text-slate-500 hover:text-slate-300'
          }`}
        >
          <Key className="h-4 w-4" />
          <span className="text-[10px] mt-0.5 font-medium">APIs</span>
        </button>
      </div>
    </nav>
  );
};
