'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Lead, LeadStatus, SocialPlatform } from '@/types';
import {
  Users,
  Plus,
  Filter,
  Search,
  MoreVertical,
  Mail,
  Phone,
  Building,
  Calendar,
  DollarSign,
  TrendingUp,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  Trash2,
  Clock,
  ArrowRight,
  Send,
  Globe,
  Tag,
  Kanban,
  Table as TableIcon,
  UserCheck,
} from 'lucide-react';

interface LeadsViewProps {
  onOpenEmailModal: (leadId: string) => void;
  onOpenScheduleModal: (leadId: string) => void;
  selectedLeadId: string | null;
  onSelectLead: (leadId: string | null) => void;
}

const STAGES: { id: LeadStatus; label: string; color: string; border: string }[] = [
  { id: 'new', label: 'New Inbound', color: 'bg-blue-500/10 text-blue-300', border: 'border-blue-500/30' },
  { id: 'contacted', label: 'Contacted', color: 'bg-amber-500/10 text-amber-300', border: 'border-amber-500/30' },
  { id: 'meeting_scheduled', label: 'Meeting Booked', color: 'bg-purple-500/10 text-purple-300', border: 'border-purple-500/30' },
  { id: 'qualified', label: 'Qualified Opportunity', color: 'bg-cyan-500/10 text-cyan-300', border: 'border-cyan-500/30' },
  { id: 'won', label: 'Closed Won 🎉', color: 'bg-emerald-500/10 text-emerald-300', border: 'border-emerald-500/30' },
  { id: 'lost', label: 'Archived / Lost', color: 'bg-slate-700/50 text-slate-400', border: 'border-slate-700' },
];

export const LeadsView: React.FC<LeadsViewProps> = ({
  onOpenEmailModal,
  onOpenScheduleModal,
  selectedLeadId,
  onSelectLead,
}) => {
  const {
    leads,
    updateLeadStatus,
    assignLead,
    addLeadNote,
    deleteLead,
    teamMembers,
    addLead,
  } = useApp();

  const [viewType, setViewType] = useState<'kanban' | 'table'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState<string>('all');
  const [newNoteContent, setNewNoteContent] = useState('');
  const [isAddLeadOpen, setIsAddLeadOpen] = useState(false);

  // New lead form state
  const [newLeadForm, setNewLeadForm] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    role: '',
    sourcePlatform: 'linkedin' as SocialPlatform,
    leadScore: 85,
    status: 'new' as LeadStatus,
    assignedTo: teamMembers[0]?.id || 'team-1',
    assignedToName: teamMembers[0]?.name || 'Sarah Chen',
    estimatedValue: 12000,
    industry: 'Technology & SaaS',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    tags: 'Hot Inbound, Enterprise',
  });

  const selectedLead = leads.find((l) => l.id === selectedLeadId);

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch =
      lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPlatform = platformFilter === 'all' || lead.sourcePlatform === platformFilter;
    return matchesSearch && matchesPlatform;
  });

  const handleCreateLead = (e: React.FormEvent) => {
    e.preventDefault();
    const assignedMember = teamMembers.find((m) => m.id === newLeadForm.assignedTo);
    addLead({
      name: newLeadForm.name,
      email: newLeadForm.email,
      phone: newLeadForm.phone,
      company: newLeadForm.company,
      role: newLeadForm.role,
      sourcePlatform: newLeadForm.sourcePlatform,
      leadScore: Number(newLeadForm.leadScore),
      status: newLeadForm.status,
      assignedTo: newLeadForm.assignedTo,
      assignedToName: assignedMember ? assignedMember.name : 'Sarah Chen',
      estimatedValue: Number(newLeadForm.estimatedValue),
      industry: newLeadForm.industry,
      avatar: newLeadForm.avatar,
      tags: newLeadForm.tags.split(',').map((t) => t.trim()).filter(Boolean),
    });
    setIsAddLeadOpen(false);
    setNewLeadForm({
      name: '',
      email: '',
      phone: '',
      company: '',
      role: '',
      sourcePlatform: 'linkedin',
      leadScore: 85,
      status: 'new',
      assignedTo: teamMembers[0]?.id || 'team-1',
      assignedToName: teamMembers[0]?.name || 'Sarah Chen',
      estimatedValue: 12000,
      industry: 'Technology & SaaS',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      tags: 'Hot Inbound, Enterprise',
    });
  };

  const handleAddNote = (leadId: string) => {
    if (!newNoteContent.trim()) return;
    addLeadNote(leadId, newNoteContent);
    setNewNoteContent('');
  };

  return (
    <div className="space-y-4 pb-10">
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#1A1E26] border border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Lead Intelligence & CRM
            </span>
            <span className="text-[11px] text-slate-400">
              {leads.length} Active Inbound Opportunities
            </span>
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight mt-1">
            OmniLead CRM & Deal Pipeline Matrix
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated lead qualification scores, touchpoint tracking, direct Gmail sync, and rep routing.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* View Toggle */}
          <div className="flex items-center bg-[#12151C] p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setViewType('kanban')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase flex items-center gap-1 transition-colors ${
                viewType === 'kanban' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Kanban Board View"
            >
              <Kanban className="h-3.5 w-3.5" />
              <span>Kanban</span>
            </button>
            <button
              onClick={() => setViewType('table')}
              className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase flex items-center gap-1 transition-colors ${
                viewType === 'table' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Data Table View"
            >
              <TableIcon className="h-3.5 w-3.5" />
              <span>Table</span>
            </button>
          </div>

          <button
            id="leads-add-lead-btn"
            onClick={() => setIsAddLeadOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5 text-blue-200" />
            <span>Add Lead</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#1A1E26] border border-slate-800 rounded-xl p-3 shadow-sm">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search leads by name, company, email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#12151C] border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto">
          <span className="text-[10px] uppercase font-bold text-slate-500 whitespace-nowrap">Source:</span>
          {['all', 'linkedin', 'twitter', 'instagram', 'tiktok'].map((plat) => (
            <button
              key={plat}
              onClick={() => setPlatformFilter(plat)}
              className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase whitespace-nowrap transition-colors ${
                platformFilter === plat
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#12151C] text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {plat}
            </button>
          ))}
        </div>
      </div>

      {/* Main CRM Views */}
      {viewType === 'kanban' ? (
        /* Kanban Pipeline Columns */
        <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-6 gap-3 overflow-x-auto pb-4">
          {STAGES.map((stage) => {
            const stageLeads = filteredLeads.filter((l) => l.status === stage.id);
            const stageTotalValue = stageLeads.reduce((sum, l) => sum + l.estimatedValue, 0);

            return (
              <div
                key={stage.id}
                className="bg-[#1A1E26] border border-slate-800 rounded-xl p-3 flex flex-col min-w-[240px] space-y-2.5 shadow-sm"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div>
                    <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase border ${stage.color} ${stage.border}`}>
                      {stage.label}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-1 font-bold">
                      ({stageLeads.length})
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-slate-300 font-mono">
                    ${(stageTotalValue / 1000).toFixed(1)}k
                  </span>
                </div>

                {/* Lead Cards inside Column */}
                <div className="space-y-2 flex-1 min-h-[140px]">
                  {stageLeads.map((lead) => (
                    <div
                      key={lead.id}
                      onClick={() => onSelectLead(lead.id)}
                      className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800 hover:border-blue-500/40 hover:bg-slate-800/40 transition-all cursor-pointer space-y-2 shadow-sm"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <img
                            src={lead.avatar}
                            alt={lead.name}
                            className="h-7 w-7 rounded-full object-cover border border-slate-700 shrink-0"
                          />
                          <div>
                            <h4 className="text-xs font-bold text-white hover:text-blue-400 transition-colors">
                              {lead.name}
                            </h4>
                            <p className="text-[10px] text-slate-400 truncate max-w-[120px]">
                              {lead.company}
                            </p>
                          </div>
                        </div>

                        <span
                          className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                            lead.leadScore >= 90
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : lead.leadScore >= 75
                              ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {lead.leadScore}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                        <span className="font-bold text-white font-mono">
                          ${lead.estimatedValue.toLocaleString()}
                        </span>
                        <span className="uppercase text-[9px] bg-[#0B0D11] border border-slate-800 px-1 py-0.2 rounded text-slate-400 font-bold">
                          {lead.sourcePlatform}
                        </span>
                      </div>

                      {/* Quick stage mover */}
                      <div className="flex items-center justify-between pt-0.5 text-[9px]">
                        <span className="text-slate-500 font-mono">Rep: {lead.assignedToName.split(' ')[0]}</span>
                        <select
                          value={lead.status}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) => updateLeadStatus(lead.id, e.target.value as LeadStatus)}
                          className="bg-[#0B0D11] border border-slate-800 text-slate-300 text-[9px] rounded px-1 py-0.5 focus:outline-none"
                        >
                          {STAGES.map((s) => (
                            <option key={s.id} value={s.id}>
                              → {s.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Data Table View */
        <div className="bg-[#1A1E26] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#12151C] text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Lead Name & Company</th>
                  <th className="py-3 px-4">Lead Score</th>
                  <th className="py-3 px-4">Pipeline Stage</th>
                  <th className="py-3 px-4">Source</th>
                  <th className="py-3 px-4">Deal Value</th>
                  <th className="py-3 px-4">Assigned Rep</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredLeads.map((lead) => (
                  <tr
                    key={lead.id}
                    onClick={() => onSelectLead(lead.id)}
                    className="hover:bg-[#12151C]/60 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={lead.avatar}
                          alt={lead.name}
                          className="h-8 w-8 rounded-full object-cover border border-slate-700 shrink-0"
                        />
                        <div>
                          <div className="font-bold text-white text-xs">{lead.name}</div>
                          <div className="text-[11px] text-slate-400">
                            {lead.role} · {lead.company}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                          lead.leadScore >= 90
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : lead.leadScore >= 75
                            ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {lead.leadScore} / 100
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={lead.status}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) => updateLeadStatus(lead.id, e.target.value as LeadStatus)}
                        className="bg-[#12151C] border border-slate-800 text-slate-200 text-xs rounded-lg px-2 py-1 focus:outline-none"
                      >
                        {STAGES.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="py-3 px-4 capitalize font-medium text-slate-300">{lead.sourcePlatform}</td>
                    <td className="py-3 px-4 font-bold text-white font-mono">
                      ${lead.estimatedValue.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-slate-300">{lead.assignedToName}</td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onOpenEmailModal(lead.id)}
                          className="p-1.5 rounded bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/30"
                          title="Send Email via Gmail"
                        >
                          <Mail className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onOpenScheduleModal(lead.id)}
                          className="p-1.5 rounded bg-purple-600/10 hover:bg-purple-600/20 text-purple-400 border border-purple-500/30"
                          title="Schedule Follow-up"
                        >
                          <Calendar className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => deleteLead(lead.id)}
                          className="p-1.5 rounded bg-[#12151C] hover:bg-red-500/20 hover:text-red-300 text-slate-400 border border-slate-800"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Selected Lead Slide-Over / Modal Details */}
      {selectedLead && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl space-y-4 text-slate-200">
            {/* Lead Header */}
            <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <img
                  src={selectedLead.avatar}
                  alt={selectedLead.name}
                  className="h-12 w-12 rounded-full object-cover border-2 border-blue-500/40 shadow-lg"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-white">{selectedLead.name}</h2>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      Score: {selectedLead.leadScore}/100
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    {selectedLead.role} at <strong className="text-white">{selectedLead.company}</strong>
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {selectedLead.email} · {selectedLead.phone || 'No phone'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onSelectLead(null)}
                className="p-1 rounded bg-[#12151C] hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Quick Action Bar for Lead */}
            <div className="flex items-center gap-2 flex-wrap bg-[#12151C] p-3 rounded-lg border border-slate-800">
              <button
                onClick={() => {
                  onSelectLead(null);
                  onOpenEmailModal(selectedLead.id);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
              >
                <Mail className="h-3.5 w-3.5" />
                <span>Compose AI Email</span>
              </button>

              <button
                onClick={() => {
                  onSelectLead(null);
                  onOpenScheduleModal(selectedLead.id);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1A1E26] hover:bg-slate-800 border border-slate-700 text-white text-xs font-bold cursor-pointer"
              >
                <Calendar className="h-3.5 w-3.5 text-blue-400" />
                <span>Book Calendar Demo</span>
              </button>

              {/* Stage Selector */}
              <div className="flex items-center gap-1.5 ml-auto">
                <span className="text-[10px] uppercase font-bold text-slate-400">Stage:</span>
                <select
                  value={selectedLead.status}
                  onChange={(e) => updateLeadStatus(selectedLead.id, e.target.value as LeadStatus)}
                  className="bg-[#0B0D11] border border-slate-800 text-white text-xs rounded-lg px-2 py-1 font-bold focus:outline-none"
                >
                  {STAGES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Lead Details Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Deal Value</span>
                <span className="text-white font-bold text-sm block mt-0.5 font-mono">
                  ${selectedLead.estimatedValue.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Origin</span>
                <span className="text-blue-400 font-bold uppercase text-xs block mt-0.5">
                  {selectedLead.sourcePlatform}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Industry</span>
                <span className="text-white font-medium text-xs block mt-0.5 truncate">
                  {selectedLead.industry || 'B2B Software'}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Assigned Rep</span>
                <select
                  value={selectedLead.assignedTo}
                  onChange={(e) => assignLead(selectedLead.id, e.target.value)}
                  className="w-full bg-[#0B0D11] border border-slate-800 text-slate-200 text-xs rounded mt-0.5 py-0.5 focus:outline-none"
                >
                  {teamMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Website Interaction Tracking Log */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Globe className="h-3.5 w-3.5 text-blue-400" />
                Website Behavior & Live Tracking History
              </h4>
              <div className="bg-[#12151C] rounded-lg p-3 border border-slate-800 space-y-1.5 text-xs">
                {selectedLead.websiteInteractions.map((inter, idx) => (
                  <div key={idx} className="flex items-center justify-between text-slate-300">
                    <span className="font-mono text-blue-400 text-xs">{inter.page}</span>
                    <span className="text-slate-400 text-[11px] font-mono">
                      Spent {inter.timeSpentSeconds}s · {new Date(inter.visitedAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Internal Team Collaboration Notes */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <MessageSquare className="h-3.5 w-3.5 text-blue-400" />
                Team Collaboration & Activity Notes ({selectedLead.notes.length})
              </h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {selectedLead.notes.map((note) => (
                  <div
                    key={note.id}
                    className="p-2.5 rounded-lg bg-[#12151C] border border-slate-800 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-white">{note.authorName}</span>
                      <span className="text-slate-500 font-mono text-[10px]">{new Date(note.createdAt).toLocaleString()}</span>
                    </div>
                    <p className="text-slate-300 text-xs">{note.content}</p>
                  </div>
                ))}
              </div>

              {/* Add Note Input */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="text"
                  placeholder="Add internal note or mention team rep..."
                  value={newNoteContent}
                  onChange={(e) => setNewNoteContent(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddNote(selectedLead.id)}
                  className="flex-1 bg-[#12151C] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  onClick={() => handleAddNote(selectedLead.id)}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold cursor-pointer"
                >
                  Post Note
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Lead Modal */}
      {isAddLeadOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateLead}
            className="bg-[#1A1E26] border border-slate-800 rounded-xl w-full max-w-lg p-5 sm:p-6 shadow-2xl space-y-4 text-slate-200"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white">Add New Inbound Lead</h3>
              <button
                type="button"
                onClick={() => setIsAddLeadOpen(false)}
                className="p-1 rounded bg-[#12151C] text-slate-400 hover:text-white border border-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={newLeadForm.name}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, name: e.target.value })}
                  placeholder="e.g. Alex Morgan"
                  className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Email *</label>
                <input
                  type="email"
                  required
                  value={newLeadForm.email}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, email: e.target.value })}
                  placeholder="alex@company.com"
                  className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Company *</label>
                <input
                  type="text"
                  required
                  value={newLeadForm.company}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, company: e.target.value })}
                  placeholder="e.g. Acme Labs"
                  className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Job Role</label>
                <input
                  type="text"
                  value={newLeadForm.role}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, role: e.target.value })}
                  placeholder="e.g. VP Growth"
                  className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Source Platform</label>
                <select
                  value={newLeadForm.sourcePlatform}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, sourcePlatform: e.target.value as SocialPlatform })}
                  className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none capitalize"
                >
                  {['linkedin', 'twitter', 'instagram', 'tiktok', 'facebook'].map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Estimated Value ($)</label>
                <input
                  type="number"
                  value={newLeadForm.estimatedValue}
                  onChange={(e) => setNewLeadForm({ ...newLeadForm, estimatedValue: Number(e.target.value) })}
                  className="w-full bg-[#12151C] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddLeadOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-[#12151C] hover:bg-slate-800 text-xs font-bold text-slate-400 border border-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white shadow-sm cursor-pointer"
              >
                Save Lead
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
