export type SocialPlatform =
  | 'twitter'
  | 'linkedin'
  | 'instagram'
  | 'facebook'
  | 'tiktok'
  | 'threads'
  | 'youtube';

export type LeadStatus =
  | 'new'
  | 'contacted'
  | 'meeting_scheduled'
  | 'qualified'
  | 'won'
  | 'lost';

export type PostStatus = 'draft' | 'scheduled' | 'published' | 'failed';

export type CampaignGoal =
  | 'lead_gen'
  | 'traffic'
  | 'sales'
  | 'brand_awareness'
  | 'webinar_signups';

export type CampaignTone =
  | 'persuasive'
  | 'professional'
  | 'conversational'
  | 'urgent'
  | 'storytelling'
  | 'viral_hook';

export interface SocialPost {
  id: string;
  campaignId?: string;
  campaignTitle?: string;
  platform: SocialPlatform;
  content: string;
  hashtags: string[];
  ctaUrl?: string;
  scheduledFor: string; // ISO string
  publishedAt?: string;
  status: PostStatus;
  autoPilot: boolean;
  engagement: {
    impressions: number;
    likes: number;
    reposts: number;
    comments: number;
    clicks: number;
    leadsGenerated: number;
  };
  aiPromptUsed?: string;
  suggestedImagePrompt?: string;
  createdAt: string;
}

export interface LeadNote {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
}

export interface WebsiteInteraction {
  page: string;
  timeSpentSeconds: number;
  visitedAt: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  company: string;
  role: string;
  avatar: string;
  sourcePlatform: SocialPlatform | 'website_direct' | 'organic_search' | 'email_outreach';
  sourcePostId?: string;
  websiteInteractions: WebsiteInteraction[];
  leadScore: number; // 0 to 100
  status: LeadStatus;
  assignedTo: string; // TeamMember id
  assignedToName: string;
  estimatedValue: number;
  industry?: string;
  notes: LeadNote[];
  lastContactedAt?: string;
  createdAt: string;
  tags: string[];
}

export interface EmailMessage {
  id: string;
  leadId: string;
  leadName: string;
  leadEmail: string;
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  isIncoming: boolean;
  timestamp: string;
  read: boolean;
  status: 'sent' | 'received' | 'draft';
  threadId: string;
  aiSuggestedReply?: string;
}

export interface CalendarFollowUp {
  id: string;
  leadId: string;
  leadName: string;
  leadEmail: string;
  leadCompany: string;
  title: string;
  description: string;
  startDateTime: string; // ISO string
  endDateTime: string; // ISO string
  type: 'discovery_call' | 'demo' | 'followup_email' | 'contract_review' | 'strategy_session';
  meetingLink?: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  reminderMinutesBefore: number;
  assignedTo: string; // TeamMember id
  assignedToName: string;
  autoSequenceFollowup?: boolean;
}

export interface Campaign {
  id: string;
  title: string;
  websiteUrl: string;
  targetAudience: string;
  goal: CampaignGoal;
  tone: CampaignTone;
  customInstructions: string;
  platforms: SocialPlatform[];
  postsCount: number;
  scheduledStartDate: string;
  scheduledEndDate: string;
  status: 'active' | 'draft' | 'paused' | 'completed';
  metrics: {
    totalImpressions: number;
    totalClicks: number;
    leadsCaptured: number;
    conversions: number;
    conversionRate: number;
    revenueGenerated: number;
  };
  createdAt: string;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'Lead Strategist' | 'Account Executive' | 'SDR / Outreach' | 'Marketing Manager' | 'AI Admin';
  avatar: string;
  assignedLeadsCount: number;
  closedLeadsCount: number;
  conversionRate: number; // percentage
  avgResponseTimeMin: number;
  status: 'online' | 'busy' | 'offline';
}

export interface SocialAccountConnection {
  platform: SocialPlatform;
  name: string;
  connected: boolean;
  handle: string;
  followersCount: number;
  apiKeyConfigured: boolean;
  rateLimitRemaining?: number;
  lastSync?: string;
}

export interface PerformanceDayMetric {
  date: string;
  impressions: number;
  clicks: number;
  leads: number;
  conversions: number;
  revenue: number;
  engagementRate: number;
  conversionRate: number;
}

export interface LiveActivityFeedItem {
  id: string;
  type: 'lead_captured' | 'post_published' | 'high_engagement' | 'meeting_booked' | 'email_received' | 'deal_won';
  title: string;
  description: string;
  timestamp: string;
  platform?: SocialPlatform;
  leadId?: string;
  avatar?: string;
  value?: number;
}
