export type SocialPlatform =
  | 'linkedin'
  | 'twitter'
  | 'instagram'
  | 'facebook'
  | 'tiktok'
  | 'youtube';

export type SentimentType = 'positive' | 'neutral' | 'negative';

export interface SentimentAnalysis {
  sentiment: SentimentType;
  sentimentScore: number; // -1.0 to 1.0
  confidenceScore: number; // 0.0 to 1.0
  primaryEmotion: string; // e.g. enthusiastic, frustrated, skeptical, inquisitive, appreciative, urgent
  keyThemes: string[];
  urgencyLevel: 'low' | 'medium' | 'high' | 'critical';
  recommendedAction: string;
  suggestedReplies: string[];
  leadQualificationScore: number; // 1 to 100
  analyzedAt: string;
}

export interface CustomerPersona {
  id: string;
  name: string;
  role: string;
  companySize: string;
  industry: string;
  avatar: string;
  color: string;
  demographics: {
    ageRange: string;
    location: string;
    education: string;
    incomeLevel: string;
  };
  corePainPoints: string[];
  primaryGoals: string[];
  buyingTriggers: string[];
  objections: string[];
  preferredChannels: SocialPlatform[];
  communicationTone: string;
  triggerKeywords: string[];
  suggestedHooks: string[];
  isDefault?: boolean;
  createdAt: string;
}

export interface ModerationFlag {
  id: string;
  category:
    | 'brand_safety'
    | 'over_promising'
    | 'tone_voice'
    | 'grammar_spelling'
    | 'regulatory'
    | 'platform_policy';
  severity: 'low' | 'medium' | 'high';
  issue: string;
  suggestion: string;
}

export interface ModerationReport {
  id: string;
  contentId: string;
  contentType: 'post' | 'comment_reply' | 'campaign_item' | 'direct_message';
  content: string;
  status: 'passed' | 'warning' | 'flagged';
  safetyScore: number; // 0 to 100
  brandAlignmentScore: number; // 0 to 100
  grammarScore: number; // 0 to 100
  readability: string;
  flags: ModerationFlag[];
  autoSanitizedContent: string;
  summary: string;
  reviewedBy?: string;
  reviewedAt?: string;
  appliedFix?: boolean;
  createdAt: string;
}

export interface SocialPost {
  id: string;
  platform: SocialPlatform;
  content: string;
  author: string;
  scheduledAt: string;
  status: 'published' | 'scheduled' | 'draft' | 'flagged';
  likes: number;
  comments: number;
  shares: number;
  impressions: number;
  targetPersonaId?: string;
  moderationReport?: ModerationReport;
  hashtags: string[];
  createdAt: string;
}

export interface MessageReply {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  isAiGenerated?: boolean;
  moderationStatus?: 'passed' | 'warning' | 'flagged';
}

export interface SocialMessage {
  id: string;
  platform: SocialPlatform;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  authorRole?: string;
  authorCompany?: string;
  type: 'comment' | 'direct_message' | 'mention';
  content: string;
  timestamp: string;
  status: 'unanswered' | 'replied' | 'converted_to_lead' | 'archived';
  sentimentAnalysis?: SentimentAnalysis;
  replies: MessageReply[];
  leadId?: string;
  associatedPostTitle?: string;
}

export interface SentimentDataPoint {
  date: string;
  sentiment: SentimentType;
  score: number;
  note: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  company: string;
  role: string;
  sourcePlatform: SocialPlatform;
  status:
    | 'new'
    | 'contacted'
    | 'qualified'
    | 'demo_scheduled'
    | 'closed_won'
    | 'closed_lost';
  leadScore: number;
  sentimentTrend: SentimentDataPoint[];
  matchedPersonaId?: string;
  interactionCount: number;
  estimatedValue: number;
  assignedTo: string;
  notes: string;
  lastContacted: string;
}

export interface CampaignPostItem {
  id: string;
  dayOffset: number;
  platform: SocialPlatform;
  hookTitle: string;
  content: string;
  hashtags: string[];
  suggestedCta: string;
  status: 'scheduled' | 'published' | 'draft';
  moderationStatus: 'passed' | 'warning' | 'flagged';
  variationLabel?: string; // e.g. 'Variation A (Technical)' | 'Variation B (ROI)'
  clicks?: number;
  signups?: number;
}

export interface CampaignConversionFunnel {
  followers: number;
  engaged: number;
  interested: number;
  websiteVisitors: number;
  leads: number;
  signups: number;
}

export interface CampaignAutonomousConversations {
  enabled: boolean;
  requireApproval: boolean;
  buyingIntentThreshold: number; // 0 to 100
  ctaLinkTrigger: boolean;
  monitoredInteractionsCount: number;
  activeConversationsCount: number;
  linksSentCount: number;
  safetyGuardrails: string[];
}

export interface CampaignAiOptimization {
  topPerformingHook: string;
  bestPlatform: SocialPlatform | string;
  abTestInsight: string;
  recommendedAction: string;
  lastOptimizedAt: string;
}

export interface Campaign {
  id: string;
  type: 'organic' | 'paid';
  title: string;
  description: string;
  websiteUrl?: string;
  targetAudience: string;
  targetPersonaId?: string;
  goal: 'lead_gen' | 'website_traffic' | 'signups' | 'product_launch' | 'event_registration' | 'brand_awareness';
  platforms: SocialPlatform[];
  status: 'active' | 'scheduled' | 'draft' | 'completed';
  startDate: string;
  endDate: string;
  budget: number;
  leadsGenerated: number;
  conversionRate: number;
  posts: CampaignPostItem[];
  customInstructions?: string;
  strategySummary?: string;
  conversionFunnel?: CampaignConversionFunnel;
  autonomousConversations?: CampaignAutonomousConversations;
  aiOptimization?: CampaignAiOptimization;
  targetMetrics?: {
    websiteVisitors?: number;
    signups?: number;
    followersGained?: number;
    leadsCaptured?: number;
    adImpressions?: number;
    cpc?: number;
    cpm?: number;
    cpl?: number;
    roas?: number;
  };
}

export interface CalendarFollowUp {
  id: string;
  leadId: string;
  leadName: string;
  title: string;
  type: 'discovery_call' | 'demo' | 'follow_up' | 'closing_call';
  scheduledAt: string;
  durationMinutes: number;
  assignedTo: string;
  notes: string;
  status: 'scheduled' | 'completed' | 'cancelled';
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  email: string;
  leadsAssigned: number;
  closedRevenue: number;
}

export interface BrandSafetyPolicy {
  strictness: 'relaxed' | 'standard' | 'strict';
  bannedKeywords: string[];
  prohibitGuarantees: boolean;
  requireDisclaimer: boolean;
  enforceBrandTone: boolean;
  preferredTone: string;
  autoBlockFlagged: boolean;
}

// ----------------------------------------------------
// Social-Growth RPG & 3D Growth Tower System Types
// ----------------------------------------------------

export type GrowthRankTier =
  | 'starter' // 🌱 Starter (Seed, Level 1-5)
  | 'rising' // 🥉 Rising (Bronze, Level 6-10)
  | 'builder' // 🥈 Builder (Silver, Level 11-18)
  | 'pro' // 🥇 Growth Pro (Gold, Level 19-28)
  | 'influencer' // 💎 Influencer (Diamond, Level 29-38)
  | 'master' // 👑 Growth Master (Crown, Level 39-49)
  | 'legend'; // 🔥 Growth Legend (Legendary, Level 50+)

export interface GrowthAccountRank {
  tier: GrowthRankTier;
  level: number;
  title: string;
  badgeEmoji: string;
  badgeName: string;
  currentXp: number;
  xpForNextLevel: number;
  totalXp: number;
  growthHealth: 'healthy' | 'surging' | 'dipping';
  healthMessage: string;
  unlockedAutomations: string[];
  campaignCapacity: number;
  towerFloors: number;
  growthMultiplier: number;
  streakDays: number;
}

export type GrowthNpcType =
  | 'follower' // 👤 Blue/Cyan climber
  | 'engaged' // 🔥 Orange/Amber climber with flame trail
  | 'conversation' // 💬 Purple/Indigo with speech bubbles
  | 'qualified_lead' // 🎯 Emerald/Gold on high-intent terrace
  | 'visitor' // 🌐 Cyan entering teleport portal
  | 'customer_signup'; // ⭐ Golden champion reaching summit with victory crown

export interface GrowthNpc {
  id: string;
  name: string;
  avatar: string;
  type: GrowthNpcType;
  platform: SocialPlatform;
  x: number; // 0 to 100 horizontal percentage on tower floor
  floor: number; // 0: Base Camp, 1: Engagement Terrace, 2: Discussion Lounge, 3: Portal Gate, 4: Qualified Platform, 5: Summit Crown
  targetFloor: number;
  climbProgress: number; // 0 to 100 within current step
  speed: number;
  status: 'climbing' | 'celebrating' | 'conversing' | 'entering_portal' | 'stumbling';
  speechBubble?: string;
  bubbleExpiresAt?: number;
  badgeMarker?: string;
  stumbleTimer?: number;
  createdAt: number;
}

export type AchievementTier = 'bronze' | 'silver' | 'gold' | 'diamond' | 'mythic';

export interface GrowthAchievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  badgeEmoji: string;
  tier: AchievementTier;
  category: 'audience' | 'conversations' | 'leads' | 'signups' | 'speed' | 'safety';
  currentProgress: number;
  targetProgress: number;
  isUnlocked: boolean;
  unlockedAt?: string;
  xpReward: number;
  perkReward?: string;
}

export interface RankUpEvent {
  oldRankTitle: string;
  newRankTitle: string;
  oldTier: GrowthRankTier;
  newTier: GrowthRankTier;
  newLevel: number;
  badgeEmoji: string;
  badgeName: string;
  newPerks: string[];
  xpGained: number;
}

