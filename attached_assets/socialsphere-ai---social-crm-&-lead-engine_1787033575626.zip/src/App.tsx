import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { CommunicationsView } from './components/CommunicationsView';
import { PersonasView } from './components/PersonasView';
import { ModerationView } from './components/ModerationView';
import { CampaignsView } from './components/CampaignsView';
import { LeadsView } from './components/LeadsView';
import { CalendarView } from './components/CalendarView';
import { NewPostModal } from './components/modals/NewPostModal';
import { NewPersonaModal } from './components/modals/NewPersonaModal';
import { NewCampaignModal } from './components/modals/NewCampaignModal';
import { AutoReplyModal } from './components/modals/AutoReplyModal';
import { ScheduleModal } from './components/modals/ScheduleModal';
import { EmailModal } from './components/modals/EmailModal';

const AppContent: React.FC = () => {
  const { activeView } = useApp();

  return (
    <div className="min-h-screen bg-[#0B0D11] text-slate-200 flex flex-col font-sans">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeView === 'dashboard' && <DashboardView />}
        {activeView === 'communications' && <CommunicationsView />}
        {activeView === 'personas' && <PersonasView />}
        {activeView === 'moderation' && <ModerationView />}
        {activeView === 'campaigns' && <CampaignsView />}
        {activeView === 'leads' && <LeadsView />}
        {activeView === 'calendar' && <CalendarView />}
      </main>

      {/* Global Modals */}
      <NewPostModal />
      <NewPersonaModal />
      <NewCampaignModal />
      <AutoReplyModal />
      <ScheduleModal />
      <EmailModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
