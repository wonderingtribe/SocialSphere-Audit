import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  SentimentType,
  SocialPlatform,
  SocialMessage,
  SentimentAnalysis,
} from '../types';
import { analyzeSentimentApi } from '../services/geminiService';
import {
  MessageSquareHeart,
  Filter,
  Sparkles,
  Send,
  UserPlus,
  RefreshCw,
  AlertTriangle,
  Flame,
  CheckCircle2,
  Smile,
  Meh,
  Frown,
  Zap,
  TrendingUp,
  ShieldCheck,
  Search,
  Bot,
} from 'lucide-react';

export const CommunicationsView: React.FC = () => {
  const {
    messages,
    filterSentiment,
    setFilterSentiment,
    filterPlatform,
    setFilterPlatform,
    analyzeMessage,
    replyToMessage,
    convertMessageToLead,
    batchAnalyzeSentiment,
    isBatchAnalyzing,
    activePersona,
  } = useApp();

  const [selectedMessage, setSelectedMessage] = useState<SocialMessage | null>(
    messages[0] || null
  );
  const [replyInput, setReplyInput] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [isAnalyzingSingle, setIsAnalyzingSingle] = useState(false);

  // Custom Text Sandbox State
  const [customText, setCustomText] = useState('');
  const [customAuthor, setCustomAuthor] = useState('Prospect');
  const [customPlatform, setCustomPlatform] = useState<SocialPlatform>('linkedin');
  const [customAnalysis, setCustomAnalysis] = useState<SentimentAnalysis | null>(null);
  const [isAnalyzingCustom, setIsAnalyzingCustom] = useState(false);
  const [showCustomSandbox, setShowCustomSandbox] = useState(false);

  // Filter messages
  const filteredMessages = messages.filter((msg) => {
    if (filterPlatform !== 'all' && msg.platform !== filterPlatform) return false;
    if (filterSentiment === 'high_urgency') {
      return (
        msg.sentimentAnalysis?.urgencyLevel === 'high' ||
        msg.sentimentAnalysis?.urgencyLevel === 'critical'
      );
    }
    if (filterSentiment !== 'all') {
      return msg.sentimentAnalysis?.sentiment === filterSentiment;
    }
    return true;
  });

  const handleSelectMessage = (msg: SocialMessage) => {
    setSelectedMessage(msg);
    setReplyInput('');
  };

  const handleAnalyzeCurrent = async () => {
    if (!selectedMessage) return;
    setIsAnalyzingSingle(true);
    try {
      const result = await analyzeMessage(selectedMessage.id);
      if (result) {
        setSelectedMessage((prev) =>
          prev ? { ...prev, sentimentAnalysis: result } : null
        );
      }
    } finally {
      setIsAnalyzingSingle(false);
    }
  };

  const handleSendReply = async () => {
    if (!selectedMessage || !replyInput.trim()) return;
    setIsSendingReply(true);
    try {
      await replyToMessage(selectedMessage.id, replyInput, true);
      setReplyInput('');
    } finally {
      setIsSendingReply(false);
    }
  };

  const handleApplySuggestedReply = (reply: string) => {
    setReplyInput(reply);
  };

  const handleAnalyzeCustomSandbox = async () => {
    if (!customText.trim()) return;
    setIsAnalyzingCustom(true);
    try {
      const res = await analyzeSentimentApi({
        text: customText,
        authorName: customAuthor,
        platform: customPlatform,
      });
      setCustomAnalysis(res);
    } finally {
      setIsAnalyzingCustom(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/15 border border-blue-500/30">
              <MessageSquareHeart className="w-5 h-5 text-blue-400" />
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white">
              Social Communications & Sentiment Intelligence
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Real-time multi-channel sentiment triage, emotional nuance profiling, and high-converting AI reply synthesis.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowCustomSandbox(!showCustomSandbox)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{showCustomSandbox ? 'Close Sandbox' : 'Live Text Sandbox'}</span>
          </button>

          <button
            onClick={batchAnalyzeSentiment}
            disabled={isBatchAnalyzing}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isBatchAnalyzing ? 'animate-spin' : ''}`} />
            <span>{isBatchAnalyzing ? 'Scanning All Threads...' : 'Batch Triage All Messages'}</span>
          </button>
        </div>
      </div>

      {/* Custom Text Sandbox Accordion (if open) */}
      {showCustomSandbox && (
        <div className="bg-[#141A26] border border-cyan-500/30 rounded-2xl p-5 shadow-xl space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">Interactive Sentiment Intelligence Sandbox</h3>
            </div>
            <span className="text-[11px] text-cyan-300 font-mono">Powered by Gemini 3.7 Flash</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Author Name / Handle</label>
              <input
                type="text"
                value={customAuthor}
                onChange={(e) => setCustomAuthor(e.target.value)}
                placeholder="e.g. Jason Calacanis"
                className="w-full bg-[#0E121B] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Channel</label>
              <select
                value={customPlatform}
                onChange={(e) => setCustomPlatform(e.target.value as SocialPlatform)}
                className="w-full bg-[#0E121B] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 capitalize"
              >
                {['linkedin', 'twitter', 'instagram', 'tiktok', 'facebook', 'youtube'].map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={handleAnalyzeCustomSandbox}
                disabled={isAnalyzingCustom || !customText.trim()}
                className="w-full py-1.5 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-600/20 transition-all cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzingCustom ? 'animate-spin' : ''}`} />
                <span>{isAnalyzingCustom ? 'Analyzing...' : 'Run Real-Time Sentiment Analysis'}</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Text / Comment / Email Body</label>
            <textarea
              rows={3}
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder="Paste any customer feedback, cold DM objection, or high-intent comment to evaluate..."
              className="w-full bg-[#0E121B] border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 leading-relaxed font-sans"
            />
          </div>

          {/* Sandbox Results */}
          {customAnalysis && (
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-400">Sentiment:</span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                      customAnalysis.sentiment === 'positive'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : customAnalysis.sentiment === 'negative'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {customAnalysis.sentiment}
                  </span>
                  <span className="text-xs text-slate-400">
                    Emotion: <strong className="text-white capitalize">{customAnalysis.primaryEmotion}</strong>
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono">
                  <span className="text-emerald-400">Score: {customAnalysis.sentimentScore > 0 ? `+${customAnalysis.sentimentScore}` : customAnalysis.sentimentScore}</span>
                  <span className="text-cyan-400">Confidence: {Math.round(customAnalysis.confidenceScore * 100)}%</span>
                  <span className="text-indigo-400">Lead Score: {customAnalysis.leadQualificationScore}/100</span>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-blue-950/30 border border-blue-900/40 text-xs text-blue-200">
                <strong className="text-cyan-300">Tactical Strategy:</strong> {customAnalysis.recommendedAction}
              </div>

              <div className="space-y-1.5">
                <span className="text-[11px] font-bold uppercase text-slate-400">AI Suggested Replies</span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {customAnalysis.suggestedReplies.map((reply, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-300 leading-relaxed hover:border-cyan-500/50 transition-colors cursor-pointer"
                      onClick={() => setReplyInput(reply)}
                    >
                      <span className="text-[9px] font-bold text-cyan-400 block mb-1">Option {i + 1}</span>
                      {reply}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filter Tabs Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121620] border border-slate-800/80 rounded-xl p-3">
        {/* Sentiment Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            Sentiment:
          </span>
          {[
            { id: 'all', label: 'All Inbound', count: messages.length },
            {
              id: 'positive',
              label: '🟢 Positive',
              count: messages.filter((m) => m.sentimentAnalysis?.sentiment === 'positive').length,
            },
            {
              id: 'neutral',
              label: '🟡 Neutral',
              count: messages.filter((m) => m.sentimentAnalysis?.sentiment === 'neutral').length,
            },
            {
              id: 'negative',
              label: '🔴 Negative',
              count: messages.filter((m) => m.sentimentAnalysis?.sentiment === 'negative').length,
            },
            {
              id: 'high_urgency',
              label: '⚡ Critical Urgency',
              count: messages.filter(
                (m) =>
                  m.sentimentAnalysis?.urgencyLevel === 'high' ||
                  m.sentimentAnalysis?.urgencyLevel === 'critical'
              ).length,
            },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilterSentiment(f.id as any)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                filterSentiment === f.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {f.label} ({f.count})
            </button>
          ))}
        </div>

        {/* Platform Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-400">Channel:</span>
          <select
            value={filterPlatform}
            onChange={(e) => setFilterPlatform(e.target.value as any)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none capitalize"
          >
            <option value="all">All Channels</option>
            <option value="linkedin">LinkedIn</option>
            <option value="twitter">X / Twitter</option>
            <option value="instagram">Instagram</option>
            <option value="tiktok">TikTok</option>
            <option value="facebook">Facebook</option>
          </select>
        </div>
      </div>

      {/* Main 2-Column Split: Message Stream + Deep Sentiment Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col (5 cols): Message List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Showing {filteredMessages.length} conversations</span>
            <span>Sorted by highest urgency</span>
          </div>

          <div className="space-y-3 max-h-[750px] overflow-y-auto pr-1">
            {filteredMessages.map((msg) => {
              const isSelected = selectedMessage?.id === msg.id;
              const sentiment = msg.sentimentAnalysis?.sentiment;
              const urgency = msg.sentimentAnalysis?.urgencyLevel;

              const sentimentBadge =
                sentiment === 'positive'
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  : sentiment === 'negative'
                  ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                  : 'bg-amber-500/15 text-amber-400 border-amber-500/30';

              return (
                <div
                  key={msg.id}
                  onClick={() => handleSelectMessage(msg)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer relative space-y-2.5 ${
                    isSelected
                      ? 'bg-[#151C2C] border-blue-500/60 shadow-lg shadow-blue-900/20 ring-1 ring-blue-500/30'
                      : 'bg-[#121620] border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-white">
                        {msg.authorName.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-white">{msg.authorName}</h4>
                        <span className="text-[10px] text-slate-400 font-mono">{msg.authorHandle}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {sentiment && (
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${sentimentBadge}`}>
                          {sentiment}
                        </span>
                      )}
                      {urgency === 'critical' && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-rose-600 text-white animate-pulse">
                          ⚡ URGENT
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    "{msg.content}"
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                    <span className="capitalize font-medium text-slate-300">
                      {msg.platform} • {msg.type}
                    </span>
                    <span>{msg.timestamp}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col (7 cols): Deep Sentiment Inspector & Smart Reply Console */}
        <div className="lg:col-span-7">
          {selectedMessage ? (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5 sticky top-24">
              {/* Message Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center font-bold text-base text-blue-400">
                    {selectedMessage.authorName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      {selectedMessage.authorName}
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 font-mono capitalize">
                        {selectedMessage.platform}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      {selectedMessage.authorRole || 'Prospect'} • {selectedMessage.authorCompany || 'Independent'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAnalyzeCurrent}
                    disabled={isAnalyzingSingle}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzingSingle ? 'animate-spin' : ''}`} />
                    <span>Re-Analyze</span>
                  </button>

                  {selectedMessage.status !== 'converted_to_lead' ? (
                    <button
                      onClick={() => convertMessageToLead(selectedMessage.id)}
                      className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition-all cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Convert to Lead</span>
                    </button>
                  ) : (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Lead Active in CRM
                    </span>
                  )}
                </div>
              </div>

              {/* Message Content Box */}
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                  Incoming Message Content
                </span>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  "{selectedMessage.content}"
                </p>
              </div>

              {/* Deep AI Sentiment Breakdown Panel */}
              {selectedMessage.sentimentAnalysis && (
                <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3.5">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                        AI Sentiment & Psychological Profiling
                      </h4>
                    </div>
                    <span className="text-[11px] font-mono text-cyan-300">
                      Lead Score: {selectedMessage.sentimentAnalysis.leadQualificationScore}/100
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                    <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Classification</span>
                      <p
                        className={`text-xs font-extrabold capitalize mt-0.5 ${
                          selectedMessage.sentimentAnalysis.sentiment === 'positive'
                            ? 'text-emerald-400'
                            : selectedMessage.sentimentAnalysis.sentiment === 'negative'
                            ? 'text-rose-400'
                            : 'text-amber-400'
                        }`}
                      >
                        {selectedMessage.sentimentAnalysis.sentiment}
                      </p>
                    </div>

                    <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Emotion</span>
                      <p className="text-xs font-extrabold text-blue-400 capitalize mt-0.5">
                        {selectedMessage.sentimentAnalysis.primaryEmotion}
                      </p>
                    </div>

                    <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Confidence</span>
                      <p className="text-xs font-extrabold text-cyan-400 mt-0.5">
                        {Math.round(selectedMessage.sentimentAnalysis.confidenceScore * 100)}%
                      </p>
                    </div>

                    <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">Urgency</span>
                      <p
                        className={`text-xs font-extrabold uppercase mt-0.5 ${
                          selectedMessage.sentimentAnalysis.urgencyLevel === 'critical'
                            ? 'text-rose-400 animate-pulse'
                            : selectedMessage.sentimentAnalysis.urgencyLevel === 'high'
                            ? 'text-amber-400'
                            : 'text-slate-300'
                        }`}
                      >
                        {selectedMessage.sentimentAnalysis.urgencyLevel}
                      </p>
                    </div>
                  </div>

                  {/* Themes */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase mr-1">Key Themes:</span>
                    {selectedMessage.sentimentAnalysis.keyThemes.map((theme, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-blue-500/10 text-blue-300 border border-blue-500/20"
                      >
                        {theme}
                      </span>
                    ))}
                  </div>

                  {/* Tactical Battlecard Advice */}
                  <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/50 text-xs text-blue-200 space-y-1">
                    <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>Tactical Objection / Closing Battlecard:</span>
                    </div>
                    <p className="leading-relaxed text-slate-300">
                      {selectedMessage.sentimentAnalysis.recommendedAction}
                    </p>
                  </div>

                  {/* 3 AI Suggested Replies */}
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase text-slate-400">
                        Suggested Reply Angles (Click to load into editor)
                      </span>
                      {activePersona && (
                        <span className="text-[10px] text-indigo-400 font-medium">
                          Tuned to: {activePersona.name}
                        </span>
                      )}
                    </div>
                    <div className="space-y-2">
                      {selectedMessage.sentimentAnalysis.suggestedReplies.map((reply, i) => (
                        <div
                          key={i}
                          onClick={() => handleApplySuggestedReply(reply)}
                          className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 text-xs text-slate-300 leading-relaxed cursor-pointer transition-all hover:bg-slate-900/60"
                        >
                          <div className="flex items-center justify-between text-[10px] text-blue-400 font-bold mb-1">
                            <span>Option {i + 1}: {i === 0 ? 'Empathetic & Direct' : i === 1 ? 'Data / Proof Focus' : 'Fast-Track Demo Booking'}</span>
                            <span className="text-slate-400 font-normal">Click to Use</span>
                          </div>
                          <p>{reply}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Reply History Threads */}
              {selectedMessage.replies.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <span className="text-[10px] font-bold uppercase text-slate-400">Conversation History</span>
                  {selectedMessage.replies.map((rep) => (
                    <div key={rep.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-blue-400">{rep.author}</span>
                        <span className="text-slate-400">{rep.timestamp}</span>
                      </div>
                      <p className="text-slate-300">{rep.content}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Live Reply Composer with Safety Guard */}
              <div className="space-y-2.5 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Send className="w-3.5 h-3.5 text-blue-400" />
                    Compose Omnichannel Reply
                  </span>
                  <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Live Brand Safety Moderation Active
                  </span>
                </div>

                <textarea
                  rows={3}
                  value={replyInput}
                  onChange={(e) => setReplyInput(e.target.value)}
                  placeholder={`Write an on-brand reply to ${selectedMessage.authorName}...`}
                  className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
                />

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Will be posted directly to {selectedMessage.platform} via API
                  </span>
                  <button
                    onClick={handleSendReply}
                    disabled={isSendingReply || !replyInput.trim()}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Send className={`w-3.5 h-3.5 ${isSendingReply ? 'animate-spin' : ''}`} />
                    <span>{isSendingReply ? 'Scanning & Sending...' : 'Send Verified Reply'}</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
              <MessageSquareHeart className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-sm font-bold text-white">No Message Selected</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Select an inbound comment or DM from the left stream to inspect its sentiment score and generate responses.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
