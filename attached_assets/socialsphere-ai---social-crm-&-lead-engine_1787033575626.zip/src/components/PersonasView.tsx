import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CustomerPersona, SocialPlatform } from '../types';
import { tailorContentApi } from '../services/geminiService';
import {
  Users,
  Sparkles,
  Target,
  Plus,
  Trash2,
  CheckCircle2,
  Share2,
  MessageSquare,
  AlertCircle,
  Lightbulb,
  Zap,
  ArrowRight,
  Send,
  Sliders,
  Copy,
  Check,
} from 'lucide-react';

export const PersonasView: React.FC = () => {
  const {
    personas,
    activePersona,
    setActivePersona,
    deletePersona,
    setIsNewPersonaModalOpen,
    setIsNewPostModalOpen,
  } = useApp();

  const [selectedPersona, setSelectedPersona] = useState<CustomerPersona>(
    activePersona || personas[0]
  );

  // Copy Resonance Tester State
  const [testTopic, setTestTopic] = useState(
    'Why traditional cold outreach is failing and how automated social lead capture solves it'
  );
  const [testPlatform, setTestPlatform] = useState<SocialPlatform>('linkedin');
  const [testGoal, setTestGoal] = useState('lead_gen');
  const [tailorResult, setTailorResult] = useState<{
    tailoredContent: string;
    personaMatchScore: number;
    matchExplanation: string;
    targetedHashtags: string[];
    ctaSuggestion: string;
  } | null>(null);
  const [isTailoring, setIsTailoring] = useState(false);
  const [hasCopied, setHasCopied] = useState(false);

  const handleTestResonance = async () => {
    if (!selectedPersona || !testTopic.trim()) return;
    setIsTailoring(true);
    try {
      const res = await tailorContentApi({
        persona: selectedPersona,
        topic: testTopic,
        platform: testPlatform,
        goal: testGoal,
      });
      setTailorResult(res);
    } finally {
      setIsTailoring(false);
    }
  };

  const handleCopyContent = () => {
    if (!tailorResult?.tailoredContent) return;
    navigator.clipboard.writeText(tailorResult.tailoredContent);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-600/15 border border-indigo-500/30">
              <Users className="w-5 h-5 text-indigo-400" />
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white">
              Customer Personas & Audience Intelligence Studio
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Define psychological buyer archetypes to tailor campaign hooks, tones, and buying triggers with AI.
          </p>
        </div>

        <button
          onClick={() => setIsNewPersonaModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold shadow-md shadow-indigo-600/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Sparkles className="w-4 h-4 text-indigo-200" />
          <span>Generate AI Persona</span>
        </button>
      </div>

      {/* Persona Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {personas.map((persona) => {
          const isSelected = selectedPersona.id === persona.id;
          const isActiveGlobal = activePersona?.id === persona.id;

          return (
            <div
              key={persona.id}
              onClick={() => setSelectedPersona(persona)}
              className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer relative space-y-3.5 flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#161C2C] border-indigo-500/60 shadow-xl shadow-indigo-950/40 ring-1 ring-indigo-500/40'
                  : 'bg-[#121620] border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm text-white shadow-md"
                      style={{ backgroundColor: persona.color || '#3B82F6' }}
                    >
                      {persona.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white line-clamp-1">{persona.name}</h3>
                      <p className="text-xs text-indigo-400 font-medium">{persona.role}</p>
                    </div>
                  </div>

                  {isActiveGlobal && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                      Default Active
                    </span>
                  )}
                </div>

                <div className="mt-3 space-y-1.5 text-xs text-slate-300">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Industry:</span>
                    <span className="text-slate-200 font-medium">{persona.industry}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Company Scale:</span>
                    <span className="text-slate-200 font-medium">{persona.companySize}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Tone:</span>
                    <span className="text-indigo-300 font-medium truncate max-w-[160px]">
                      {persona.communicationTone}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActivePersona(persona);
                  }}
                  className={`text-xs font-semibold px-2.5 py-1 rounded-lg transition-colors ${
                    isActiveGlobal
                      ? 'text-slate-400 bg-slate-800/40 cursor-default'
                      : 'text-blue-400 hover:text-blue-300 hover:bg-blue-600/15 cursor-pointer'
                  }`}
                >
                  {isActiveGlobal ? 'Active for Outreach' : 'Set as Active'}
                </button>

                {personas.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deletePersona(persona.id);
                    }}
                    className="p-1 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                    title="Delete Persona"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Persona Deep Profile & AI Resonance Tester */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col (6 cols): Psychological Profile Deep-Dive */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">
                  Psychological Blueprint: {selectedPersona.name}
                </h3>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                {selectedPersona.demographics?.location || 'Global'}
              </span>
            </div>

            {/* Core Pain Points */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase text-rose-400 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Core Business & Career Pain Points
              </span>
              <div className="space-y-1.5">
                {selectedPersona.corePainPoints.map((pain, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-rose-950/20 border border-rose-900/30 text-xs text-rose-200 leading-relaxed flex items-start gap-2"
                  >
                    <span className="font-bold text-rose-400 shrink-0">•</span>
                    <span>{pain}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Primary Goals */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                Primary Business Goals & Desired Outcomes
              </span>
              <div className="space-y-1.5">
                {selectedPersona.primaryGoals.map((goal, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-900/30 text-xs text-emerald-200 leading-relaxed flex items-start gap-2"
                  >
                    <span className="font-bold text-emerald-400 shrink-0">✓</span>
                    <span>{goal}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Buying Triggers & Objections Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold uppercase text-amber-400 flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  Buying Triggers
                </span>
                <ul className="space-y-1 text-xs text-slate-300">
                  {selectedPersona.buyingTriggers.map((t, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-amber-400 font-bold">›</span>
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <span className="text-[10px] font-bold uppercase text-blue-400 flex items-center gap-1">
                  <Lightbulb className="w-3 h-3" />
                  Common Objections
                </span>
                <ul className="space-y-1 text-xs text-slate-300">
                  {selectedPersona.objections.map((obj, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-blue-400 font-bold">›</span>
                      <span>{obj}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Trigger Keywords */}
            <div className="space-y-1.5 pt-2">
              <span className="text-[10px] font-bold uppercase text-slate-400">High-Resonance Vocabulary & Power Words:</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedPersona.triggerKeywords.map((kw, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md text-xs font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                  >
                    #{kw}
                  </span>
                ))}
              </div>
            </div>

            {/* High-Converting Viral Hooks Library */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <span className="text-[10px] font-bold uppercase text-cyan-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Proven Hook Headlines Tailored for this Persona
              </span>
              <div className="space-y-1.5">
                {selectedPersona.suggestedHooks.map((hook, idx) => (
                  <div
                    key={idx}
                    onClick={() => setTestTopic(hook)}
                    className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 text-xs text-slate-300 cursor-pointer transition-colors flex items-center justify-between gap-2"
                  >
                    <span className="italic">"{hook}"</span>
                    <span className="text-[10px] text-cyan-400 font-semibold whitespace-nowrap">Use in Tester →</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Col (6 cols): Live Persona Content Tailoring & Resonance Tester */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">
                  Live Persona Copy Tailoring & Resonance Engine
                </h3>
              </div>
              <span className="text-[11px] text-indigo-400 font-semibold">
                Targeting: {selectedPersona.name}
              </span>
            </div>

            {/* Input Config */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                  Topic, Value Proposition, or Draft Idea
                </label>
                <textarea
                  rows={3}
                  value={testTopic}
                  onChange={(e) => setTestTopic(e.target.value)}
                  placeholder="Enter the core message or topic you want to tailor..."
                  className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Platform</label>
                  <select
                    value={testPlatform}
                    onChange={(e) => setTestPlatform(e.target.value as SocialPlatform)}
                    className="w-full bg-[#0B0D11] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none capitalize"
                  >
                    {['linkedin', 'twitter', 'instagram', 'tiktok', 'facebook'].map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Goal</label>
                  <select
                    value={testGoal}
                    onChange={(e) => setTestGoal(e.target.value)}
                    className="w-full bg-[#0B0D11] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none"
                  >
                    <option value="lead_gen">Inbound Lead Generation</option>
                    <option value="demo_booking">Direct Demo Booking</option>
                    <option value="thought_leadership">Authority / Thought Leadership</option>
                    <option value="case_study">Case Study Social Proof</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleTestResonance}
                disabled={isTailoring || !testTopic.trim()}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isTailoring ? 'animate-spin' : ''}`} />
                <span>{isTailoring ? 'Synthesizing with Persona Psychological Triggers...' : 'Tailor & Measure Persona Resonance'}</span>
              </button>
            </div>

            {/* Tailor Output Results */}
            {tailorResult && (
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3.5 animate-in fade-in">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">Persona Match Score:</span>
                    <span className="px-2 py-0.5 rounded-full text-xs font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {tailorResult.personaMatchScore} / 100
                    </span>
                  </div>
                  <button
                    onClick={handleCopyContent}
                    className="flex items-center gap-1 text-xs text-slate-400 hover:text-white cursor-pointer"
                  >
                    {hasCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{hasCopied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                <div className="p-3 rounded-lg bg-indigo-950/30 border border-indigo-900/40 text-xs text-indigo-200">
                  <strong className="text-indigo-300">Resonance Psychology:</strong> {tailorResult.matchExplanation}
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                    AI Tailored Copy ({testPlatform})
                  </span>
                  <div className="p-3 rounded-xl bg-[#0B0D11] border border-slate-800 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                    {tailorResult.tailoredContent}
                  </div>
                </div>

                {/* Hashtags & CTA */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex flex-wrap gap-1">
                    {tailorResult.targetedHashtags.map((h, i) => (
                      <span key={i} className="text-[11px] text-blue-400 font-mono">
                        #{h}
                      </span>
                    ))}
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">
                    CTA: <strong className="text-white">{tailorResult.ctaSuggestion}</strong>
                  </span>
                </div>

                <button
                  onClick={() => setIsNewPostModalOpen(true)}
                  className="w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Launch this Post with Live Safety Scanner</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
