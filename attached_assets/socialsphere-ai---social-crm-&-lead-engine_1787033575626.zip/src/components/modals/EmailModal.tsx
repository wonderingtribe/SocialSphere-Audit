import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Mail,
  Sparkles,
  Send,
  ShieldCheck,
} from 'lucide-react';

export const EmailModal: React.FC = () => {
  const {
    isEmailModalOpen,
    setIsEmailModalOpen,
    selectedLeadForEmail,
    updateLeadStatus,
  } = useApp();

  const [subject, setSubject] = useState(
    selectedLeadForEmail
      ? `Re: Social lead qualification for ${selectedLeadForEmail.company}`
      : 'Executive Follow-Up'
  );
  const [body, setBody] = useState(
    selectedLeadForEmail
      ? `Hi ${selectedLeadForEmail.name},\n\nThanks for connecting with us on ${selectedLeadForEmail.sourcePlatform}! I saw your question regarding automated pipeline routing.\n\nWe built our platform specifically for teams like ${selectedLeadForEmail.company} to turn social engagement into qualified revenue without SDR manual overhead.\n\nWould you have 10 minutes this week for a quick sandbox walkthrough?\n\nBest regards,\nSarah Jenkins\nSenior Enterprise AE`
      : ''
  );
  const [isSending, setIsSending] = useState(false);

  if (!isEmailModalOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!body.trim()) return;

    setIsSending(true);
    setTimeout(() => {
      if (selectedLeadForEmail) {
        updateLeadStatus(selectedLeadForEmail.id, 'contacted');
      }
      setIsSending(false);
      setIsEmailModalOpen(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-lg p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white">Send Direct Email Follow-Up</h2>
              <p className="text-[11px] text-slate-400">
                To: {selectedLeadForEmail?.email || 'prospect@example.com'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsEmailModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSend} className="space-y-3.5">
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Subject Line
            </label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-bold uppercase text-slate-400">
                Email Message Body
              </label>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Moderation Approved
              </span>
            </div>
            <textarea
              rows={7}
              required
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsEmailModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSending}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              <Send className={`w-3.5 h-3.5 ${isSending ? 'animate-spin' : ''}`} />
              <span>{isSending ? 'Sending...' : 'Send Verified Email'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
