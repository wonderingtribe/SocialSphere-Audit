import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SocialPlatform } from '../../types';
import { generateCampaignApi } from '../../services/geminiService';
import {
  X,
  Sparkles,
  Megaphone,
  Globe,
  DollarSign,
  ShieldAlert,
  Zap,
  Users,
  Target,
  CheckCircle2,
} from 'lucide-react';

export const NewCampaignModal: React.FC = () => {
  const {
    isNewCampaignModalOpen,
    setIsNewCampaignModalOpen,
    personas,
    addCampaign,
    setActiveView,
  } = useApp();

  const [campaignType, setCampaignType] = useState<'organic' | 'paid'>('organic');
  const [title, setTitle] = useState('Launch AI-WONDERLAND Growth Engine');
  const [description, setDescription] = useState(
    'Multi-platform viral sequence driving high-intent web developers, SaaS builders, and AI creators to visit the website, follow social hubs, and sign up for beta.'
  );
  const [websiteUrl, setWebsiteUrl] = useState('https://ai-wonderland.io');
  const [targetAudience, setTargetAudience] = useState(
    'Web developers, SaaS builders, AI developers'
  );
  const [targetPersonaId, setTargetPersonaId] = useState(personas[0]?.id || '');
  const [goal, setGoal] = useState<any>('website_traffic');
  const [selectedPlatforms, setSelectedPlatforms] = useState<SocialPlatform[]>([
    'linkedin',
    'twitter',
    'instagram',
    'tiktok',
    'facebook',
  ]);
  const [budget, setBudget] = useState<number>(0);
  const [requireApproval, setRequireApproval] = useState<boolean>(false);
  const [customInstructions, setCustomInstructions] = useState(
    'Focus on hands-on developer experience, zero marketing fluff, speed of shipping, and direct link to interactive sandbox.'
  );
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isNewCampaignModalOpen) return null;

  const togglePlatform = (p: SocialPlatform) => {
    if (selectedPlatforms.includes(p)) {
      if (selectedPlatforms.length > 1) {
        setSelectedPlatforms(selectedPlatforms.filter((item) => item !== p));
      }
    } else {
      setSelectedPlatforms([...selectedPlatforms, p]);
    }
  };

  const handleApplyTemplate = (type: 'organic' | 'paid') => {
    setCampaignType(type);
    if (type === 'organic') {
      setTitle('Launch AI-WONDERLAND Growth Engine');
      setDescription(
        'Goal: Get website visitors + followers + signups across developer communities with automated comment-to-lead routing.'
      );
      setWebsiteUrl('https://ai-wonderland.io');
      setTargetAudience('Web developers, SaaS builders, AI developers');
      setGoal('website_traffic');
      setSelectedPlatforms(['instagram', 'facebook', 'linkedin', 'twitter', 'tiktok']);
      setBudget(0);
      setRequireApproval(false);
      setCustomInstructions(
        'Include your website CTA on all variations. Monitor replies, identify interested commenters, and deliver the direct link when intent is detected.'
      );
    } else {
      setTitle('Q3 Enterprise Paid Demand Gen & Sponsored InMail');
      setDescription(
        'High-intent sponsored placements and carousel ad creatives across LinkedIn and Meta targeting VPs of Engineering and Enterprise Decision Makers.'
      );
      setWebsiteUrl('https://socialsphere.ai/enterprise');
      setTargetAudience('VPs of Revenue Ops, CROs, CMOs, Enterprise Growth Directors');
      setGoal('lead_gen');
      setSelectedPlatforms(['linkedin', 'facebook', 'twitter']);
      setBudget(6500);
      setRequireApproval(true);
      setCustomInstructions(
        'Emphasize SOC2 compliance, verified 3.4x ROI metrics, and direct link to book enterprise discovery call.'
      );
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsGenerating(true);
    try {
      const selectedPersona = personas.find((p) => p.id === targetPersonaId);
      const generated = await generateCampaignApi({
        type: campaignType,
        title,
        description,
        websiteUrl,
        targetAudience,
        targetPersona: selectedPersona,
        goal,
        platforms: selectedPlatforms,
        budget: campaignType === 'paid' ? budget : 0,
        customInstructions,
      });

      const today = new Date();
      const nextMonth = new Date(Date.now() + 30 * 86400000);

      const estimatedFunnel = generated.estimatedFunnel || {
        followers: campaignType === 'organic' ? 2200 : 750,
        engaged: campaignType === 'organic' ? 1600 : 1300,
        interested: campaignType === 'organic' ? 880 : 540,
        websiteVisitors: campaignType === 'organic' ? 4400 : 5800,
        leads: campaignType === 'organic' ? 480 : 250,
        signups: campaignType === 'organic' ? 820 : 310,
      };

      addCampaign({
        type: campaignType,
        title,
        description,
        websiteUrl,
        targetAudience,
        targetPersonaId,
        goal,
        platforms: selectedPlatforms,
        status: 'active',
        startDate: today.toISOString().split('T')[0],
        endDate: nextMonth.toISOString().split('T')[0],
        budget: campaignType === 'paid' ? Number(budget) : 0,
        leadsGenerated: 0,
        conversionRate: 0,
        customInstructions,
        strategySummary:
          generated.campaignStrategy ||
          `${campaignType === 'organic' ? 'Organic growth loop' : 'Paid acquisition'} targeting ${targetAudience}.`,
        targetMetrics: {
          websiteVisitors: estimatedFunnel.websiteVisitors,
          signups: estimatedFunnel.signups,
          followersGained: estimatedFunnel.followers,
          leadsCaptured: estimatedFunnel.leads,
          ...(campaignType === 'paid'
            ? {
                adImpressions: 45000,
                cpc: 2.15,
                cpm: 18.0,
                cpl: 42.5,
                roas: 3.2,
              }
            : {}),
        },
        conversionFunnel: estimatedFunnel,
        autonomousConversations: {
          enabled: true,
          requireApproval,
          buyingIntentThreshold: campaignType === 'organic' ? 80 : 90,
          ctaLinkTrigger: true,
          monitoredInteractionsCount: 0,
          activeConversationsCount: 0,
          linksSentCount: 0,
          safetyGuardrails: generated.safetyGuardrails || [
            'Act strictly as a helpful, consultative community and tech advisor, never an aggressive sales bot',
            'Detect technical questions and answer accurately based on verified platform documentation',
            'Only send the website signup link when explicit interest or buying intent is detected (>80%)',
            'Automated brand safety and grammar pre-check before dispatching any comment reply',
          ],
        },
        aiOptimization: generated.aiOptimization || {
          topPerformingHook: 'Why 85% of developers struggle with AI app deployment in 2026',
          bestPlatform: selectedPlatforms[0] || 'linkedin',
          abTestInsight: 'Variation A (Technical Breakdown) is optimized for higher initial website clickthrough.',
          recommendedAction: 'Coordinate cross-platform publication and monitor incoming technical comments.',
          lastOptimizedAt: new Date().toISOString(),
        },
        posts:
          generated.posts?.map((p: any, idx: number) => ({
            id: 'cp-' + Date.now() + '-' + idx,
            dayOffset: p.dayOffset || idx * 2 + 1,
            platform: (p.platform as SocialPlatform) || selectedPlatforms[idx % selectedPlatforms.length],
            hookTitle: p.hookTitle || `Variation ${idx + 1}`,
            content: p.content,
            hashtags: p.hashtags || ['B2BGrowth', 'LeadGen', 'AI'],
            suggestedCta: p.suggestedCta || `Visit ${websiteUrl} to explore more.`,
            variationLabel:
              p.variationLabel ||
              (campaignType === 'paid'
                ? `Ad Creative ${idx + 1}`
                : `Variation ${String.fromCharCode(65 + idx)}`),
            status: idx === 0 ? 'published' : 'scheduled',
            moderationStatus: 'passed',
            clicks: 0,
            signups: 0,
          })) || [],
      });

      setIsNewCampaignModalOpen(false);
      setActiveView('campaigns');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white">
                Launch Growth Campaign
              </h2>
              <p className="text-[11px] text-slate-400">
                Design autonomous organic viral loops or high-ROI paid ad campaigns
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsNewCampaignModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Campaign Type Switcher & Templates */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold uppercase text-slate-400">
              Campaign Architecture Type
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => handleApplyTemplate('organic')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
              >
                Template: AI-WONDERLAND (Organic)
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={() => handleApplyTemplate('paid')}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
              >
                Template: Enterprise Ads (Paid)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                setCampaignType('organic');
                if (budget > 0) setBudget(0);
              }}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                campaignType === 'organic'
                  ? 'bg-cyan-600/15 border-cyan-500 text-white shadow-lg ring-1 ring-cyan-500/30'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-cyan-400 flex items-center gap-1.5">
                  <Zap className="w-4 h-4" />
                  Organic Growth Campaign
                </span>
                {campaignType === 'organic' && (
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                Posts, comments/replies, conversations, followers, website traffic & signups.
              </p>
            </button>

            <button
              type="button"
              onClick={() => {
                setCampaignType('paid');
                if (budget === 0) setBudget(5000);
              }}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                campaignType === 'paid'
                  ? 'bg-indigo-600/15 border-indigo-500 text-white shadow-lg ring-1 ring-indigo-500/30'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-indigo-400 flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4" />
                  Paid Ad Campaign
                </span>
                {campaignType === 'paid' && (
                  <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                Ad creatives, budget allocation, audience targeting, CPC/CPM/CPL & ROAS.
              </p>
            </button>
          </div>
        </div>

        {/* Main Form */}
        <form onSubmit={handleGenerate} className="space-y-3.5">
          {/* Title & Website Link */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Campaign Title
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Launch AI-WONDERLAND"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1 flex items-center gap-1">
                <Globe className="w-3 h-3 text-cyan-400" />
                Website Destination CTA URL
              </label>
              <input
                type="url"
                required
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://ai-wonderland.io"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>
          </div>

          {/* Description / Value Prop */}
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Product Value Proposition & Campaign Goal
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Goal: Get website visitors + followers + signups for AI developer tools..."
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-sans"
            />
          </div>

          {/* Target Audience & Target Persona */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Target Audience
              </label>
              <input
                type="text"
                required
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                placeholder="e.g. Web developers, SaaS builders, AI developers"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Buyer Persona Profile
              </label>
              <select
                value={targetPersonaId}
                onChange={(e) => setTargetPersonaId(e.target.value)}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                {personas.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.industry})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Goal & Budget */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Primary Conversion Focus
              </label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="website_traffic">Website Visitors + Followers + Signups</option>
                <option value="lead_gen">Inbound Lead Generation</option>
                <option value="signups">Direct Product Signups</option>
                <option value="product_launch">Launch Event / Product Hunt</option>
                <option value="brand_awareness">Brand Authority & Reach</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                {campaignType === 'paid' ? 'Total Ad Budget ($)' : 'Organic Production Budget ($)'}
              </label>
              <input
                type="number"
                min={0}
                step={100}
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                placeholder={campaignType === 'paid' ? 'e.g. 5000' : '0 (Organic)'}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Platform Multi-Select */}
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1.5">
              Active Multi-Channel Distribution
            </label>
            <div className="flex flex-wrap gap-2">
              {(
                ['instagram', 'facebook', 'linkedin', 'twitter', 'tiktok', 'youtube'] as SocialPlatform[]
              ).map((p) => {
                const isSelected = selectedPlatforms.includes(p);
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => togglePlatform(p)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {p}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Autonomous Conversation Safety Guardrails Settings */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-cyan-400" />
                Autonomous Conversation Guardrails
              </span>
              <span className="text-[10px] text-cyan-400 font-mono">Safety Verified</span>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>Approval Workflow:</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setRequireApproval(false)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    !requireApproval
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-slate-950 text-slate-400'
                  }`}
                >
                  Auto-Pilot (Intent &gt; 80%)
                </button>
                <button
                  type="button"
                  onClick={() => setRequireApproval(true)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    requireApproval
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-slate-950 text-slate-400'
                  }`}
                >
                  Require Human SDR Review
                </button>
              </div>
            </div>
            <p className="text-[11px] text-slate-400">
              The AI acts as a consultative sales/community assistant (never a spam bot). It monitors replies, detects buying intent, and delivers the website link safely.
            </p>
          </div>

          {/* Custom AI Instructions */}
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Custom AI Directives & Copy Angles
            </label>
            <input
              type="text"
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              placeholder="e.g. Include website CTA, reuse successful hooks, and generate A/B variations"
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsNewCampaignModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isGenerating}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>
                {isGenerating
                  ? 'Synthesizing Strategy, Posts & Guardrails...'
                  : `Launch ${campaignType === 'organic' ? 'Organic Growth' : 'Paid Ad'} Campaign`}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

