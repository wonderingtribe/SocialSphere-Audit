import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sparkles,
  Users,
  Target,
  Building,
  Briefcase,
  Sliders,
  Flame,
} from 'lucide-react';

export const NewPersonaModal: React.FC = () => {
  const { isNewPersonaModalOpen, setIsNewPersonaModalOpen, generatePersona, setActiveView } = useApp();

  const [industry, setIndustry] = useState('B2B SaaS / Enterprise Cloud');
  const [targetRole, setTargetRole] = useState('VP of Sales / Head of Revenue');
  const [companySize, setCompanySize] = useState('50 - 250 employees');
  const [productDescription, setProductDescription] = useState(
    'AI-powered social sentiment intelligence and automated comment-to-CRM pipeline generator that accelerates demo bookings by 3x'
  );
  const [tonePreference, setTonePreference] = useState(
    'Data-backed, executive, high-conviction, ROI-focused'
  );
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isNewPersonaModalOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!industry.trim() || !targetRole.trim()) return;

    setIsGenerating(true);
    try {
      await generatePersona({
        industry,
        targetRole,
        companySize,
        productDescription,
        tonePreference,
      });
      setIsNewPersonaModalOpen(false);
      setActiveView('personas');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white">
                AI Customer Persona Builder
              </h2>
              <p className="text-[11px] text-slate-400">
                Synthesize detailed psychological buyer profiles, pain points, and hooks using Gemini
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsNewPersonaModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleGenerate} className="space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1 flex items-center gap-1">
                <Building className="w-3 h-3 text-indigo-400" />
                Target Industry
              </label>
              <input
                type="text"
                required
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                placeholder="e.g. B2B SaaS, Cybersecurity, Fintech"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1 flex items-center gap-1">
                <Briefcase className="w-3 h-3 text-indigo-400" />
                Target Role / Decision Maker
              </label>
              <input
                type="text"
                required
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                placeholder="e.g. Chief Marketing Officer, Founder & CEO"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Company Size / Growth Stage
              </label>
              <input
                type="text"
                value={companySize}
                onChange={(e) => setCompanySize(e.target.value)}
                placeholder="e.g. 20 - 150 employees (Series A/B)"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1 flex items-center gap-1">
                <Sliders className="w-3 h-3 text-indigo-400" />
                Preferred Communication Tone
              </label>
              <input
                type="text"
                value={tonePreference}
                onChange={(e) => setTonePreference(e.target.value)}
                placeholder="e.g. Data-driven, ROI-focused, Direct"
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Your Product Description & Key Value Proposition
            </label>
            <textarea
              rows={3}
              value={productDescription}
              onChange={(e) => setProductDescription(e.target.value)}
              placeholder="Describe what your product does and the core problems it solves..."
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
            />
          </div>

          {/* Prompt Highlights Preview */}
          <div className="p-3 rounded-xl bg-indigo-950/25 border border-indigo-900/30 text-xs text-indigo-200 space-y-1">
            <span className="font-bold text-indigo-300 flex items-center gap-1 text-[11px]">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              What Gemini Will Generate Automatically:
            </span>
            <ul className="grid grid-cols-2 gap-1 text-[11px] text-slate-300">
              <li>• Core psychological pain points</li>
              <li>• Buying triggers & objections</li>
              <li>• High-converting headline hooks</li>
              <li>• Trigger keywords & channel weights</li>
            </ul>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsNewPersonaModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isGenerating}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'Synthesizing Persona...' : 'Generate Complete Persona'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
