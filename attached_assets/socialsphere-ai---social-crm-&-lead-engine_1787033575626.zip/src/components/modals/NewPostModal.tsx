import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SocialPlatform } from '../../types';
import { tailorContentApi, moderateContentApi } from '../../services/geminiService';
import {
  X,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Send,
  Calendar,
  Wand2,
  Check,
  Target,
} from 'lucide-react';

export const NewPostModal: React.FC = () => {
  const {
    isNewPostModalOpen,
    setIsNewPostModalOpen,
    personas,
    activePersona,
    addPost,
    brandSafetyPolicy,
  } = useApp();

  const [platform, setPlatform] = useState<SocialPlatform>('linkedin');
  const [targetPersonaId, setTargetPersonaId] = useState(
    activePersona?.id || personas[0]?.id || ''
  );
  const [content, setContent] = useState('');
  const [topic, setTopic] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAuditing, setIsAuditing] = useState(false);
  const [moderationReport, setModerationReport] = useState<any>(null);

  if (!isNewPostModalOpen) return null;

  const selectedPersona = personas.find((p) => p.id === targetPersonaId) || personas[0];

  const handleGenerateWithAi = async () => {
    if (!selectedPersona) return;
    setIsGenerating(true);
    try {
      const res = await tailorContentApi({
        persona: selectedPersona,
        topic: topic || 'Why speed to lead on social comments drives 3x more pipeline than cold email',
        platform,
        goal: 'lead_gen',
      });
      setContent(res.tailoredContent);

      // Automatically run moderation on generated text!
      const mod = await moderateContentApi({
        content: res.tailoredContent,
        platform,
        brandRules: brandSafetyPolicy,
      });
      setModerationReport(mod);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAuditContent = async () => {
    if (!content.trim()) return;
    setIsAuditing(true);
    try {
      const mod = await moderateContentApi({
        content,
        platform,
        brandRules: brandSafetyPolicy,
      });
      setModerationReport(mod);
    } finally {
      setIsAuditing(false);
    }
  };

  const handleApplySanitized = () => {
    if (moderationReport?.autoSanitizedContent) {
      setContent(moderationReport.autoSanitizedContent);
      setModerationReport((prev: any) =>
        prev
          ? {
              ...prev,
              status: 'passed',
              safetyScore: 98,
              brandAlignmentScore: 95,
              flags: [],
            }
          : null
      );
    }
  };

  const handleSubmit = (status: 'published' | 'scheduled') => {
    if (!content.trim()) return;

    addPost({
      platform,
      content,
      author: 'You',
      scheduledAt: new Date(Date.now() + 86400000).toISOString(),
      status,
      targetPersonaId: selectedPersona?.id,
      hashtags: ['B2BGrowth', 'LeadGen', 'SocialSelling'],
    });

    setIsNewPostModalOpen(false);
    setContent('');
    setTopic('');
    setModerationReport(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white">
                Create Brand-Safe Social Post
              </h2>
              <p className="text-[11px] text-slate-400">
                Craft copy tailored to target personas with real-time pre-publish moderation
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsNewPostModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Configuration Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Publishing Channel
            </label>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value as SocialPlatform)}
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none capitalize"
            >
              {['linkedin', 'twitter', 'instagram', 'tiktok', 'facebook'].map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Target Buyer Persona
            </label>
            <select
              value={targetPersonaId}
              onChange={(e) => setTargetPersonaId(e.target.value)}
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            >
              {personas.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.industry})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* AI Prompt / Topic Input */}
        <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase text-cyan-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Prompt Gemini with Topic or Value Proposition
            </span>
            <span className="text-[10px] text-slate-400">Auto-tuned to buyer tone</span>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. 3 reasons comment response speed triples demo booking rates..."
              className="flex-1 bg-[#0B0D11] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={handleGenerateWithAi}
              disabled={isGenerating}
              className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-sm transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'Synthesizing...' : 'Generate with AI'}</span>
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold uppercase text-slate-400">Post Content</label>
            <button
              onClick={handleAuditContent}
              disabled={isAuditing || !content.trim()}
              className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Audit Brand Safety</span>
            </button>
          </div>

          <textarea
            rows={5}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write or refine your post copy..."
            className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
          />
        </div>

        {/* Live Moderation Status Banner */}
        {moderationReport && (
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">Pre-Publish Safety Status:</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    moderationReport.status === 'passed'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : moderationReport.status === 'warning'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {moderationReport.status}
                </span>
              </div>
              <span className="text-xs font-mono text-emerald-400">
                Safety: {moderationReport.safetyScore}%
              </span>
            </div>

            {moderationReport.flags?.length > 0 && (
              <div className="space-y-1 text-xs text-rose-300">
                {moderationReport.flags.map((f: any) => (
                  <div key={f.id} className="flex items-start gap-1">
                    <span className="text-rose-400">•</span>
                    <span>{f.issue}</span>
                  </div>
                ))}
              </div>
            )}

            {moderationReport.autoSanitizedContent && moderationReport.status !== 'passed' && (
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-cyan-300">AI auto-sanitized version ready</span>
                <button
                  onClick={handleApplySanitized}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Wand2 className="w-3 h-3" />
                  <span>Apply Clean Fix</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
          <button
            onClick={() => setIsNewPostModalOpen(false)}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={() => handleSubmit('scheduled')}
            disabled={!content.trim()}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
          >
            Schedule for Later
          </button>
          <button
            onClick={() => handleSubmit('published')}
            disabled={!content.trim()}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50"
          >
            Publish Live Post
          </button>
        </div>
      </div>
    </div>
  );
};
