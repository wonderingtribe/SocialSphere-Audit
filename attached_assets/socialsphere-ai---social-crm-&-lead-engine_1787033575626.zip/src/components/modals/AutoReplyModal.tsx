import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sparkles,
  Send,
  ShieldCheck,
  Zap,
  Target,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

export const AutoReplyModal: React.FC = () => {
  const {
    isAutoReplyModalOpen,
    setIsAutoReplyModalOpen,
    selectedMessageForReply,
    replyToMessage,
    personas,
    activePersona,
  } = useApp();

  const [replyText, setReplyText] = useState('');
  const [selectedPersonaId, setSelectedPersonaId] = useState(
    activePersona?.id || personas[0]?.id || ''
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAutoReplyModalOpen || !selectedMessageForReply) return null;

  const sentiment = selectedMessageForReply.sentimentAnalysis;

  const handleApplyOption = (text: string) => {
    setReplyText(text);
  };

  const handleSend = async () => {
    if (!replyText.trim()) return;
    setIsSubmitting(true);
    try {
      await replyToMessage(selectedMessageForReply.id, replyText, true);
      setIsAutoReplyModalOpen(false);
      setReplyText('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Zap className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white">
                AI Smart Reply & Sentiment Responder
              </h2>
              <p className="text-[11px] text-slate-400">
                Responding to {selectedMessageForReply.authorName} on {selectedMessageForReply.platform}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAutoReplyModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Incoming Message Snippet */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-bold text-white">
              {selectedMessageForReply.authorName}{' '}
              <span className="text-slate-400 font-normal">({selectedMessageForReply.authorRole || 'Prospect'})</span>
            </span>
            {sentiment && (
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                  sentiment.sentiment === 'positive'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : sentiment.sentiment === 'negative'
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                }`}
              >
                {sentiment.sentiment} ({Math.round(sentiment.confidenceScore * 100)}%)
              </span>
            )}
          </div>
          <p className="text-xs text-slate-300 italic">"{selectedMessageForReply.content}"</p>
        </div>

        {/* Tactical Recommendation */}
        {sentiment && (
          <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-900/40 text-xs text-blue-200 space-y-1">
            <strong className="text-cyan-300 block">AI Strategic Battlecard:</strong>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {sentiment.recommendedAction}
            </p>
          </div>
        )}

        {/* Suggested AI Angles */}
        {sentiment?.suggestedReplies && (
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase text-slate-400">
              Recommended AI Reply Angles (Click to use)
            </label>
            <div className="space-y-2">
              {sentiment.suggestedReplies.map((opt, i) => (
                <div
                  key={i}
                  onClick={() => handleApplyOption(opt)}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/60 text-xs text-slate-200 cursor-pointer transition-all hover:bg-slate-900/80 space-y-1"
                >
                  <span className="text-[10px] font-bold text-blue-400 block">
                    Option {i + 1}: {i === 0 ? 'Empathetic & Direct' : i === 1 ? 'Proof & Data' : 'Instant Demo Link'}
                  </span>
                  <p>{opt}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Composer Box */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold uppercase text-slate-400">
              Final Outbound Reply
            </label>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Automated Safety Scanner Active
            </span>
          </div>

          <textarea
            rows={3}
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder="Type or customize your reply..."
            className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
          />
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={() => setIsAutoReplyModalOpen(false)}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSend}
            disabled={isSubmitting || !replyText.trim()}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50"
          >
            <Send className={`w-3.5 h-3.5 ${isSubmitting ? 'animate-spin' : ''}`} />
            <span>{isSubmitting ? 'Verifying & Sending...' : 'Send Verified Reply'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
