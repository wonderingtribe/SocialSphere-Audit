import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Calendar,
  Clock,
  Video,
  User,
} from 'lucide-react';

export const ScheduleModal: React.FC = () => {
  const {
    isScheduleModalOpen,
    setIsScheduleModalOpen,
    selectedLeadForSchedule,
    addFollowUp,
    updateLeadStatus,
    teamMembers,
  } = useApp();

  const [title, setTitle] = useState(
    selectedLeadForSchedule
      ? `Executive Demo & Workflow Walkthrough: ${selectedLeadForSchedule.company}`
      : 'Executive Product Demo'
  );
  const [scheduledAt, setScheduledAt] = useState(
    new Date(Date.now() + 86400000).toISOString().slice(0, 16)
  );
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [assignedTo, setAssignedTo] = useState(teamMembers[0]?.name || 'Sarah Jenkins');
  const [notes, setNotes] = useState(
    selectedLeadForSchedule?.notes || 'Discuss custom HubSpot two-way sync and team seat pricing.'
  );

  if (!isScheduleModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    addFollowUp({
      leadId: selectedLeadForSchedule?.id || 'general-demo',
      leadName: selectedLeadForSchedule
        ? `${selectedLeadForSchedule.name} (${selectedLeadForSchedule.company})`
        : 'Prospect Demo',
      title,
      type: 'demo',
      scheduledAt: new Date(scheduledAt).toISOString(),
      durationMinutes,
      assignedTo,
      notes,
      status: 'scheduled',
    });

    if (selectedLeadForSchedule) {
      updateLeadStatus(selectedLeadForSchedule.id, 'demo_scheduled');
    }

    setIsScheduleModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#121620] border border-slate-800 rounded-2xl w-full max-w-lg p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white">Book Executive Demo Call</h2>
              <p className="text-[11px] text-slate-400">
                {selectedLeadForSchedule ? `With ${selectedLeadForSchedule.name} (${selectedLeadForSchedule.company})` : 'Schedule prospect walkthrough'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsScheduleModalOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Meeting Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Date & Time
              </label>
              <input
                type="datetime-local"
                required
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                Assigned AE / Rep
              </label>
              <select
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
              >
                {teamMembers.map((tm) => (
                  <option key={tm.id} value={tm.name}>
                    {tm.name} ({tm.role})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Agenda & Prospect Notes
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-purple-500 leading-relaxed font-sans"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsScheduleModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/25 transition-all cursor-pointer"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Confirm Demo Invitation</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
