import React, { useState } from 'react';
import { Campaign, SocialPlatform } from '../../types';
import { useApp } from '../../context/AppContext';
import { simulateAutonomousReplyApi } from '../../services/geminiService';
import {
  MessageSquare,
  Sparkles,
  ShieldCheck,
  Zap,
  Globe,
  UserCheck,
  Send,
  AlertCircle,
  Play,
  CheckCircle2,
  Lock,
  ArrowRight,
} from 'lucide-react';

interface AutonomousConversationEngineProps {
  campaign: Campaign;
}

export const AutonomousConversationEngine: React.FC<AutonomousConversationEngineProps> = ({
  campaign,
}) => {
  const { addLead, setActiveView } = useApp();

  const [testComment, setTestComment] = useState(
    'Where can I try this out? Does it support instant React + Node fullstack container deployments?'
  );
  const [commenterName, setCommenterName] = useState('Sarah Chen (Lead Dev)');
  const [platform, setPlatform] = useState<SocialPlatform>('linkedin');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simResult, setSimResult] = useState<{
    intentType: string;
    intentScore: number;
    shouldSendLink: boolean;
    replyText: string;
    guardrailCheckPassed: boolean;
    guardrailNotes: string;
    nextPipelineStep: string;
    detectedFunnelStage: string;
  } | null>(null);

  const [autoPilot, setAutoPilot] = useState(
    !campaign.autonomousConversations?.requireApproval
  );
  const [intentThreshold, setIntentThreshold] = useState(
    campaign.autonomousConversations?.buyingIntentThreshold || 80
  );

  const guardrails = campaign.autonomousConversations?.safetyGuardrails || [
    'Act strictly as a helpful, consultative community and tech advisor, never an aggressive sales bot',
    'Detect technical questions and answer accurately based on verified platform documentation',
    'Only send the website signup link when explicit interest or buying intent is detected (>80%)',
    'Automated brand safety pre-check before dispatching any comment reply',
  ];

  const handleSimulate = async () => {
    if (!testComment.trim()) return;

    setIsSimulating(true);
    try {
      const res = await simulateAutonomousReplyApi({
        commentText: testComment,
        authorName: commenterName,
        platform,
        websiteUrl: campaign.websiteUrl || 'https://ai-wonderland.io',
        campaignTitle: campaign.title,
        guardrails,
        buyingIntentThreshold: intentThreshold,
      });

      setSimResult(res);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleTransferToLeadManager = () => {
    if (!simResult) return;
    const today = new Date().toISOString().split('T')[0];

    addLead({
      name: commenterName,
      email: `${commenterName.toLowerCase().replace(/[^a-z]/g, '')}@techcorp.io`,
      company: 'TechCorp Engineering',
      role: 'Staff Frontend Engineer',
      sourcePlatform: platform,
      status: 'qualified',
      leadScore: simResult.intentScore,
      sentimentTrend: [
        {
          date: today,
          sentiment: 'positive',
          score: simResult.intentScore / 100,
          note: `Autonomous Conversation from ${campaign.title}: "${testComment}"`,
        },
      ],
      interactionCount: 2,
      estimatedValue: 4800,
      assignedTo: 'Growth SDR Team',
      notes: `Inbound intent: ${simResult.intentType}. AI Reply sent: "${simResult.replyText}". Target URL delivered: ${campaign.websiteUrl}`,
      lastContacted: today,
    });

    setActiveView('leads');
  };

  return (
    <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <MessageSquare className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">
              Autonomous Conversation & Social Assistant Engine
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitors incoming comments/replies, detects intent, provides consultative support, and routes to website CTA.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border flex items-center gap-1.5 ${
              autoPilot
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                autoPilot ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`}
            />
            {autoPilot ? 'Auto-Pilot Mode Active' : 'Human SDR Review Required'}
          </span>
        </div>
      </div>

      {/* Configuration & Guardrails Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Guardrails Card */}
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Safety & Brand Guardrails
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">Anti-Spam Verified</span>
          </div>

          <ul className="space-y-1.5 text-xs text-slate-300">
            {guardrails.map((g, i) => (
              <li key={i} className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                <span>{g}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Intent Threshold & Controls */}
        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-cyan-400" />
              Intent Detection & Trigger Rules
            </span>
            <span className="text-xs font-mono font-bold text-cyan-400">
              {intentThreshold}% Intent Threshold
            </span>
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Casual Discussion</span>
              <span>Website CTA Link Trigger</span>
            </div>
            <input
              type="range"
              min={50}
              max={95}
              value={intentThreshold}
              onChange={(e) => setIntentThreshold(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800">
            <span className="text-slate-400">Delivery Target URL:</span>
            <span className="font-mono text-cyan-400 text-[11px] truncate max-w-[200px]">
              {campaign.websiteUrl || 'https://ai-wonderland.io'}
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Simulator Card */}
      <div className="p-4 rounded-xl bg-[#0E121B] border border-cyan-500/25 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Live Interactive Conversation Simulator
            </h4>
          </div>
          <span className="text-[11px] text-slate-400">
            Test how the AI assistant responds to prospects
          </span>
        </div>

        {/* Simulator Input Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Commenter Name
            </label>
            <input
              type="text"
              value={commenterName}
              onChange={(e) => setCommenterName(e.target.value)}
              className="w-full bg-[#08090D] border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
              Platform Channel
            </label>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value as SocialPlatform)}
              className="w-full bg-[#08090D] border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
            >
              <option value="linkedin">LinkedIn</option>
              <option value="twitter">X / Twitter</option>
              <option value="instagram">Instagram</option>
              <option value="tiktok">TikTok</option>
              <option value="facebook">Facebook</option>
            </select>
          </div>

          <div className="sm:col-span-1 flex items-end">
            <button
              onClick={handleSimulate}
              disabled={isSimulating}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md shadow-cyan-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              <Play className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
              <span>{isSimulating ? 'Evaluating...' : 'Simulate Response'}</span>
            </button>
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
            Prospect Incoming Comment / Reply
          </label>
          <textarea
            rows={2}
            value={testComment}
            onChange={(e) => setTestComment(e.target.value)}
            className="w-full bg-[#08090D] border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-sans"
            placeholder="Type any incoming comment from a user..."
          />
        </div>

        {/* Quick Sample Prompts */}
        <div className="flex flex-wrap gap-2 text-[11px]">
          <span className="text-slate-400 self-center">Sample Inquiries:</span>
          <button
            type="button"
            onClick={() =>
              setTestComment(
                'Where can I try this out? Does it support instant React + Node container deployments?'
              )
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 cursor-pointer"
          >
            "Where can I try this out?"
          </button>
          <button
            type="button"
            onClick={() =>
              setTestComment('What is the pricing model for teams with 5+ developers?')
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 cursor-pointer"
          >
            "What is the pricing?"
          </button>
          <button
            type="button"
            onClick={() =>
              setTestComment(
                'Is this just another wrapper or does it run full stack isolated sandboxes?'
              )
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 cursor-pointer"
          >
            "Technical comparison"
          </button>
        </div>

        {/* Simulation Output Card */}
        {simResult && (
          <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/40 space-y-3 animate-in fade-in">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 uppercase font-mono">
                  {simResult.intentType.replace(/_/g, ' ')}
                </span>
                <span className="text-xs font-bold text-white font-mono">
                  Intent Score: {simResult.intentScore}/100
                </span>
                <span className="text-xs text-slate-400">
                  • Funnel: <strong className="text-emerald-400">{simResult.detectedFunnelStage}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2">
                {simResult.shouldSendLink ? (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                    <Globe className="w-3 h-3" />
                    Website Link Sent
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400">
                    Nurture (No Link Yet)
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">
                Generated AI Assistant Reply (Non-Robotic / Consultative):
              </span>
              <p className="text-xs text-white bg-[#08090D] p-3 rounded-xl border border-slate-800 leading-relaxed font-sans">
                {simResult.replyText}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400 pt-1">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Next Pipeline Step: <strong className="text-white">{simResult.nextPipelineStep}</strong></span>
              </div>

              <button
                onClick={handleTransferToLeadManager}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition-all cursor-pointer self-start sm:self-auto"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Move to Social CRM Leads</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
