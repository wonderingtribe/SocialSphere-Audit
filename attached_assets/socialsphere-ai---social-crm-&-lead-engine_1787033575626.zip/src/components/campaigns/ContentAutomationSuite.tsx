import React, { useState } from 'react';
import { Campaign, CampaignPostItem, SocialPlatform } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  Sparkles,
  Layers,
  Repeat,
  Plus,
  ShieldCheck,
  Globe,
  CheckCircle2,
  ExternalLink,
  Share2,
} from 'lucide-react';

interface ContentAutomationSuiteProps {
  campaign: Campaign;
}

export const ContentAutomationSuite: React.FC<ContentAutomationSuiteProps> = ({
  campaign,
}) => {
  const { setIsNewPostModalOpen, createPost } = useApp();
  const [selectedVariation, setSelectedVariation] = useState<string | null>(null);

  const posts = campaign.posts || [];
  const isPaid = campaign.type === 'paid';

  const handleReuseContent = (post: CampaignPostItem) => {
    // Generate a fresh variation of successful content
    createPost({
      platform: post.platform,
      content: `${post.content}\n\n[Re-engineered from winning campaign hook: "${post.hookTitle}"]\n🚀 Visit ${campaign.websiteUrl || 'https://ai-wonderland.io'} to get started today.`,
      hashtags: [...post.hashtags, 'TrendingGrowth'],
      mediaUrls: [],
      scheduledTime: new Date(Date.now() + 48 * 3600000).toISOString(),
    });
  };

  return (
    <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Layers className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">
              📅 Content & Creative Variations Engine
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Create posts, schedule variations, reuse high-performing hooks, and embed website CTAs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNewPostModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Variation</span>
          </button>
        </div>
      </div>

      {/* Posts & Variations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {posts.map((post, idx) => (
          <div
            key={post.id || idx}
            className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between space-y-3 relative hover:border-slate-700 transition-all"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center text-xs font-bold font-mono">
                    D{post.dayOffset}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 capitalize">
                    {post.platform}
                  </span>
                </div>

                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                  {post.variationLabel || `Variation ${String.fromCharCode(65 + idx)}`}
                </span>
              </div>

              <h4 className="text-xs font-bold text-white line-clamp-2">
                {post.hookTitle}
              </h4>

              <p className="text-xs text-slate-300 leading-relaxed font-sans line-clamp-3">
                {post.content}
              </p>
            </div>

            {/* CTA & Actions */}
            <div className="space-y-2 pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Website CTA:</span>
                <span className="text-cyan-400 font-mono font-medium truncate max-w-[170px]">
                  {post.suggestedCta || campaign.websiteUrl}
                </span>
              </div>

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Passed
                  </span>
                  <span className="text-[10px] text-slate-400 capitalize">
                    {post.status || 'scheduled'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleReuseContent(post)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold transition-all cursor-pointer"
                  title="Reuse this hook & generate a new post"
                >
                  <Repeat className="w-3 h-3 text-cyan-400" />
                  <span>Reuse Hook</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
