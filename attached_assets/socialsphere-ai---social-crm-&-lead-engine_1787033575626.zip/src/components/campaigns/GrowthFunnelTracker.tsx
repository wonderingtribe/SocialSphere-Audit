import React from 'react';
import { Campaign, CampaignConversionFunnel } from '../../types';
import {
  TrendingUp,
  Users,
  MessageSquare,
  Sparkles,
  Globe,
  UserCheck,
  Zap,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

interface GrowthFunnelTrackerProps {
  campaign: Campaign;
}

export const GrowthFunnelTracker: React.FC<GrowthFunnelTrackerProps> = ({
  campaign,
}) => {
  const funnel: CampaignConversionFunnel = campaign.conversionFunnel || {
    followers: 1200,
    engaged: 840,
    interested: 420,
    websiteVisitors: 2600,
    leads: 180,
    signups: 310,
  };

  const isPaid = campaign.type === 'paid';

  const stages = [
    {
      id: 'followers',
      label: 'Followers / Audience',
      count: funnel.followers,
      subtext: 'Cross-platform audience pool',
      icon: Users,
      color: 'from-blue-500/20 to-blue-600/10 text-blue-400 border-blue-500/30',
      badge: 'Top of Funnel',
    },
    {
      id: 'engaged',
      label: 'Engaged',
      count: funnel.engaged,
      subtext: 'Likes, shares & discussions',
      icon: MessageSquare,
      color: 'from-cyan-500/20 to-cyan-600/10 text-cyan-400 border-cyan-500/30',
      conversionRate: Math.round((funnel.engaged / Math.max(funnel.followers, 1)) * 100),
      badge: 'Social Touchpoint',
    },
    {
      id: 'interested',
      label: 'Interested',
      count: funnel.interested,
      subtext: 'Questions & high buying intent',
      icon: Sparkles,
      color: 'from-purple-500/20 to-purple-600/10 text-purple-400 border-purple-500/30',
      conversionRate: Math.round((funnel.interested / Math.max(funnel.engaged, 1)) * 100),
      badge: 'High Intent',
    },
    {
      id: 'websiteVisitors',
      label: 'Website Visitors',
      count: funnel.websiteVisitors,
      subtext: `Clicks to ${campaign.websiteUrl || 'website'}`,
      icon: Globe,
      color: 'from-amber-500/20 to-amber-600/10 text-amber-400 border-amber-500/30',
      conversionRate: Math.round((funnel.websiteVisitors / Math.max(funnel.interested + funnel.engaged, 1)) * 100),
      badge: 'CTA Link Triggered',
    },
    {
      id: 'leads',
      label: 'Qualified Leads',
      count: funnel.leads,
      subtext: 'Captured into Social CRM',
      icon: UserCheck,
      color: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400 border-emerald-500/30',
      conversionRate: Math.round((funnel.leads / Math.max(funnel.websiteVisitors, 1)) * 100),
      badge: 'CRM Synced',
    },
    {
      id: 'signups',
      label: 'Signups / Customers',
      count: funnel.signups,
      subtext: 'Activated accounts & demo wins',
      icon: Zap,
      color: 'from-rose-500/20 to-rose-600/10 text-rose-400 border-rose-500/30',
      conversionRate: Math.round((funnel.signups / Math.max(funnel.leads, 1)) * 100),
      badge: 'Final Conversion',
    },
  ];

  return (
    <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">
              Growth Funnel & Conversion Attribution
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time pipeline: Follower → Engaged → Interested → Website Visitor → Lead → Signup
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-900 border border-slate-800 text-slate-300">
            Total Signups:{' '}
            <strong className="text-emerald-400 font-mono text-xs ml-1">{funnel.signups}</strong>
          </span>
          <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-slate-900 border border-slate-800 text-slate-300">
            Website Visitors:{' '}
            <strong className="text-cyan-400 font-mono text-xs ml-1">{funnel.websiteVisitors.toLocaleString()}</strong>
          </span>
        </div>
      </div>

      {/* Funnel Flow Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        {stages.map((stage, idx) => {
          const Icon = stage.icon;
          return (
            <div
              key={stage.id}
              className={`p-3.5 rounded-xl border bg-gradient-to-b ${stage.color} flex flex-col justify-between relative space-y-2`}
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Step 0{idx + 1}
                  </span>
                  <Icon className="w-4 h-4 opacity-80" />
                </div>

                <span className="text-[11px] font-bold text-slate-200 block truncate">
                  {stage.label}
                </span>
                <span className="text-lg font-black text-white font-mono block">
                  {stage.count.toLocaleString()}
                </span>
              </div>

              <div className="pt-2 border-t border-slate-800/40">
                <p className="text-[10px] text-slate-400 truncate">{stage.subtext}</p>
                {stage.conversionRate !== undefined && (
                  <div className="flex items-center justify-between text-[10px] text-slate-300 mt-1 font-mono">
                    <span>Conv:</span>
                    <span className="text-emerald-400 font-bold">{stage.conversionRate}%</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Campaign Highlights & Integration Tracking */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">
            Destination Website Link
          </span>
          <a
            href={campaign.websiteUrl || 'https://ai-wonderland.io'}
            target="_blank"
            rel="noreferrer"
            className="text-cyan-400 hover:underline font-mono truncate block"
          >
            {campaign.websiteUrl || 'https://ai-wonderland.io'}
          </a>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">
            Target Audience Focus
          </span>
          <p className="text-white font-semibold truncate">{campaign.targetAudience}</p>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">
            CRM & Webhook Sync
          </span>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              HubSpot + Salesforce Active
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
