import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ModerationReport, SocialPlatform } from '../types';
import { moderateContentApi } from '../services/geminiService';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Sliders,
  AlertOctagon,
  Wand2,
  Check,
  X,
  RefreshCw,
  Plus,
  Trash2,
  Lock,
  FileCheck,
  Search,
} from 'lucide-react';

export const ModerationView: React.FC = () => {
  const {
    moderationReports,
    brandSafetyPolicy,
    updateBrandSafetyPolicy,
    applySanitizedFix,
    approveReport,
    rejectReport,
  } = useApp();

  // Live Scanner State
  const [scanInput, setScanInput] = useState(
    'Stop working 80 hours a week. Our AI software guarantees you will make $50,000 in your first 7 days with zero effort. Click the link now before this secret hack gets taken down!'
  );
  const [scanPlatform, setScanPlatform] = useState<SocialPlatform>('linkedin');
  const [liveReport, setLiveReport] = useState<ModerationReport | null>(null);
  const [isScanning, setIsScanning] = useState(false);

  // Filter queue
  const [filterStatus, setFilterStatus] = useState<'all' | 'flagged' | 'warning' | 'passed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Policy Keyword Input
  const [newKeyword, setNewKeyword] = useState('');

  const handleRunScan = async () => {
    if (!scanInput.trim()) return;
    setIsScanning(true);
    try {
      const res = await moderateContentApi({
        content: scanInput,
        platform: scanPlatform,
        brandRules: brandSafetyPolicy,
      });
      setLiveReport(res);
    } finally {
      setIsScanning(false);
    }
  };

  const handleApplyLiveSanitize = () => {
    if (liveReport?.autoSanitizedContent) {
      setScanInput(liveReport.autoSanitizedContent);
      setLiveReport((prev) =>
        prev
          ? {
              ...prev,
              status: 'passed',
              safetyScore: 98,
              brandAlignmentScore: 96,
              flags: [],
              appliedFix: true,
            }
          : null
      );
    }
  };

  const handleAddKeyword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyword.trim()) return;
    if (!brandSafetyPolicy.bannedKeywords.includes(newKeyword.trim().toLowerCase())) {
      updateBrandSafetyPolicy({
        bannedKeywords: [...brandSafetyPolicy.bannedKeywords, newKeyword.trim().toLowerCase()],
      });
    }
    setNewKeyword('');
  };

  const handleRemoveKeyword = (kw: string) => {
    updateBrandSafetyPolicy({
      bannedKeywords: brandSafetyPolicy.bannedKeywords.filter((k) => k !== kw),
    });
  };

  const filteredQueue = moderationReports.filter((r) => {
    if (filterStatus !== 'all' && r.status !== filterStatus) return false;
    if (searchQuery && !r.content.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-600/15 border border-amber-500/30">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white">
              AI Content Moderation & Brand Safety Engine
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Real-time multi-layer policy enforcement: claim verification, tone compliance, grammar auditing, and instant AI auto-sanitization.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Policy Mode</span>
            <span className="text-xs font-extrabold text-amber-400 capitalize">
              {brandSafetyPolicy.strictness} Protection
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400">
            <Lock className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Top Split: Live Pre-Publish Scanner + Policy Configurator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (7 cols): Interactive Live Content Scanner */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">
                  Live Pre-Publish Compliance Scanner & Sanitizer
                </h3>
              </div>
              <span className="text-[11px] text-cyan-300 font-mono">Real-Time Audit</span>
            </div>

            {/* Input box */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-bold uppercase text-slate-400">
                  Draft Copy / Outbound Comment / Message
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400">Channel:</span>
                  <select
                    value={scanPlatform}
                    onChange={(e) => setScanPlatform(e.target.value as SocialPlatform)}
                    className="bg-[#0B0D11] border border-slate-800 rounded px-2 py-0.5 text-[11px] text-white capitalize focus:outline-none"
                  >
                    {['linkedin', 'twitter', 'instagram', 'tiktok', 'facebook'].map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <textarea
                rows={4}
                value={scanInput}
                onChange={(e) => setScanInput(e.target.value)}
                placeholder="Type or paste any draft copy to audit against brand safety rules..."
                className="w-full bg-[#0B0D11] border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 leading-relaxed font-sans"
              />

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {scanInput.length} characters • Checked against {brandSafetyPolicy.bannedKeywords.length} prohibited terms
                </span>
                <button
                  onClick={handleRunScan}
                  disabled={isScanning || !scanInput.trim()}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold shadow-md shadow-amber-600/25 transition-all cursor-pointer disabled:opacity-50"
                >
                  <ShieldCheck className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>{isScanning ? 'Auditing with AI Guardrails...' : 'Run Compliance Audit'}</span>
                </button>
              </div>
            </div>

            {/* Live Scan Results */}
            {liveReport && (
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3.5 animate-in fade-in">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">Status:</span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold uppercase ${
                        liveReport.status === 'passed'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : liveReport.status === 'warning'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {liveReport.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs font-mono">
                    <span className="text-emerald-400">Safety: {liveReport.safetyScore}%</span>
                    <span className="text-blue-400">Brand Voice: {liveReport.brandAlignmentScore}%</span>
                    <span className="text-cyan-400">Grammar: {liveReport.grammarScore}%</span>
                  </div>
                </div>

                {/* Flags list */}
                {liveReport.flags.length > 0 ? (
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold uppercase text-rose-400 flex items-center gap-1">
                      <AlertOctagon className="w-3.5 h-3.5" />
                      Detected Compliance & Quality Violations ({liveReport.flags.length})
                    </span>
                    {liveReport.flags.map((flag) => (
                      <div
                        key={flag.id}
                        className="p-3 rounded-xl bg-rose-950/25 border border-rose-900/40 text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-rose-300 capitalize">
                            [{flag.category.replace('_', ' ')}] {flag.issue}
                          </span>
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-rose-500/20 text-rose-400 border border-rose-500/30">
                            {flag.severity}
                          </span>
                        </div>
                        <p className="text-slate-300 text-[11px]">
                          <strong className="text-cyan-400">Suggestion:</strong> {flag.suggestion}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-900/30 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Copy is 100% compliant with brand safety rules, claim guidelines, and grammar benchmarks!</span>
                  </div>
                )}

                {/* Auto-Sanitized Version */}
                {liveReport.autoSanitizedContent && liveReport.status !== 'passed' && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase text-cyan-400 flex items-center gap-1">
                        <Wand2 className="w-3.5 h-3.5" />
                        AI Auto-Sanitized Compliant Version
                      </span>
                      <button
                        onClick={handleApplyLiveSanitize}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition-all cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>1-Click Apply AI Fix</span>
                      </button>
                    </div>

                    <div className="p-3 rounded-xl bg-[#0B0D11] border border-cyan-500/30 text-xs text-slate-200 leading-relaxed font-sans">
                      {liveReport.autoSanitizedContent}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right (5 cols): Enterprise Brand Safety Policy Configurator */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">Brand Safety Policy Controls</h3>
              </div>
              <span className="text-[10px] font-mono text-slate-400">Enterprise Guardrails</span>
            </div>

            {/* Strictness Level */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase text-slate-400">
                Moderation Strictness Level
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['relaxed', 'standard', 'strict'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => updateBrandSafetyPolicy({ strictness: lvl })}
                    className={`py-2 px-2 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer text-center ${
                      brandSafetyPolicy.strictness === lvl
                        ? 'bg-amber-600 text-white shadow-md shadow-amber-600/20'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="space-y-2.5 pt-2">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <div>
                  <h4 className="text-xs font-bold text-white">Prohibit Unrealistic Guarantees</h4>
                  <p className="text-[10px] text-slate-400">Flags deceptive income claims, $ promises & 100% hype</p>
                </div>
                <input
                  type="checkbox"
                  checked={brandSafetyPolicy.prohibitGuarantees}
                  onChange={(e) => updateBrandSafetyPolicy({ prohibitGuarantees: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <div>
                  <h4 className="text-xs font-bold text-white">Require Compliance Disclaimers</h4>
                  <p className="text-[10px] text-slate-400">Enforces case study and trial disclaimers</p>
                </div>
                <input
                  type="checkbox"
                  checked={brandSafetyPolicy.requireDisclaimer}
                  onChange={(e) => updateBrandSafetyPolicy({ requireDisclaimer: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <div>
                  <h4 className="text-xs font-bold text-white">Auto-Block Flagged Content</h4>
                  <p className="text-[10px] text-slate-400">Prevents unverified posts from automated publishing</p>
                </div>
                <input
                  type="checkbox"
                  checked={brandSafetyPolicy.autoBlockFlagged}
                  onChange={(e) => updateBrandSafetyPolicy({ autoBlockFlagged: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
            </div>

            {/* Banned Keywords Chip Manager */}
            <div className="space-y-2 pt-2">
              <label className="block text-[10px] font-bold uppercase text-slate-400">
                Prohibited Keywords & Phrases ({brandSafetyPolicy.bannedKeywords.length})
              </label>

              <form onSubmit={handleAddKeyword} className="flex gap-2">
                <input
                  type="text"
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  placeholder="e.g. guaranteed revenue..."
                  className="flex-1 bg-[#0B0D11] border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold border border-slate-700 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </form>

              <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto pr-1">
                {brandSafetyPolicy.bannedKeywords.map((kw) => (
                  <span
                    key={kw}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-900 text-slate-300 border border-slate-800"
                  >
                    <span>{kw}</span>
                    <button
                      onClick={() => handleRemoveKeyword(kw)}
                      className="text-slate-500 hover:text-rose-400 ml-0.5 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Moderation Audit Queue & History */}
      <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              Historical Content Audit Queue & Review Log
            </h3>
          </div>

          {/* Filter Pills & Search */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-900 rounded-lg p-1 border border-slate-800">
              {(['all', 'flagged', 'warning', 'passed'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold capitalize transition-all cursor-pointer ${
                    filterStatus === st
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search audits..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-slate-700 w-44"
              />
            </div>
          </div>
        </div>

        {/* Audit Queue Cards */}
        <div className="space-y-3">
          {filteredQueue.map((rep) => {
            const isFlagged = rep.status === 'flagged';
            const isWarning = rep.status === 'warning';
            const isPassed = rep.status === 'passed';

            const badgeColor = isFlagged
              ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
              : isWarning
              ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
              : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';

            return (
              <div
                key={rep.id}
                className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Audit #{rep.id}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(rep.createdAt).toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${badgeColor}`}>
                      {rep.status}
                    </span>
                    <span className="text-xs font-mono text-emerald-400 font-semibold">
                      Score: {rep.safetyScore}%
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-[#0B0D11] border border-slate-800 space-y-1">
                    <span className="text-[10px] font-bold uppercase text-slate-400">Original Copy</span>
                    <p className="text-xs text-slate-300 leading-relaxed italic">"{rep.content}"</p>
                  </div>

                  <div className="p-3 rounded-xl bg-[#0B0D11] border border-slate-800 space-y-1">
                    <span className="text-[10px] font-bold uppercase text-cyan-400">Sanitized Compliant Copy</span>
                    <p className="text-xs text-slate-200 leading-relaxed font-medium">
                      "{rep.autoSanitizedContent || rep.content}"
                    </p>
                  </div>
                </div>

                {/* Flags detail */}
                {rep.flags.length > 0 && (
                  <div className="space-y-1 text-xs">
                    {rep.flags.map((f) => (
                      <div key={f.id} className="text-rose-400 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{f.issue}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                  <span className="text-[11px] text-slate-400">
                    Readability: <strong className="text-slate-300">{rep.readability}</strong>
                  </span>

                  <div className="flex items-center gap-2">
                    {!isPassed && rep.autoSanitizedContent && (
                      <button
                        onClick={() => applySanitizedFix(rep.id)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all cursor-pointer"
                      >
                        <Check className="w-3 h-3" />
                        <span>Apply AI Sanitize</span>
                      </button>
                    )}

                    {!isPassed && (
                      <button
                        onClick={() => approveReport(rep.id)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Manual Override Approve</span>
                      </button>
                    )}

                    {!isFlagged && (
                      <button
                        onClick={() => rejectReport(rep.id)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
                      >
                        <X className="w-3 h-3" />
                        <span>Flag & Reject</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
