import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Campaign, SocialPlatform } from '../types';
import {
  Megaphone,
  Sparkles,
  Plus,
  Target,
  Calendar,
  DollarSign,
  TrendingUp,
  Share2,
  Trash2,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Send,
} from 'lucide-react';

export const CampaignsView: React.FC = () => {
  const {
    campaigns,
    personas,
    deleteCampaign,
    setIsNewCampaignModalOpen,
    setIsNewPostModalOpen,
  } = useApp();

  const [selectedCampaign, setSelectedCampaign] = useState<Campaign>(
    campaigns[0] || null
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-600/15 border border-blue-500/30">
              <Megaphone className="w-5 h-5 text-blue-400" />
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white">
              Social Campaigns & Multi-Channel Sequences
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Orchestrate coordinated, persona-targeted social campaigns with automated moderation and lead attribution.
          </p>
        </div>

        <button
          onClick={() => setIsNewCampaignModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Sparkles className="w-4 h-4" />
          <span>New AI Campaign</span>
        </button>
      </div>

      {/* Campaigns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {campaigns.map((camp) => {
          const isSelected = selectedCampaign?.id === camp.id;
          const persona = personas.find((p) => p.id === camp.targetPersonaId);

          return (
            <div
              key={camp.id}
              onClick={() => setSelectedCampaign(camp)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer relative space-y-4 flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#161C2C] border-blue-500/60 shadow-xl ring-1 ring-blue-500/40'
                  : 'bg-[#121620] border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
              }`}
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-blue-500/15 text-blue-400 border border-blue-500/30">
                    {camp.status}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {camp.startDate} → {camp.endDate}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white line-clamp-1">{camp.title}</h3>
                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {camp.description}
                </p>

                {persona && (
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                    <Target className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span className="text-slate-300 truncate">
                      Target: <strong className="text-white">{persona.name}</strong>
                    </span>
                  </div>
                )}
              </div>

              {/* Stats & Platforms */}
              <div className="space-y-3 pt-3 border-t border-slate-800/80">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block">Leads Generated</span>
                    <span className="text-base font-extrabold text-emerald-400">
                      {camp.leadsGenerated || 0}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block">Conversion Rate</span>
                    <span className="text-base font-extrabold text-cyan-400">
                      {camp.conversionRate || 0}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase block">Posts Queued</span>
                    <span className="text-base font-extrabold text-indigo-400">
                      {camp.posts?.length || 0}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {camp.platforms.map((p) => (
                      <span
                        key={p}
                        className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 capitalize"
                      >
                        {p}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteCampaign(camp.id);
                    }}
                    className="p-1 text-slate-500 hover:text-rose-400"
                    title="Delete Campaign"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Campaign Post Timeline */}
      {selectedCampaign && (
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span>Multi-Day Scheduled Content Sequence: {selectedCampaign.title}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {selectedCampaign.strategySummary || 'Automated multi-channel cadence'}
              </p>
            </div>

            <button
              onClick={() => setIsNewPostModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Post to Sequence</span>
            </button>
          </div>

          <div className="space-y-3">
            {selectedCampaign.posts?.map((post, idx) => (
              <div
                key={post.id || idx}
                className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center text-xs font-bold font-mono">
                      D{post.dayOffset}
                    </span>
                    <span className="text-xs font-bold text-white capitalize">
                      {post.platform} • {post.hookTitle}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      Moderation Passed
                    </span>
                    <span className="text-[10px] text-slate-400 capitalize">
                      Status: {post.status || 'scheduled'}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {post.content}
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                  <div className="flex gap-1.5 font-mono text-blue-400">
                    {post.hashtags?.map((h, i) => (
                      <span key={i}>#{h}</span>
                    ))}
                  </div>
                  <span className="font-medium text-slate-300">
                    CTA: {post.suggestedCta}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
