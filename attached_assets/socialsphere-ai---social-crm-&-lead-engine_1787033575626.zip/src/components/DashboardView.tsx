import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GrowthTowerCanvas } from './growth/GrowthTowerCanvas';
import { RankBadgeCard } from './growth/RankBadgeCard';
import { AchievementsDrawer } from './growth/AchievementsDrawer';
import { RankUpModal } from './growth/RankUpModal';
import {
  MessageSquare,
  TrendingUp,
  ShieldCheck,
  Users,
  DollarSign,
  Sparkles,
  ArrowUpRight,
  Flame,
  AlertCircle,
  CheckCircle2,
  Send,
  UserPlus,
  RefreshCw,
  Target,
  Crown,
  Award,
  ChevronRight,
  BarChart3,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

export const DashboardView: React.FC = () => {
  const {
    messages,
    personas,
    moderationReports,
    leads,
    posts,
    setActiveView,
    setActivePersona,
    setIsNewPostModalOpen,
    setIsNewPersonaModalOpen,
    setIsAutoReplyModalOpen,
    setSelectedMessageForReply,
    convertMessageToLead,
    batchAnalyzeSentiment,
    isBatchAnalyzing,
    growthRank,
    isAchievementsDrawerOpen,
    setIsAchievementsDrawerOpen,
    rankUpEvent,
    setRankUpEvent,
  } = useApp();

  const [showSecondaryCharts, setShowSecondaryCharts] = useState(false);

  // Calculate high-level metrics
  const totalMessages = messages.length;
  const positiveCount = messages.filter(
    (m) => m.sentimentAnalysis?.sentiment === 'positive'
  ).length;
  const neutralCount = messages.filter(
    (m) => m.sentimentAnalysis?.sentiment === 'neutral'
  ).length;
  const negativeCount = messages.filter(
    (m) => m.sentimentAnalysis?.sentiment === 'negative'
  ).length;

  const positivePercent = totalMessages ? Math.round((positiveCount / totalMessages) * 100) : 0;
  const neutralPercent = totalMessages ? Math.round((neutralCount / totalMessages) * 100) : 0;
  const negativePercent = totalMessages ? Math.round((negativeCount / totalMessages) * 100) : 0;

  const totalPipeline = leads.reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);
  const avgSafetyScore = moderationReports.length
    ? Math.round(
        moderationReports.reduce((sum, r) => sum + r.safetyScore, 0) /
          moderationReports.length
      )
    : 98;

  const flaggedReports = moderationReports.filter(
    (r) => r.status === 'flagged' || r.status === 'warning'
  );

  // Chart data: 7-day sentiment trend
  const sentimentTrendData = [
    { day: 'Mon', positive: 18, neutral: 6, negative: 1, avgScore: 0.82 },
    { day: 'Tue', positive: 24, neutral: 8, negative: 3, avgScore: 0.74 },
    { day: 'Wed', positive: 31, neutral: 12, negative: 2, avgScore: 0.86 },
    { day: 'Thu', positive: 28, neutral: 9, negative: 4, avgScore: 0.79 },
    { day: 'Fri', positive: 45, neutral: 14, negative: 2, avgScore: 0.91 },
    { day: 'Sat', positive: 22, neutral: 5, negative: 1, avgScore: 0.88 },
    { day: 'Sun', positive: positiveCount + 15, neutral: neutralCount + 6, negative: negativeCount, avgScore: 0.89 },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner / Welcome & RPG Quick Action Bar */}
      <div className="bg-gradient-to-r from-[#141B2D] via-[#161D31] to-[#111624] border border-slate-800/80 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-8 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1">
                <Crown className="w-3 h-3 text-yellow-300" />
                RPG Rank: {growthRank.title} (Level {growthRank.level})
              </span>
              <span className="text-xs text-slate-400">1,284 NPCs Climbing Tower</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              3D Social Growth Tower & Gamified Command Center
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Watch real-time followers, engaged prospects, and qualified leads physically climb the Growth Tower. Level up your account to unlock autonomous auto-pilot automations.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setIsAchievementsDrawerOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 text-xs font-bold shadow-sm transition-all cursor-pointer"
            >
              <Award className="w-3.5 h-3.5 text-yellow-300" />
              <span>Trophy Case & Quests</span>
            </button>
            <button
              onClick={batchAnalyzeSentiment}
              disabled={isBatchAnalyzing}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-200 text-xs font-semibold shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isBatchAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isBatchAnalyzing ? 'Scanning...' : 'Batch Triage'}</span>
            </button>
            <button
              onClick={() => setIsNewPostModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Draft Safe Post</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Centerpiece: 3D Growth Tower & Rank Badge System */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: 3D Growth Tower Canvas */}
        <div className="lg:col-span-2">
          <GrowthTowerCanvas />
        </div>

        {/* Right 1 Col: RPG Rank Badge & XP Card */}
        <div className="lg:col-span-1">
          <RankBadgeCard onOpenAchievements={() => setIsAchievementsDrawerOpen(true)} />
        </div>
      </div>

      {/* KPI Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Sentiment Health */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Sentiment Health</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                +14% vs LW
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">{positivePercent}%</span>
              <span className="text-xs text-emerald-400 font-semibold">Positive Inbound</span>
            </div>
            {/* Visual Sentiment Stacked Bar */}
            <div className="w-full h-2 rounded-full bg-slate-800 mt-3 flex overflow-hidden">
              <div
                style={{ width: `${positivePercent}%` }}
                className="bg-emerald-500 h-full transition-all"
                title={`Positive: ${positivePercent}%`}
              />
              <div
                style={{ width: `${neutralPercent}%` }}
                className="bg-amber-500 h-full transition-all"
                title={`Neutral: ${neutralPercent}%`}
              />
              <div
                style={{ width: `${negativePercent}%` }}
                className="bg-rose-500 h-full transition-all"
                title={`Negative: ${negativePercent}%`}
              />
            </div>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800/60">
            <span className="flex items-center gap-1 text-emerald-400">🟢 {positiveCount} Pos</span>
            <span className="flex items-center gap-1 text-amber-400">🟡 {neutralCount} Neu</span>
            <span className="flex items-center gap-1 text-rose-400">🔴 {negativeCount} Neg</span>
          </div>
        </div>

        {/* KPI 2: Verified Pipeline */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Social CRM Pipeline</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
                {leads.length} Active Leads
              </span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl sm:text-3xl font-black text-white">
                ${(totalPipeline / 1000).toFixed(1)}k
              </span>
              <span className="text-xs text-slate-400 font-medium">ARR value</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Avg deal size: ${(totalPipeline / Math.max(1, leads.length)).toLocaleString()}
            </p>
          </div>
          <button
            onClick={() => setActiveView('leads')}
            className="flex items-center justify-between text-[11px] text-blue-400 hover:text-blue-300 font-semibold mt-3 pt-2 border-t border-slate-800/60 cursor-pointer"
          >
            <span>View Social CRM Pipeline</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* KPI 3: Customer Personas */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Target Personas</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                {personas.length} Profiles
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">{personas.length}</span>
              <span className="text-xs text-indigo-400 font-semibold">Active Buyer Archetypes</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2 truncate">
              Top: {personas[0]?.name || 'SaaS Founder'}
            </p>
          </div>
          <button
            onClick={() => setActiveView('personas')}
            className="flex items-center justify-between text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold mt-3 pt-2 border-t border-slate-800/60 cursor-pointer"
          >
            <span>Explore Persona Studio</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* KPI 4: Brand Safety & Moderation */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Content Moderation</span>
              {flaggedReports.length > 0 ? (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {flaggedReports.length} Needs Review
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  100% Safe
                </span>
              )}
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">{avgSafetyScore}%</span>
              <span className="text-xs text-emerald-400 font-semibold">Brand Compliance</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              {moderationReports.length} items audited with automated guardrails
            </p>
          </div>
          <button
            onClick={() => setActiveView('moderation')}
            className="flex items-center justify-between text-[11px] text-amber-400 hover:text-amber-300 font-semibold mt-3 pt-2 border-t border-slate-800/60 cursor-pointer"
          >
            <span>Inspect Moderation Hub</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Secondary Deep Metrics & Personas Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Real-Time Sentiment Trend Area Chart */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>Multi-Channel Sentiment Velocity & Volume</span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Daily volume of positive, neutral, and negative inbound engagements across all connected platforms
              </p>
            </div>
            <span className="text-[11px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 self-start sm:self-auto">
              Net Sentiment Score: +0.84
            </span>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sentimentTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorPositive" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorNeutral" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F59E0B" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorNegative" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F43F5E" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F43F5E" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '10px',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="positive"
                  name="Positive Inbound"
                  stroke="#10B981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorPositive)"
                />
                <Area
                  type="monotone"
                  dataKey="neutral"
                  name="Neutral Inquiries"
                  stroke="#F59E0B"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorNeutral)"
                />
                <Area
                  type="monotone"
                  dataKey="negative"
                  name="Objections / Issues"
                  stroke="#F43F5E"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorNegative)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-4 mt-2 border-t border-slate-800/80 text-center">
            <div className="p-2 rounded-xl bg-slate-900/50">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Positive Conversion</span>
              <p className="text-base font-extrabold text-emerald-400 mt-0.5">38.4%</p>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/50">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Avg Response Latency</span>
              <p className="text-base font-extrabold text-cyan-400 mt-0.5">3.8 mins</p>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/50">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Triage Accuracy</span>
              <p className="text-base font-extrabold text-indigo-400 mt-0.5">99.2%</p>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Customer Personas Performance Leaderboard */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Target className="w-4 h-4 text-indigo-400" />
                  <span>Persona Lead Velocity</span>
                </h2>
                <p className="text-[11px] text-slate-400">Resonance & conversion by buyer archetype</p>
              </div>
              <button
                onClick={() => setIsNewPersonaModalOpen(true)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-400 cursor-pointer"
                title="Add Persona"
              >
                <Sparkles className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Persona List */}
            <div className="space-y-3 mt-4">
              {personas.map((persona, idx) => {
                const personaLeads = leads.filter((l) => l.matchedPersonaId === persona.id);
                const leadValue = personaLeads.reduce((sum, l) => sum + l.estimatedValue, 0);

                return (
                  <div
                    key={persona.id}
                    onClick={() => {
                      setActivePersona(persona);
                      setActiveView('personas');
                    }}
                    className="p-3 rounded-xl bg-slate-900/70 hover:bg-slate-800/60 border border-slate-800 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs text-white shadow-sm"
                          style={{ backgroundColor: persona.color || '#3B82F6' }}
                        >
                          {persona.name.charAt(0)}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors">
                            {persona.name}
                          </h4>
                          <span className="text-[10px] text-slate-400">{persona.role}</span>
                        </div>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-400">
                        ${(leadValue / 1000).toFixed(0)}k
                      </span>
                    </div>

                    <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3 text-slate-400" />
                        {personaLeads.length} Pipeline Deals
                      </span>
                      <span className="text-indigo-300 font-medium">
                        Tone: {persona.communicationTone?.split(',')[0] || 'Direct'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => setActiveView('personas')}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 text-xs font-bold text-center transition-all cursor-pointer"
          >
            Manage & Test All Personas
          </button>
        </div>
      </div>

      {/* Bottom Row: High-Priority Inbound Engagement & Live Moderation Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent High-Intent Inbound Messages */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
                <MessageSquare className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">High-Intent Inbound Stream</h3>
                <p className="text-[11px] text-slate-400">Analyzed by AI with instant tactical battlecard recommendations</p>
              </div>
            </div>
            <button
              onClick={() => setActiveView('communications')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 cursor-pointer"
            >
              View All ({messages.length}) →
            </button>
          </div>

          <div className="space-y-3 mt-4">
            {messages.slice(0, 3).map((msg) => {
              const sentiment = msg.sentimentAnalysis?.sentiment || 'neutral';
              const sentimentBadge =
                sentiment === 'positive'
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  : sentiment === 'negative'
                  ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                  : 'bg-amber-500/15 text-amber-400 border-amber-500/30';

              return (
                <div
                  key={msg.id}
                  className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-200">
                        {msg.authorName.charAt(0)}
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white">{msg.authorName}</span>
                        <span className="text-[10px] text-slate-400 ml-1.5 font-mono">{msg.authorHandle}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${sentimentBadge}`}>
                        {sentiment}
                      </span>
                      {msg.sentimentAnalysis?.urgencyLevel === 'critical' && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-600 text-white animate-pulse">
                          ⚡ URGENT
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed italic">
                    "{msg.content}"
                  </p>

                  {/* AI Battlecard Advice Snippet */}
                  {msg.sentimentAnalysis && (
                    <div className="p-2 rounded-lg bg-blue-950/40 border border-blue-900/40 text-[11px] text-blue-300 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-cyan-300">AI Strategy:</strong> {msg.sentimentAnalysis.recommendedAction}
                      </span>
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-400">{msg.timestamp} on {msg.platform}</span>
                    <div className="flex items-center gap-2">
                      {msg.status !== 'converted_to_lead' && (
                        <button
                          onClick={() => convertMessageToLead(msg.id)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-[11px] font-semibold transition-all cursor-pointer"
                        >
                          <UserPlus className="w-3 h-3" />
                          <span>Convert to Lead</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setSelectedMessageForReply(msg);
                          setIsAutoReplyModalOpen(true);
                        }}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold shadow-sm transition-all cursor-pointer"
                      >
                        <Send className="w-3 h-3" />
                        <span>Smart AI Reply</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Live Content Moderation & Brand Safety Ticker */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-amber-600/10 border border-amber-500/20">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Brand Safety & Moderation Audit</h3>
                  <p className="text-[11px] text-slate-400">Pre-publish AI compliance, claim verification & auto-sanitize</p>
                </div>
              </div>
              <button
                onClick={() => setActiveView('moderation')}
                className="text-xs font-semibold text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                Open Audit Hub →
              </button>
            </div>

            <div className="space-y-3 mt-4">
              {moderationReports.slice(0, 3).map((rep) => {
                const isFlagged = rep.status === 'flagged';
                const isWarning = rep.status === 'warning';
                const badgeColor = isFlagged
                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                  : isWarning
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';

                return (
                  <div
                    key={rep.id}
                    className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {isFlagged ? (
                          <AlertCircle className="w-4 h-4 text-rose-400" />
                        ) : isWarning ? (
                          <AlertCircle className="w-4 h-4 text-amber-400" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        )}
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          {rep.contentType} Audit
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${badgeColor}`}>
                        {rep.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2 italic">
                      "{rep.content}"
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                      <span className="font-mono text-emerald-400">Safety: {rep.safetyScore}%</span>
                      <span className="font-mono text-blue-400">Grammar: {rep.grammarScore}%</span>
                      <span className="font-mono text-indigo-400">{rep.readability}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 mt-2">
            <button
              onClick={() => setActiveView('moderation')}
              className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer text-center"
            >
              Configure Enterprise Brand Safety Policies
            </button>
          </div>
        </div>
      </div>

      {/* Global Modals & Drawers */}
      <AchievementsDrawer
        isOpen={isAchievementsDrawerOpen}
        onClose={() => setIsAchievementsDrawerOpen(false)}
      />

      <RankUpModal
        event={rankUpEvent}
        onClose={() => setRankUpEvent(null)}
      />
    </div>
  );
};


  // Calculate high-level metrics
  const totalMessages = messages.length;
  const positiveCount = messages.filter(
    (m) => m.sentimentAnalysis?.sentiment === 'positive'
  ).length;
  const neutralCount = messages.filter(
    (m) => m.sentimentAnalysis?.sentiment === 'neutral'
  ).length;
  const negativeCount = messages.filter(
    (m) => m.sentimentAnalysis?.sentiment === 'negative'
  ).length;

  const positivePercent = totalMessages ? Math.round((positiveCount / totalMessages) * 100) : 0;
  const neutralPercent = totalMessages ? Math.round((neutralCount / totalMessages) * 100) : 0;
  const negativePercent = totalMessages ? Math.round((negativeCount / totalMessages) * 100) : 0;

  const totalPipeline = leads.reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);
  const avgSafetyScore = moderationReports.length
    ? Math.round(
        moderationReports.reduce((sum, r) => sum + r.safetyScore, 0) /
          moderationReports.length
      )
    : 98;

  const flaggedReports = moderationReports.filter(
    (r) => r.status === 'flagged' || r.status === 'warning'
  );

  // Chart data: 7-day sentiment trend
  const sentimentTrendData = [
    { day: 'Mon', positive: 18, neutral: 6, negative: 1, avgScore: 0.82 },
    { day: 'Tue', positive: 24, neutral: 8, negative: 3, avgScore: 0.74 },
    { day: 'Wed', positive: 31, neutral: 12, negative: 2, avgScore: 0.86 },
    { day: 'Thu', positive: 28, neutral: 9, negative: 4, avgScore: 0.79 },
    { day: 'Fri', positive: 45, neutral: 14, negative: 2, avgScore: 0.91 },
    { day: 'Sat', positive: 22, neutral: 5, negative: 1, avgScore: 0.88 },
    { day: 'Sun', positive: positiveCount + 15, neutral: neutralCount + 6, negative: negativeCount, avgScore: 0.89 },
  ];

  // Channel distribution
  const channelData = [
    { channel: 'LinkedIn', count: 48, conversion: 22 },
    { channel: 'X / Twitter', count: 32, conversion: 14 },
    { channel: 'Instagram', count: 19, conversion: 18 },
    { channel: 'TikTok', count: 11, conversion: 9 },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner / Welcome & Quick Action Bar */}
      <div className="bg-gradient-to-r from-[#141B2D] via-[#161D31] to-[#111624] border border-slate-800/80 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-8 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center gap-1">
                <Flame className="w-3 h-3 text-amber-400" />
                Live Social Sentiment & Lead Pulse
              </span>
              <span className="text-xs text-slate-400">Synced across 5 channels</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Omnichannel Social Command Center
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Turn social comments and direct messages into qualified sales pipeline with real-time sentiment triage, target persona tailoring, and pre-publish brand moderation.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={batchAnalyzeSentiment}
              disabled={isBatchAnalyzing}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-200 text-xs font-semibold shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isBatchAnalyzing ? 'animate-spin' : ''}`} />
              <span>{isBatchAnalyzing ? 'Analyzing Sentiment...' : 'Batch Sentiment Scan'}</span>
            </button>
            <button
              onClick={() => setIsNewPersonaModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>New AI Persona</span>
            </button>
            <button
              onClick={() => setIsNewPostModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Draft Brand-Safe Post</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Sentiment Health */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Sentiment Health</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                +14% vs LW
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">{positivePercent}%</span>
              <span className="text-xs text-emerald-400 font-semibold">Positive Inbound</span>
            </div>
            {/* Visual Sentiment Stacked Bar */}
            <div className="w-full h-2 rounded-full bg-slate-800 mt-3 flex overflow-hidden">
              <div
                style={{ width: `${positivePercent}%` }}
                className="bg-emerald-500 h-full transition-all"
                title={`Positive: ${positivePercent}%`}
              />
              <div
                style={{ width: `${neutralPercent}%` }}
                className="bg-amber-500 h-full transition-all"
                title={`Neutral: ${neutralPercent}%`}
              />
              <div
                style={{ width: `${negativePercent}%` }}
                className="bg-rose-500 h-full transition-all"
                title={`Negative: ${negativePercent}%`}
              />
            </div>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800/60">
            <span className="flex items-center gap-1 text-emerald-400">🟢 {positiveCount} Pos</span>
            <span className="flex items-center gap-1 text-amber-400">🟡 {neutralCount} Neu</span>
            <span className="flex items-center gap-1 text-rose-400">🔴 {negativeCount} Neg</span>
          </div>
        </div>

        {/* KPI 2: Verified Pipeline */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Social CRM Pipeline</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
                {leads.length} Active Leads
              </span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl sm:text-3xl font-black text-white">
                ${(totalPipeline / 1000).toFixed(1)}k
              </span>
              <span className="text-xs text-slate-400 font-medium">ARR value</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Avg deal size: ${(totalPipeline / Math.max(1, leads.length)).toLocaleString()}
            </p>
          </div>
          <button
            onClick={() => setActiveView('leads')}
            className="flex items-center justify-between text-[11px] text-blue-400 hover:text-blue-300 font-semibold mt-3 pt-2 border-t border-slate-800/60 cursor-pointer"
          >
            <span>View Social CRM Pipeline</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* KPI 3: Customer Personas */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Target Personas</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                {personas.length} Profiles
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">{personas.length}</span>
              <span className="text-xs text-indigo-400 font-semibold">Active Buyer Archetypes</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2 truncate">
              Top: {personas[0]?.name || 'SaaS Founder'}
            </p>
          </div>
          <button
            onClick={() => setActiveView('personas')}
            className="flex items-center justify-between text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold mt-3 pt-2 border-t border-slate-800/60 cursor-pointer"
          >
            <span>Explore Persona Studio</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* KPI 4: Brand Safety & Moderation */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold uppercase tracking-wider text-[10px]">Content Moderation</span>
              {flaggedReports.length > 0 ? (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {flaggedReports.length} Needs Review
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  100% Safe
                </span>
              )}
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">{avgSafetyScore}%</span>
              <span className="text-xs text-emerald-400 font-semibold">Brand Compliance</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              {moderationReports.length} items audited with automated guardrails
            </p>
          </div>
          <button
            onClick={() => setActiveView('moderation')}
            className="flex items-center justify-between text-[11px] text-amber-400 hover:text-amber-300 font-semibold mt-3 pt-2 border-t border-slate-800/60 cursor-pointer"
          >
            <span>Inspect Moderation Hub</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Charts & Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Real-Time Sentiment Trend Area Chart */}
        <div className="lg:col-span-2 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>Multi-Channel Sentiment Velocity & Volume</span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Daily volume of positive, neutral, and negative inbound engagements across all connected platforms
              </p>
            </div>
            <span className="text-[11px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 self-start sm:self-auto">
              Net Sentiment Score: +0.84
            </span>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sentimentTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorPositive" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorNeutral" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F59E0B" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorNegative" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F43F5E" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F43F5E" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '10px',
                    fontSize: '12px',
                    color: '#F8FAFC',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="positive"
                  name="Positive Inbound"
                  stroke="#10B981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorPositive)"
                />
                <Area
                  type="monotone"
                  dataKey="neutral"
                  name="Neutral Inquiries"
                  stroke="#F59E0B"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorNeutral)"
                />
                <Area
                  type="monotone"
                  dataKey="negative"
                  name="Objections / Issues"
                  stroke="#F43F5E"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorNegative)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-4 mt-2 border-t border-slate-800/80 text-center">
            <div className="p-2 rounded-xl bg-slate-900/50">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Positive Conversion</span>
              <p className="text-base font-extrabold text-emerald-400 mt-0.5">38.4%</p>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/50">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Avg Response Latency</span>
              <p className="text-base font-extrabold text-cyan-400 mt-0.5">3.8 mins</p>
            </div>
            <div className="p-2 rounded-xl bg-slate-900/50">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Triage Accuracy</span>
              <p className="text-base font-extrabold text-indigo-400 mt-0.5">99.2%</p>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Customer Personas Performance Leaderboard */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Target className="w-4 h-4 text-indigo-400" />
                  <span>Persona Lead Velocity</span>
                </h2>
                <p className="text-[11px] text-slate-400">Resonance & conversion by buyer archetype</p>
              </div>
              <button
                onClick={() => setIsNewPersonaModalOpen(true)}
                className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-400"
                title="Add Persona"
              >
                <Sparkles className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Persona List */}
            <div className="space-y-3 mt-4">
              {personas.map((persona, idx) => {
                const personaLeads = leads.filter((l) => l.matchedPersonaId === persona.id);
                const leadValue = personaLeads.reduce((sum, l) => sum + l.estimatedValue, 0);

                return (
                  <div
                    key={persona.id}
                    onClick={() => {
                      setActivePersona(persona);
                      setActiveView('personas');
                    }}
                    className="p-3 rounded-xl bg-slate-900/70 hover:bg-slate-800/60 border border-slate-800 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs text-white shadow-sm"
                          style={{ backgroundColor: persona.color || '#3B82F6' }}
                        >
                          {persona.name.charAt(0)}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors">
                            {persona.name}
                          </h4>
                          <span className="text-[10px] text-slate-400">{persona.role}</span>
                        </div>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-400">
                        ${(leadValue / 1000).toFixed(0)}k
                      </span>
                    </div>

                    <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3 text-slate-400" />
                        {personaLeads.length} Pipeline Deals
                      </span>
                      <span className="text-indigo-300 font-medium">
                        Tone: {persona.communicationTone?.split(',')[0] || 'Direct'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => setActiveView('personas')}
            className="w-full mt-4 py-2 px-3 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 text-xs font-bold text-center transition-all cursor-pointer"
          >
            Manage & Test All Personas
          </button>
        </div>
      </div>

      {/* Bottom Row: High-Priority Inbound Engagement & Live Moderation Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent High-Intent Inbound Messages */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-blue-600/10 border border-blue-500/20">
                <MessageSquare className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">High-Intent Inbound Stream</h3>
                <p className="text-[11px] text-slate-400">Analyzed by AI with instant tactical battlecard recommendations</p>
              </div>
            </div>
            <button
              onClick={() => setActiveView('communications')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 cursor-pointer"
            >
              View All ({messages.length}) →
            </button>
          </div>

          <div className="space-y-3 mt-4">
            {messages.slice(0, 3).map((msg) => {
              const sentiment = msg.sentimentAnalysis?.sentiment || 'neutral';
              const sentimentBadge =
                sentiment === 'positive'
                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  : sentiment === 'negative'
                  ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                  : 'bg-amber-500/15 text-amber-400 border-amber-500/30';

              return (
                <div
                  key={msg.id}
                  className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-200">
                        {msg.authorName.charAt(0)}
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white">{msg.authorName}</span>
                        <span className="text-[10px] text-slate-400 ml-1.5 font-mono">{msg.authorHandle}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${sentimentBadge}`}>
                        {sentiment}
                      </span>
                      {msg.sentimentAnalysis?.urgencyLevel === 'critical' && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-600 text-white animate-pulse">
                          ⚡ URGENT
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed italic">
                    "{msg.content}"
                  </p>

                  {/* AI Battlecard Advice Snippet */}
                  {msg.sentimentAnalysis && (
                    <div className="p-2 rounded-lg bg-blue-950/40 border border-blue-900/40 text-[11px] text-blue-300 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>
                        <strong className="text-cyan-300">AI Strategy:</strong> {msg.sentimentAnalysis.recommendedAction}
                      </span>
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-400">{msg.timestamp} on {msg.platform}</span>
                    <div className="flex items-center gap-2">
                      {msg.status !== 'converted_to_lead' && (
                        <button
                          onClick={() => convertMessageToLead(msg.id)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-[11px] font-semibold transition-all cursor-pointer"
                        >
                          <UserPlus className="w-3 h-3" />
                          <span>Convert to Lead</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setSelectedMessageForReply(msg);
                          setIsAutoReplyModalOpen(true);
                        }}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold shadow-sm transition-all cursor-pointer"
                      >
                        <Send className="w-3 h-3" />
                        <span>Smart AI Reply</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Live Content Moderation & Brand Safety Ticker */}
        <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-amber-600/10 border border-amber-500/20">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Brand Safety & Moderation Audit</h3>
                  <p className="text-[11px] text-slate-400">Pre-publish AI compliance, claim verification & auto-sanitize</p>
                </div>
              </div>
              <button
                onClick={() => setActiveView('moderation')}
                className="text-xs font-semibold text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                Open Audit Hub →
              </button>
            </div>

            <div className="space-y-3 mt-4">
              {moderationReports.slice(0, 3).map((rep) => {
                const isFlagged = rep.status === 'flagged';
                const isWarning = rep.status === 'warning';
                const badgeColor = isFlagged
                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                  : isWarning
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';

                return (
                  <div
                    key={rep.id}
                    className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {isFlagged ? (
                          <AlertCircle className="w-4 h-4 text-rose-400" />
                        ) : isWarning ? (
                          <AlertCircle className="w-4 h-4 text-amber-400" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        )}
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          {rep.contentType} Audit
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${badgeColor}`}>
                        {rep.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2 italic">
                      "{rep.content}"
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                      <span className="font-mono text-emerald-400">Safety: {rep.safetyScore}%</span>
                      <span className="font-mono text-blue-400">Grammar: {rep.grammarScore}%</span>
                      <span className="font-mono text-indigo-400">{rep.readability}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-4 mt-2">
            <button
              onClick={() => setActiveView('moderation')}
              className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all cursor-pointer text-center"
            >
              Configure Enterprise Brand Safety Policies
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
