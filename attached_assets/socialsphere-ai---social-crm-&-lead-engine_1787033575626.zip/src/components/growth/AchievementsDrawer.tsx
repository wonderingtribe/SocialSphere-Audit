import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RANK_TIERS } from '../../data/rpgDefaults';
import { GrowthAchievement, GrowthRankTier } from '../../types';
import {
  X,
  Award,
  Crown,
  Sparkles,
  Flame,
  CheckCircle2,
  Lock,
  Zap,
  TrendingUp,
  MessageSquare,
  Users,
  UserCheck,
  Globe,
  Rocket,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';

interface AchievementsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AchievementsDrawer: React.FC<AchievementsDrawerProps> = ({
  isOpen,
  onClose,
}) => {
  const { growthRank, achievements, claimAchievement } = useApp();
  const [activeCategory, setActiveCategory] = useState<
    'all' | 'audience' | 'conversations' | 'leads' | 'signups' | 'speed' | 'safety'
  >('all');
  const [selectedTab, setSelectedTab] = useState<'achievements' | 'rank_tiers'>('achievements');

  if (!isOpen) return null;

  const currentTier = growthRank.tier;
  const filteredAchievements = achievements.filter((ach) => {
    if (activeCategory === 'all') return true;
    return ach.category === activeCategory;
  });

  const unlockedCount = achievements.filter((a) => a.isUnlocked).length;
  const totalXpClaimed = achievements
    .filter((a) => a.isUnlocked)
    .reduce((sum, a) => sum + a.xpReward, 0);

  const getTierBadgeStyle = (tier: GrowthAchievement['tier']) => {
    switch (tier) {
      case 'mythic':
        return 'bg-gradient-to-r from-purple-600 to-rose-600 text-white border-purple-400';
      case 'diamond':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40';
      case 'gold':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-400/40';
      case 'silver':
        return 'bg-slate-400/20 text-slate-200 border-slate-300/40';
      case 'bronze':
      default:
        return 'bg-amber-600/20 text-amber-300 border-amber-600/40';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#0E121B] border-l border-slate-800 h-full flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#121622]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-500/25">
              <Award className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">Social Growth RPG Trophy Case</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  {unlockedCount}/{achievements.length} Unlocked
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Unlock achievements, ascend rank tiers, and claim autonomous growth perks.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-800/80 bg-[#0B0E14] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedTab('achievements')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedTab === 'achievements'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              🏅 Achievement Badges ({achievements.length})
            </button>
            <button
              onClick={() => setSelectedTab('rank_tiers')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedTab === 'rank_tiers'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              👑 Rank Hierarchy Tiers
            </button>
          </div>

          <span className="text-xs font-mono font-bold text-yellow-400">
            +{totalXpClaimed.toLocaleString()} Total XP
          </span>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {selectedTab === 'achievements' ? (
            <>
              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {[
                  { id: 'all', label: 'All Quests' },
                  { id: 'audience', label: '👥 Audience' },
                  { id: 'conversations', label: '💬 Conversations' },
                  { id: 'leads', label: '🎯 Leads' },
                  { id: 'signups', label: '⭐ Signups' },
                  { id: 'speed', label: '⚡ Speed' },
                  { id: 'safety', label: '🛡️ Safety' },
                ].map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id as any)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      activeCategory === cat.id
                        ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Achievements Grid */}
              <div className="space-y-3">
                {filteredAchievements.map((ach) => {
                  const percent = Math.min(
                    100,
                    Math.round((ach.currentProgress / Math.max(1, ach.targetProgress)) * 100)
                  );
                  const isReadyToClaim =
                    !ach.isUnlocked && ach.currentProgress >= ach.targetProgress;

                  return (
                    <div
                      key={ach.id}
                      className={`p-4 rounded-xl border transition-all duration-200 space-y-3 ${
                        ach.isUnlocked
                          ? 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                          : isReadyToClaim
                          ? 'bg-purple-950/30 border-purple-500/50 shadow-md shadow-purple-500/20'
                          : 'bg-slate-950/60 border-slate-800/60 opacity-80'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xl border shadow-inner shrink-0 ${
                              ach.isUnlocked
                                ? 'bg-gradient-to-tr from-purple-600/30 to-indigo-600/30 border-purple-500/40 text-white'
                                : 'bg-slate-900 border-slate-800 text-slate-500'
                            }`}
                          >
                            {ach.badgeEmoji}
                          </div>

                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-white">{ach.title}</h4>
                              <span
                                className={`px-1.5 py-0.2 rounded text-[9px] font-black uppercase tracking-wider border ${getTierBadgeStyle(
                                  ach.tier
                                )}`}
                              >
                                {ach.tier}
                              </span>
                              {ach.isUnlocked && (
                                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-0.5">
                                  <CheckCircle2 className="w-3 h-3" /> Unlocked
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                              {ach.description}
                            </p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-xs font-mono font-bold text-yellow-400 block">
                            +{ach.xpReward} XP
                          </span>
                        </div>
                      </div>

                      {/* Progress Bar & Rewards */}
                      <div className="space-y-1 pt-1">
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                          <span>
                            Progress: {ach.currentProgress.toLocaleString()} /{' '}
                            {ach.targetProgress.toLocaleString()}
                          </span>
                          <span className="font-bold text-slate-300">{percent}%</span>
                        </div>

                        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            style={{ width: `${percent}%` }}
                            className={`h-full rounded-full transition-all duration-300 ${
                              ach.isUnlocked
                                ? 'bg-emerald-500'
                                : isReadyToClaim
                                ? 'bg-purple-500 animate-pulse'
                                : 'bg-blue-600'
                            }`}
                          />
                        </div>
                      </div>

                      {/* Unlocked Perk Tag & Claim Action */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                        {ach.perkReward && (
                          <span className="text-[11px] text-indigo-300 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-cyan-400" />
                            <strong>Perk:</strong> {ach.perkReward}
                          </span>
                        )}

                        {isReadyToClaim && (
                          <button
                            onClick={() => claimAchievement(ach.id)}
                            className="px-3 py-1 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-purple-500/30 transition-all cursor-pointer ml-auto"
                          >
                            Claim Reward (+{ach.xpReward} XP)
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            /* Rank Tiers Progression Roadmap */
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/30 text-xs text-purple-300 flex items-center gap-2">
                <Crown className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>
                  Ascend through 7 growth tiers. Higher tiers unlock multi-campaign capacity, autonomous auto-pilot speeds, and taller Growth Tower floors.
                </span>
              </div>

              <div className="space-y-3">
                {Object.entries(RANK_TIERS).map(([key, config]) => {
                  const isCurrent = currentTier === key;

                  return (
                    <div
                      key={key}
                      className={`p-4 rounded-xl border transition-all ${
                        isCurrent
                          ? 'bg-[#151B28] border-cyan-400 ring-2 ring-cyan-500/30 shadow-lg'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-2xl bg-black/40 border border-slate-700 flex items-center justify-center text-xl shadow-inner">
                            {config.badgeEmoji}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-white">{config.name}</h4>
                              <span className="px-2 py-0.2 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                                LVL {config.minLevel} - {config.maxLevel}
                              </span>
                              {isCurrent && (
                                <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                                  Current Tier
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-400 mt-0.5">
                              {config.badgeName} • {config.towerFloors} Tower Floors
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-mono font-bold text-slate-300">
                            {config.campaignCapacity} Active Slots
                          </span>
                        </div>
                      </div>

                      {/* Perks */}
                      <div className="mt-3 pt-2 border-t border-slate-800/80 flex flex-wrap gap-1.5">
                        {config.unlockedPerks.map((p, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-950 border border-slate-800 text-slate-300 flex items-center gap-1"
                          >
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            {p}
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Drawer Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#121622] flex items-center justify-between text-xs text-slate-400">
          <span>Active RPG Rank: <strong className="text-white">{growthRank.title} (LVL {growthRank.level})</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-all cursor-pointer"
          >
            Close Trophy Case
          </button>
        </div>
      </div>
    </div>
  );
};
