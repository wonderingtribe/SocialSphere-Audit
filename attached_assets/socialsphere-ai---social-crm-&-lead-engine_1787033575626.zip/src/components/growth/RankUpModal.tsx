import React from 'react';
import { RankUpEvent } from '../../types';
import {
  Crown,
  Sparkles,
  Award,
  CheckCircle2,
  Zap,
  ArrowRight,
  ShieldCheck,
  Flame,
} from 'lucide-react';

interface RankUpModalProps {
  event: RankUpEvent | null;
  onClose: () => void;
}

export const RankUpModal: React.FC<RankUpModalProps> = ({ event, onClose }) => {
  if (!event) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#121622] border-2 border-yellow-500/60 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300 text-center space-y-5">
        {/* Radiant Fireworks Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-yellow-500/25 via-purple-600/20 to-transparent rounded-full blur-3xl pointer-events-none" />

        {/* Celebration Badges */}
        <div className="relative z-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 text-xs font-black uppercase tracking-wider animate-bounce">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Milestone Achieved!</span>
          </div>

          <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-yellow-500 via-amber-400 to-yellow-200 flex items-center justify-center text-4xl shadow-xl shadow-yellow-500/30 border-2 border-white/40 my-3">
            {event.badgeEmoji || '👑'}
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            RANK UP: {event.newRankTitle.toUpperCase()}!
          </h2>
          <p className="text-xs text-slate-300 max-w-sm mx-auto">
            Your growth engine reached <strong>Level {event.newLevel}</strong>. New autonomous perks and tower capacities are now unlocked!
          </p>
        </div>

        {/* Rank Progression Step */}
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-center gap-3 text-xs font-bold">
          <span className="text-slate-400 capitalize">{event.oldRankTitle}</span>
          <ArrowRight className="w-4 h-4 text-cyan-400" />
          <span className="text-yellow-300 font-black capitalize flex items-center gap-1">
            <Crown className="w-3.5 h-3.5 text-yellow-400" />
            {event.newRankTitle} (LVL {event.newLevel})
          </span>
        </div>

        {/* Unlocked Perks List */}
        <div className="text-left space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block text-center">
            🎁 Unlocked Growth Perks:
          </span>
          <div className="space-y-1.5">
            {event.newPerks.map((perk, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-purple-950/30 border border-purple-500/30 text-purple-200 text-xs font-semibold flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{perk}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Claim Action Button */}
        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 text-slate-950 font-black text-sm shadow-xl shadow-yellow-500/25 transition-all cursor-pointer transform hover:scale-[1.02] active:scale-[0.98]"
          >
            Claim Rewards & Ascend Tower (+{event.xpGained} XP) 🚀
          </button>
        </div>
      </div>
    </div>
  );
};
