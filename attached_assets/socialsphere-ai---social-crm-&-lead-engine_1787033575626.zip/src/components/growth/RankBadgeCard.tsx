import React from 'react';
import { useApp } from '../../context/AppContext';
import { RANK_TIERS } from '../../data/rpgDefaults';
import {
  Crown,
  Sparkles,
  Flame,
  Award,
  Zap,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  ChevronRight,
  Lock,
  CheckCircle2,
  Users,
} from 'lucide-react';

interface RankBadgeCardProps {
  onOpenAchievements?: () => void;
}

export const RankBadgeCard: React.FC<RankBadgeCardProps> = ({
  onOpenAchievements,
}) => {
  const { growthRank, triggerFollowerSurge } = useApp();

  const currentTierConfig = RANK_TIERS[growthRank.tier] || RANK_TIERS.master;
  const isDipping = growthRank.growthHealth === 'dipping';
  const isSurging = growthRank.growthHealth === 'surging';

  const xpPercent = Math.min(
    100,
    Math.round((growthRank.currentXp / Math.max(1, growthRank.xpForNextLevel)) * 100)
  );

  return (
    <div
      className={`bg-[#121620] border rounded-2xl p-5 shadow-xl relative overflow-hidden transition-all duration-500 flex flex-col justify-between space-y-4 ${
        isDipping
          ? 'border-rose-500/50 shadow-rose-500/10'
          : isSurging
          ? 'border-yellow-500/60 shadow-yellow-500/20'
          : 'border-slate-800'
      }`}
    >
      {/* Background Radiance */}
      <div
        className={`absolute -right-12 -top-12 w-64 h-64 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
          isDipping
            ? 'bg-rose-600/15'
            : isSurging
            ? 'bg-yellow-500/25'
            : 'bg-purple-600/15'
        }`}
      />

      {/* Top Bar: Badge & Rank Level */}
      <div className="relative z-10 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-cyan-400" />
            Social Growth RPG Rank
          </span>

          <span
            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border flex items-center gap-1.5 ${
              isDipping
                ? 'bg-rose-500/20 text-rose-400 border-rose-500/40 animate-pulse'
                : isSurging
                ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40 shadow-sm'
                : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isDipping
                  ? 'bg-rose-400 animate-ping'
                  : isSurging
                  ? 'bg-yellow-400 animate-pulse'
                  : 'bg-emerald-400'
              }`}
            />
            {isDipping ? 'Growth Dip (Crack State)' : isSurging ? 'Growth Surging 🔥' : 'Health: Optimal'}
          </span>
        </div>

        {/* Dynamic Interactive Rank Emblem / Badge */}
        <div
          className={`p-4 rounded-xl border relative transition-all duration-500 ${
            isDipping
              ? 'bg-slate-900/90 border-rose-500/50 opacity-85 grayscale-20'
              : `bg-gradient-to-r ${currentTierConfig.gradient} ${currentTierConfig.borderGlow} text-white`
          }`}
        >
          {/* Cracked overlay visual effect when dipping */}
          {isDipping && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center bg-black/40 rounded-xl">
              <span className="text-3xl opacity-70 animate-pulse">⚡💔</span>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-black/30 border border-white/20 flex items-center justify-center text-2xl shadow-inner">
                {currentTierConfig.badgeEmoji}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-black tracking-tight uppercase">
                    {growthRank.title}
                  </h3>
                  <span className="px-2 py-0.5 rounded-md bg-black/40 text-xs font-mono font-bold text-yellow-300 border border-yellow-300/30">
                    LVL {growthRank.level}
                  </span>
                </div>
                <p className="text-xs opacity-90 font-medium">
                  {currentTierConfig.badgeName} • Tier {growthRank.tier.toUpperCase()}
                </p>
              </div>
            </div>

            <div className="text-right hidden sm:block">
              <span className="text-[10px] font-mono opacity-80 uppercase block">XP Booster</span>
              <span className="text-sm font-black font-mono">
                {growthRank.growthMultiplier}x Velocity
              </span>
            </div>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold">
              XP Progress: <strong className="text-cyan-400">{growthRank.currentXp.toLocaleString()}</strong> / {growthRank.xpForNextLevel.toLocaleString()}
            </span>
            <span className="text-yellow-400 font-bold">{xpPercent}%</span>
          </div>

          <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden relative">
            <div
              style={{ width: `${xpPercent}%` }}
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-yellow-400 rounded-full transition-all duration-500 shadow-sm"
            />
          </div>
        </div>

        {/* Real-time NPC Mob Population & Tower Floors */}
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              Active Climbers on Tower:
            </span>
            <span className="font-mono font-black text-cyan-300 text-xs">
              1,284 NPCs Climbing
            </span>
          </div>

          <div className="flex items-center gap-1 text-sm tracking-wider overflow-hidden text-slate-300 py-0.5">
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span>🧍</span>
            <span className="text-xs text-slate-500 font-mono">+1.2k</span>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Tower Height: <strong className="text-white">{growthRank.towerFloors} Active Floors</strong></span>
            <span>Active Streak: <strong className="text-amber-400">{growthRank.streakDays} Days 🔥</strong></span>
          </div>
        </div>

        {/* Unlocked Automations & Perks Pill Grid */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">
            Active Rank Perks & Automations:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {growthRank.unlockedAutomations.slice(0, 3).map((perk, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1"
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                {perk}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Action Footer: Open Trophy Case & Quests */}
      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
        <button
          onClick={onOpenAchievements}
          className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600/20 to-indigo-600/20 hover:from-purple-600/30 hover:to-indigo-600/30 border border-purple-500/40 text-purple-300 text-xs font-bold transition-all cursor-pointer shadow-sm"
        >
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Open RPG Trophy Case & Quests</span>
          </span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
