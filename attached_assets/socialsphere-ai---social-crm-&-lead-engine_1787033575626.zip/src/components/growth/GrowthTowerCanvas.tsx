import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { GrowthNpc, GrowthNpcType, SocialPlatform } from '../../types';
import {
  TrendingUp,
  Sparkles,
  Users,
  Flame,
  MessageSquare,
  Globe,
  UserCheck,
  Zap,
  Play,
  Pause,
  RotateCcw,
  ShieldCheck,
  ArrowUpRight,
  ChevronUp,
  AlertTriangle,
  Award,
  Crown,
  Share2,
} from 'lucide-react';

interface GrowthTowerCanvasProps {
  onNpcClick?: (npc: GrowthNpc) => void;
}

export const GrowthTowerCanvas: React.FC<GrowthTowerCanvasProps> = ({
  onNpcClick,
}) => {
  const {
    growthRank,
    towerNpcs,
    triggerFollowerSurge,
    triggerLeadArrival,
    triggerSignupCelebration,
    triggerPortalVisitor,
    triggerConversationBubble,
    simulateGrowthDip,
    campaigns,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'tower' | 'floors' | 'analytics'>('tower');
  const [isAutoLoop, setIsAutoLoop] = useState(true);
  const [simulationSpeed, setSimulationSpeed] = useState<1 | 2 | 5>(1);
  const [selectedNpc, setSelectedNpc] = useState<GrowthNpc | null>(null);
  const [filterType, setFilterType] = useState<GrowthNpcType | 'all'>('all');

  const containerRef = useRef<HTMLDivElement>(null);

  // Active campaign context
  const activeCampaign = campaigns[0];
  const funnel = activeCampaign?.conversionFunnel || {
    followers: 2340,
    engaged: 1820,
    interested: 940,
    websiteVisitors: 4820,
    leads: 520,
    signups: 890,
  };

  const isDipping = growthRank.growthHealth === 'dipping';
  const isSurging = growthRank.growthHealth === 'surging';

  // Tower floors configuration
  const floors = [
    {
      id: 5,
      name: 'Floor 05: Golden Summit & Customer Signups',
      subtitle: 'Final Conversion • Activated SaaS Customers',
      count: funnel.signups,
      badge: 'Summit Crown',
      icon: Crown,
      color: 'from-amber-500/25 via-yellow-500/15 to-transparent',
      borderColor: 'border-yellow-500/50',
      accentColor: 'text-yellow-400',
      tagColor: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
      glowShadow: 'shadow-[0_0_25px_rgba(234,179,8,0.25)]',
    },
    {
      id: 4,
      name: 'Floor 04: Qualified Lead Terrace',
      subtitle: 'High Buying Intent (>80%) • CRM Synced Deals',
      count: funnel.leads,
      badge: 'VIP Terrace',
      icon: UserCheck,
      color: 'from-emerald-500/20 via-teal-500/10 to-transparent',
      borderColor: 'border-emerald-500/40',
      accentColor: 'text-emerald-400',
      tagColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      glowShadow: 'shadow-[0_0_20px_rgba(16,185,129,0.2)]',
    },
    {
      id: 3,
      name: 'Floor 03: Teleport Portal & Website Visitors',
      subtitle: `Target URL: ${activeCampaign?.websiteUrl || 'ai-wonderland.io'}`,
      count: funnel.websiteVisitors,
      badge: 'Warp Portal',
      icon: Globe,
      color: 'from-cyan-500/20 via-blue-500/10 to-transparent',
      borderColor: 'border-cyan-500/40',
      accentColor: 'text-cyan-400',
      tagColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
      glowShadow: 'shadow-[0_0_20px_rgba(6,182,212,0.2)]',
    },
    {
      id: 2,
      name: 'Floor 02: Community Lounge & Live Inbound Chat',
      subtitle: 'Autonomous Consultation • Zero Robotic Fluff',
      count: funnel.interested,
      badge: 'Discussion Lounge',
      icon: MessageSquare,
      color: 'from-purple-500/20 via-indigo-500/10 to-transparent',
      borderColor: 'border-purple-500/40',
      accentColor: 'text-purple-400',
      tagColor: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
      glowShadow: 'shadow-[0_0_15px_rgba(168,85,247,0.15)]',
    },
    {
      id: 1,
      name: 'Floor 01: Viral Engagement Terrace',
      subtitle: 'Fast Climbers • Likes, Carousels & Video Shares',
      count: funnel.engaged,
      badge: 'Speed Terrace',
      icon: Flame,
      color: 'from-orange-500/20 via-amber-500/10 to-transparent',
      borderColor: 'border-orange-500/40',
      accentColor: 'text-orange-400',
      tagColor: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
      glowShadow: 'shadow-[0_0_15px_rgba(249,115,22,0.15)]',
    },
    {
      id: 0,
      name: 'Floor 00: Audience Base Camp',
      subtitle: 'Cross-Platform Followers & Inbound Impressions',
      count: funnel.followers,
      badge: 'Base Camp',
      icon: Users,
      color: 'from-blue-600/20 via-slate-800/40 to-transparent',
      borderColor: 'border-blue-500/40',
      accentColor: 'text-blue-400',
      tagColor: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
      glowShadow: 'shadow-[0_0_15px_rgba(59,130,246,0.15)]',
    },
  ];

  const filteredNpcs = towerNpcs.filter((npc) => {
    if (filterType === 'all') return true;
    return npc.type === filterType;
  });

  const getNpcTypeConfig = (type: GrowthNpcType) => {
    switch (type) {
      case 'customer_signup':
        return {
          icon: '⭐',
          color: 'bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-yellow-400/50',
          label: 'Customer / Signup',
          speedLabel: 'Summit Champ',
        };
      case 'qualified_lead':
        return {
          icon: '🎯',
          color: 'bg-emerald-500 text-white border-emerald-300 ring-2 ring-emerald-400/40',
          label: 'Qualified Lead',
          speedLabel: 'High Intent',
        };
      case 'visitor':
        return {
          icon: '🌐',
          color: 'bg-cyan-500 text-slate-950 border-cyan-300 ring-2 ring-cyan-400/40',
          label: 'Website Visitor',
          speedLabel: 'Portal Warp',
        };
      case 'conversation':
        return {
          icon: '💬',
          color: 'bg-purple-500 text-white border-purple-300',
          label: 'Inbound Conversation',
          speedLabel: 'Consulting',
        };
      case 'engaged':
        return {
          icon: '🔥',
          color: 'bg-orange-500 text-white border-orange-300',
          label: 'Engaged Climber',
          speedLabel: 'Fast Climber',
        };
      case 'follower':
      default:
        return {
          icon: '👤',
          color: 'bg-blue-500 text-white border-blue-300',
          label: 'New Follower',
          speedLabel: 'Ascending',
        };
    }
  };

  return (
    <div className="bg-[#0F1420] border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-4 relative overflow-hidden">
      {/* Dynamic Background Aura */}
      <div
        className={`absolute -right-16 -top-16 w-80 h-80 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
          isDipping
            ? 'bg-rose-600/15'
            : isSurging
            ? 'bg-amber-500/20'
            : 'bg-cyan-500/15'
        }`}
      />

      {/* Header Bar */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/25">
              <Crown className="w-4 h-4 text-yellow-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white tracking-tight">
                  3D Social Growth Tower & NPC Climber Arena
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  RPG Live Engine
                </span>
              </div>
              <p className="text-xs text-slate-400">
                1,284 real-time climbers physically ascend your tower as campaigns, engagement, and website signups surge.
              </p>
            </div>
          </div>
        </div>

        {/* View Mode & Speed Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="flex items-center bg-slate-900/90 rounded-xl p-1 border border-slate-800">
            <button
              onClick={() => setActiveTab('tower')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'tower'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              3D Tower
            </button>
            <button
              onClick={() => setActiveTab('floors')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'floors'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Floor Tiers
            </button>
          </div>

          <button
            onClick={() => setIsAutoLoop(!isAutoLoop)}
            className={`p-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              isAutoLoop
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
            title="Toggle autonomous NPC movement"
          >
            {isAutoLoop ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isAutoLoop ? 'Live' : 'Paused'}</span>
          </button>
        </div>
      </div>

      {/* Main 3D Tower Canvas Container */}
      <div
        ref={containerRef}
        className={`relative min-h-[460px] rounded-2xl border transition-all duration-500 overflow-hidden bg-gradient-to-b from-[#0B0E14] via-[#0E131F] to-[#080A0F] ${
          isDipping
            ? 'border-rose-500/40 ring-1 ring-rose-500/20'
            : isSurging
            ? 'border-yellow-500/50 ring-1 ring-yellow-500/30'
            : 'border-slate-800'
        }`}
      >
        {/* Metric Line Chart Background Grid */}
        <div className="absolute inset-0 pointer-events-none opacity-25">
          <svg className="w-full h-full" preserveAspectRatio="none">
            <defs>
              <linearGradient id="metricGrad" x1="0" y1="1" x2="0" y2="0">
                <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#06B6D4" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#EAB308" stopOpacity="0.6" />
              </linearGradient>
            </defs>
            <path
              d="M 50 420 C 150 380, 250 340, 350 280 C 450 220, 550 160, 650 100 C 750 60, 850 40, 950 25"
              fill="none"
              stroke="url(#metricGrad)"
              strokeWidth="4"
              strokeDasharray="6 4"
            />
            {/* Floor connection nodes */}
            <circle cx="150" cy="380" r="5" fill="#3B82F6" />
            <circle cx="350" cy="280" r="6" fill="#F97316" />
            <circle cx="550" cy="180" r="6" fill="#A855F7" />
            <circle cx="700" cy="110" r="7" fill="#06B6D4" />
            <circle cx="820" cy="65" r="8" fill="#10B981" />
            <circle cx="950" cy="25" r="10" fill="#EAB308" />
          </svg>
        </div>

        {/* Growth Health Alert Ticker (when dipping or surging) */}
        {isDipping && (
          <div className="absolute top-3 left-3 right-3 z-30 bg-rose-950/80 border border-rose-500/50 backdrop-blur-md rounded-xl p-2.5 flex items-center justify-between animate-pulse">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="text-xs font-bold text-white">
                ⚠️ Growth Dip Active: NPCs tumbling slightly. Rank badge dimmed! Deploying auto-nurture...
              </span>
            </div>
            <button
              onClick={triggerFollowerSurge}
              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold cursor-pointer transition-all shadow-sm"
            >
              Recover Growth 🚀
            </button>
          </div>
        )}

        {/* 3D Vertical Floors Structure */}
        <div className="relative z-10 p-4 sm:p-6 flex flex-col justify-between h-full space-y-4">
          {floors.map((fl) => {
            const floorNpcs = filteredNpcs.filter((n) => n.floor === fl.id);
            const FloorIcon = fl.icon;

            return (
              <div
                key={fl.id}
                className={`relative rounded-xl border p-3.5 transition-all duration-300 bg-gradient-to-r ${fl.color} ${fl.borderColor} ${fl.glowShadow} backdrop-blur-sm group hover:border-slate-600`}
              >
                {/* Floor Header Label & Metric */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-slate-900/80 border border-slate-700 flex items-center justify-center text-[10px] font-mono font-bold text-slate-300">
                      0{fl.id}
                    </span>
                    <FloorIcon className={`w-4 h-4 ${fl.accentColor}`} />
                    <span className="text-xs font-black text-white">{fl.name}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${fl.tagColor}`}>
                      {fl.badge}
                    </span>
                    <span className="text-xs font-mono font-black text-white bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                      {fl.count.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Special Floor Feature: Portal on Floor 3 */}
                {fl.id === 3 && (
                  <div className="absolute right-24 top-2 bottom-2 w-14 rounded-full bg-cyan-500/20 border-2 border-cyan-400 animate-pulse flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.4)] pointer-events-none">
                    <div className="w-8 h-8 rounded-full bg-cyan-400/40 blur-[2px] animate-spin flex items-center justify-center text-[9px] font-bold text-white">
                      🌀
                    </div>
                  </div>
                )}

                {/* Special Floor Feature: Summit Fireworks on Floor 5 */}
                {fl.id === 5 && (
                  <div className="absolute right-12 top-2 flex items-center gap-1.5 text-xs text-yellow-300 font-bold animate-bounce pointer-events-none">
                    <span>👑</span>
                    <span className="text-[10px] uppercase font-mono tracking-wider">Summit Apex</span>
                    <span>🎉</span>
                  </div>
                )}

                {/* NPC Walkway / Climber Track */}
                <div className="relative min-h-[44px] flex items-center flex-wrap gap-3 pt-1">
                  {floorNpcs.length === 0 ? (
                    <span className="text-[11px] text-slate-500 italic">
                      Climbers ascending towards this milestone...
                    </span>
                  ) : (
                    floorNpcs.map((npc) => {
                      const typeConfig = getNpcTypeConfig(npc.type);
                      const isSelected = selectedNpc?.id === npc.id;

                      return (
                        <div
                          key={npc.id}
                          onClick={() => {
                            setSelectedNpc(npc);
                            if (onNpcClick) onNpcClick(npc);
                          }}
                          className={`relative group/npc flex items-center gap-1.5 p-1 rounded-xl transition-all duration-300 cursor-pointer ${
                            isSelected
                              ? 'bg-white/10 ring-2 ring-cyan-400 scale-105 shadow-lg'
                              : 'hover:bg-slate-800/80 hover:scale-105'
                          } ${npc.status === 'stumbling' ? 'animate-bounce' : ''}`}
                        >
                          {/* Animated Speech Bubble */}
                          {npc.speechBubble && (
                            <div className="absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap z-30 px-2 py-0.5 rounded-lg bg-slate-900/95 border border-cyan-400/50 text-[10px] font-bold text-cyan-200 shadow-xl pointer-events-none animate-in fade-in zoom-in-90">
                              <span>{npc.speechBubble}</span>
                              <div className="w-1.5 h-1.5 bg-slate-900 border-r border-b border-cyan-400/50 rotate-45 absolute -bottom-1 left-1/2 -translate-x-1/2" />
                            </div>
                          )}

                          {/* NPC Avatar & Status Ring */}
                          <div className="relative">
                            <img
                              src={npc.avatar}
                              alt={npc.name}
                              className="w-7 h-7 rounded-full object-cover border border-slate-700"
                            />
                            <span
                              className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold border ${typeConfig.color}`}
                            >
                              {typeConfig.icon}
                            </span>
                          </div>

                          {/* NPC Name & Platform */}
                          <div className="flex flex-col text-left">
                            <span className="text-[11px] font-bold text-white leading-tight flex items-center gap-1">
                              {npc.name}
                              {npc.status === 'stumbling' && <span className="text-[10px]">💦</span>}
                              {npc.status === 'celebrating' && <span className="text-[10px]">🎉</span>}
                            </span>
                            <span className="text-[9px] text-slate-400 capitalize font-mono">
                              {npc.platform} • {typeConfig.speedLabel}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected NPC Deep-Dive Card */}
      {selectedNpc && (
        <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <img
              src={selectedNpc.avatar}
              alt={selectedNpc.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-cyan-400 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-bold text-white">{selectedNpc.name}</h4>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 uppercase font-mono">
                  {selectedNpc.type.replace(/_/g, ' ')}
                </span>
                <span className="text-xs text-slate-400 capitalize font-mono">
                  via {selectedNpc.platform}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 italic">
                "{selectedNpc.speechBubble || 'Climbing tower based on campaign resonance...'}"
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => triggerConversationBubble()}
              className="px-3 py-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 text-xs font-bold cursor-pointer transition-all"
            >
              💬 Trigger Banter
            </button>
            <button
              onClick={() => setSelectedNpc(null)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Interactive Growth Trigger Sandbox Bar */}
      <div className="p-4 rounded-xl bg-[#090C12] border border-slate-800/90 space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-300 font-bold uppercase tracking-wider text-[10px]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Interactive Growth Engine Triggers</span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Directly manipulate tower climbers & trigger real-time simulations
          </span>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          <button
            onClick={triggerFollowerSurge}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-300 text-xs font-bold shadow-sm transition-all cursor-pointer"
            title="Spawns new followers scrambling upward"
          >
            <Users className="w-3.5 h-3.5" />
            <span>+50 Followers (Surge)</span>
          </button>

          <button
            onClick={triggerPortalVisitor}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/30 text-cyan-300 text-xs font-bold shadow-sm transition-all cursor-pointer"
            title="NPC steps through teleport portal"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>🌐 Portal Jump (+Visitor)</span>
          </button>

          <button
            onClick={triggerConversationBubble}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-300 text-xs font-bold shadow-sm transition-all cursor-pointer"
            title="Spawns real consultative banter bubbles"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>💬 Community Chat</span>
          </button>

          <button
            onClick={() => triggerLeadArrival()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-300 text-xs font-bold shadow-sm transition-all cursor-pointer"
            title="High-intent lead climbs to VIP terrace"
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>🎯 High-Intent Lead (+XP)</span>
          </button>

          <button
            onClick={triggerSignupCelebration}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/40 text-yellow-300 text-xs font-bold shadow-sm transition-all cursor-pointer"
            title="Champion reaches summit with fireworks"
          >
            <Crown className="w-3.5 h-3.5" />
            <span>⭐ Summit Signup (Win!)</span>
          </button>

          <button
            onClick={simulateGrowthDip}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600/15 hover:bg-rose-600/25 border border-rose-500/30 text-rose-300 text-xs font-bold shadow-sm transition-all cursor-pointer ml-auto"
            title="Simulates a growth dip: NPCs stumble, rank badge temporarily dims"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>📉 Simulate Growth Dip</span>
          </button>
        </div>
      </div>
    </div>
  );
};
