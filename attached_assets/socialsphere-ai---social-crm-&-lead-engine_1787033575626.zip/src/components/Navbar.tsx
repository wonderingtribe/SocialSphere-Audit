import React from 'react';
import { useApp, AppView } from '../context/AppContext';
import {
  LayoutDashboard,
  MessageSquareHeart,
  Users,
  ShieldCheck,
  Megaphone,
  UserCheck,
  Calendar,
  Sparkles,
  PlusCircle,
  AlertTriangle,
  Flame,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    activeView,
    setActiveView,
    personas,
    activePersona,
    setActivePersona,
    messages,
    moderationReports,
    setIsNewPostModalOpen,
    setIsNewPersonaModalOpen,
  } = useApp();

  const unreadMessagesCount = messages.filter((m) => m.status === 'unanswered').length;
  const flaggedModerationCount = moderationReports.filter(
    (r) => r.status === 'flagged' || r.status === 'warning'
  ).length;

  const navItems: Array<{
    id: AppView;
    label: string;
    icon: React.ElementType;
    badge?: number | string;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    {
      id: 'communications',
      label: 'Communications & Sentiment',
      icon: MessageSquareHeart,
      badge: unreadMessagesCount > 0 ? unreadMessagesCount : undefined,
      badgeColor: 'bg-blue-500 text-white',
    },
    {
      id: 'personas',
      label: 'Customer Personas',
      icon: Users,
      badge: `${personas.length}`,
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30',
    },
    {
      id: 'moderation',
      label: 'Content Moderation',
      icon: ShieldCheck,
      badge: flaggedModerationCount > 0 ? flaggedModerationCount : undefined,
      badgeColor: 'bg-amber-500 text-white animate-pulse',
    },
    { id: 'campaigns', label: 'Growth Campaigns', icon: Megaphone },
    { id: 'leads', label: 'Social CRM Leads', icon: UserCheck },
    { id: 'calendar', label: 'Schedule & Demos', icon: Calendar },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0E121B]/95 backdrop-blur-md border-b border-slate-800/80">
      {/* Top Banner / Status Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 p-0.5 shadow-lg shadow-blue-500/20">
              <div className="w-full h-full bg-[#0E121B] rounded-[10px] flex items-center justify-center">
                <Flame className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-white">
                  SocialSphere<span className="text-cyan-400 font-normal">.ai</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Enterprise Lead Engine
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Multi-Channel Sentiment Intelligence & Brand-Safe Outreach
              </p>
            </div>
          </div>

          {/* Persona Selector & Quick Actions */}
          <div className="flex items-center gap-2.5">
            {/* Active Persona Quick Tag */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[11px] font-medium text-slate-400">Target Persona:</span>
              <select
                value={activePersona?.id || ''}
                onChange={(e) => {
                  const found = personas.find((p) => p.id === e.target.value);
                  setActivePersona(found || null);
                }}
                className="bg-transparent text-xs font-semibold text-blue-400 focus:outline-none cursor-pointer"
              >
                {personas.map((p) => (
                  <option key={p.id} value={p.id} className="bg-slate-900 text-slate-200">
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            {/* AI Persona Quick Button */}
            <button
              onClick={() => setIsNewPersonaModalOpen(true)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 text-xs font-semibold transition-all cursor-pointer"
              title="Create or auto-generate buyer persona with AI"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>AI Persona Builder</span>
            </button>

            {/* New Post with Live Scanner */}
            <button
              onClick={() => setIsNewPostModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create Safe Post</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Sub-bar */}
      <div className="border-t border-slate-800/60 bg-[#0B0E14]/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 scrollbar-none">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        item.badgeColor || 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};
