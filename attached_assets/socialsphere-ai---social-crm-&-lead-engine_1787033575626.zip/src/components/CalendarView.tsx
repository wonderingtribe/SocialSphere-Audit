import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar as CalendarIcon,
  Clock,
  Video,
  Send,
  Plus,
  CheckCircle2,
  AlertCircle,
  User,
  ShieldCheck,
} from 'lucide-react';

export const CalendarView: React.FC = () => {
  const {
    followUps,
    posts,
    updateFollowUpStatus,
    setIsNewPostModalOpen,
    setIsScheduleModalOpen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'demos' | 'posts'>('all');

  const scheduledPosts = posts.filter((p) => p.status === 'scheduled');

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-purple-600/15 border border-purple-500/30">
              <CalendarIcon className="w-5 h-5 text-purple-400" />
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white">
              Schedule & Executive Demo Calendar
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Unified chronological schedule for safe automated social publishing and booked prospect demos.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsScheduleModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Book Follow-Up Call</span>
          </button>

          <button
            onClick={() => setIsNewPostModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Schedule Safe Post</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        {(['all', 'demos', 'posts'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer ${
              activeTab === tab
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            {tab === 'all'
              ? `All Scheduled Events (${followUps.length + scheduledPosts.length})`
              : tab === 'demos'
              ? `Demo Calls (${followUps.length})`
              : `Social Posts (${scheduledPosts.length})`}
          </button>
        ))}
      </div>

      {/* Unified Timeline Cards */}
      <div className="space-y-4">
        {/* Follow-up Demos */}
        {(activeTab === 'all' || activeTab === 'demos') &&
          followUps.map((fup) => (
            <div
              key={fup.id}
              className="p-4 rounded-2xl bg-[#121620] border border-slate-800 hover:border-purple-500/40 transition-all space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
                    <Video className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-400 border border-purple-500/30 uppercase">
                      Executive Demo
                    </span>
                    <h3 className="text-sm font-bold text-white mt-1">{fup.title}</h3>
                  </div>
                </div>

                <div className="text-right text-xs">
                  <span className="font-mono text-cyan-400 font-bold block">
                    {new Date(fup.scheduledAt).toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  <span className="text-[11px] text-slate-400">Duration: {fup.durationMinutes} mins</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 bg-slate-900/70 p-2.5 rounded-xl border border-slate-800">
                {fup.notes}
              </p>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/60">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  Assigned AE: {fup.assignedTo}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateFollowUpStatus(fup.id, 'completed')}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 text-[11px] font-bold border border-emerald-500/30 cursor-pointer"
                  >
                    Mark Done
                  </button>
                </div>
              </div>
            </div>
          ))}

        {/* Scheduled Posts */}
        {(activeTab === 'all' || activeTab === 'posts') &&
          scheduledPosts.map((post) => (
            <div
              key={post.id}
              className="p-4 rounded-2xl bg-[#121620] border border-slate-800 hover:border-blue-500/40 transition-all space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
                    <Send className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30 uppercase">
                        {post.platform} Post
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" />
                        Moderated & Approved
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white mt-1 capitalize">
                      {post.platform} Scheduled Launch
                    </h3>
                  </div>
                </div>

                <div className="text-right text-xs">
                  <span className="font-mono text-cyan-400 font-bold block">
                    {new Date(post.scheduledAt).toLocaleDateString('en-US', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  <span className="text-[11px] text-slate-400">Author: {post.author}</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 bg-slate-900/70 p-2.5 rounded-xl border border-slate-800 font-sans whitespace-pre-wrap">
                {post.content}
              </p>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/60">
                <div className="flex gap-1.5 font-mono text-blue-400 text-[11px]">
                  {post.hashtags?.map((h, i) => (
                    <span key={i}>#{h}</span>
                  ))}
                </div>
                <span className="text-emerald-400 font-medium">Ready for Automated Dispatch</span>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};
