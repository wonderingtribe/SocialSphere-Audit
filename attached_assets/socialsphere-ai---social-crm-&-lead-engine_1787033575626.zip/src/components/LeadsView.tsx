import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lead } from '../types';
import {
  UserCheck,
  UserPlus,
  Mail,
  Calendar,
  Sparkles,
  TrendingUp,
  Target,
  DollarSign,
  Phone,
  MessageSquare,
  Clock,
  ArrowRight,
  Filter,
  Search,
} from 'lucide-react';

export const LeadsView: React.FC = () => {
  const {
    leads,
    activeLead,
    setActiveLead,
    updateLeadStatus,
    personas,
    setIsScheduleModalOpen,
    setSelectedLeadForSchedule,
    setIsEmailModalOpen,
    setSelectedLeadForEmail,
  } = useApp();

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead>(activeLead || leads[0]);

  const filteredLeads = leads.filter((lead) => {
    if (filterStatus !== 'all' && lead.status !== filterStatus) return false;
    if (
      searchQuery &&
      !lead.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !lead.company.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const statuses: Array<{ id: Lead['status']; label: string; color: string }> = [
    { id: 'new', label: 'New Inbound', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
    { id: 'contacted', label: 'Contacted', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
    { id: 'qualified', label: 'Qualified', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
    { id: 'demo_scheduled', label: 'Demo Booked', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
    { id: 'closed_won', label: 'Closed Won', color: 'bg-emerald-600/30 text-emerald-300 border-emerald-500/50' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-600/15 border border-emerald-500/30">
              <UserCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white">
              Social CRM Pipeline & Sentiment Journey
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Track leads converted from social interactions, monitor sentiment progression over time, and trigger demo follow-ups.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Pipeline Value</span>
            <span className="text-sm font-black text-emerald-400">
              ${leads.reduce((s, l) => s + (l.estimatedValue || 0), 0).toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#121620] border border-slate-800 rounded-xl p-3">
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              filterStatus === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200'
            }`}
          >
            All Leads ({leads.length})
          </button>
          {statuses.map((st) => (
            <button
              key={st.id}
              onClick={() => setFilterStatus(st.id)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                filterStatus === st.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200'
              }`}
            >
              {st.label} ({leads.filter((l) => l.status === st.id).length})
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Search lead or company..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none w-56"
          />
        </div>
      </div>

      {/* 2-Column Split: Leads Table / List + Lead Detail Profile */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (5 cols): Leads List */}
        <div className="lg:col-span-5 space-y-3 max-h-[750px] overflow-y-auto pr-1">
          {filteredLeads.map((lead) => {
            const isSelected = selectedLead?.id === lead.id;
            const matchedPersona = personas.find((p) => p.id === lead.matchedPersonaId);

            return (
              <div
                key={lead.id}
                onClick={() => setSelectedLead(lead)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2.5 ${
                  isSelected
                    ? 'bg-[#151C2C] border-emerald-500/60 shadow-lg ring-1 ring-emerald-500/30'
                    : 'bg-[#121620] border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-xs">
                      {lead.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{lead.name}</h4>
                      <span className="text-[10px] text-slate-400">{lead.company}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      ${lead.estimatedValue.toLocaleString()}
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/15 text-blue-400 border border-blue-500/30">
                      Score {lead.leadScore}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="capitalize">{lead.sourcePlatform} Source</span>
                  <span className="text-indigo-300 font-medium truncate max-w-[160px]">
                    {matchedPersona?.name || 'Target Persona'}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px]">
                  <span className="text-slate-400 capitalize">Status: {lead.status.replace('_', ' ')}</span>
                  <span className="text-slate-400">{lead.lastContacted}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right (7 cols): Lead Journey & Action Console */}
        <div className="lg:col-span-7">
          {selectedLead ? (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5 sticky top-24">
              {/* Lead Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    {selectedLead.name}
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                      Score: {selectedLead.leadScore}/100
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {selectedLead.role} @ {selectedLead.company} • {selectedLead.email}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedLeadForEmail(selectedLead);
                      setIsEmailModalOpen(true);
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Email</span>
                  </button>

                  <button
                    onClick={() => {
                      setSelectedLeadForSchedule(selectedLead);
                      setIsScheduleModalOpen(true);
                    }}
                    className="flex items-center gap-1 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-500/25 transition-all cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Book Demo</span>
                  </button>
                </div>
              </div>

              {/* Status Selector */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-xs font-semibold text-slate-400">Pipeline Stage:</span>
                <div className="flex flex-wrap gap-1.5">
                  {statuses.map((st) => (
                    <button
                      key={st.id}
                      onClick={() => updateLeadStatus(selectedLead.id, st.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold capitalize transition-all cursor-pointer ${
                        selectedLead.status === st.id
                          ? st.color
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sentiment Evolution Timeline */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    Sentiment Progression Journey
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {selectedLead.sentimentTrend?.length || 1} touchpoints recorded
                  </span>
                </div>

                <div className="space-y-2 relative pl-4 border-l-2 border-slate-800">
                  {selectedLead.sentimentTrend?.map((trend, idx) => (
                    <div key={idx} className="relative space-y-1 text-xs">
                      <div
                        className={`absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full ${
                          trend.sentiment === 'positive'
                            ? 'bg-emerald-500 ring-4 ring-emerald-500/20'
                            : trend.sentiment === 'negative'
                            ? 'bg-rose-500 ring-4 ring-rose-500/20'
                            : 'bg-amber-500 ring-4 ring-amber-500/20'
                        }`}
                      />
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-white capitalize">
                          {trend.sentiment} Sentiment (Score: {trend.score > 0 ? `+${trend.score}` : trend.score})
                        </span>
                        <span className="text-slate-400 font-mono">{trend.date}</span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed bg-slate-900/60 p-2 rounded-lg border border-slate-800/80">
                        {trend.note}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Deal Notes & Attribution */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <span className="text-[10px] font-bold uppercase text-slate-400">
                  Lead Intelligence & Rep Notes
                </span>
                <p className="text-xs text-slate-300 bg-slate-900 p-3 rounded-xl border border-slate-800 leading-relaxed">
                  {selectedLead.notes || 'Captured via automated social sentiment engine.'}
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-[#121620] border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
              <UserCheck className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-sm font-bold text-white">No Lead Selected</h3>
              <p className="text-xs text-slate-400">Select a lead from the pipeline on the left.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
