import { GoogleGenAI, Type } from '@google/genai';

// Initialize server-side GoogleGenAI client with standard User-Agent header
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY || '';
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

export async function handleSentimentAnalysis(body: {
  text: string;
  authorName?: string;
  platform?: string;
  context?: string;
}) {
  const { text, authorName = 'Prospect', platform = 'linkedin', context = '' } = body;
  const ai = getGeminiClient();

  const prompt = `Analyze the sentiment, emotional nuance, purchase intent, and key themes of the following social media message or comment:
Platform: ${platform}
Author: ${authorName}
Context: ${context || 'General inbound engagement / B2B sales inquiry'}
Content to analyze:
"${text}"

Provide a structured, deep analytical breakdown.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction: `You are an elite Social Media Sentiment & Customer Intelligence Engine for enterprise CRM.
Analyze incoming social messages with extreme accuracy. Categorize sentiment strictly as 'positive', 'neutral', or 'negative'.
Detect subtle emotional nuances (e.g. enthusiastic, frustrated, skeptical, inquisitive, appreciative, urgent, indifferent, confused).
Provide tactical battlecard response advice, lead qualification score (1-100), and 3 distinct suggested reply options.`,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          sentiment: {
            type: Type.STRING,
            description: "Must be 'positive', 'neutral', or 'negative'",
          },
          sentimentScore: {
            type: Type.NUMBER,
            description: 'Float between -1.0 (extremely negative) and 1.0 (extremely positive)',
          },
          confidenceScore: {
            type: Type.NUMBER,
            description: 'Float between 0.0 and 1.0 representing model certainty',
          },
          primaryEmotion: {
            type: Type.STRING,
            description: 'One key emotional nuance e.g. enthusiastic, frustrated, skeptical, inquisitive, appreciative, urgent',
          },
          keyThemes: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2-4 concise themes or topics extracted from message',
          },
          urgencyLevel: {
            type: Type.STRING,
            description: "Must be 'low', 'medium', 'high', or 'critical'",
          },
          recommendedAction: {
            type: Type.STRING,
            description: 'Actionable tactical advice for sales rep or community manager',
          },
          suggestedReplies: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3 distinct, high-converting reply options tailored to the sentiment',
          },
          leadQualificationScore: {
            type: Type.NUMBER,
            description: 'Integer from 1 to 100 indicating buyer intent and lead viability',
          },
        },
        required: [
          'sentiment',
          'sentimentScore',
          'confidenceScore',
          'primaryEmotion',
          'keyThemes',
          'urgencyLevel',
          'recommendedAction',
          'suggestedReplies',
          'leadQualificationScore',
        ],
      },
    },
  });

  const parsed = JSON.parse(response.text || '{}');
  return {
    ...parsed,
    analyzedAt: new Date().toISOString(),
  };
}

export async function handleGeneratePersona(body: {
  industry: string;
  targetRole: string;
  companySize?: string;
  productDescription?: string;
  tonePreference?: string;
}) {
  const {
    industry,
    targetRole,
    companySize = '10 - 250 employees',
    productDescription = 'B2B SaaS and Social Lead Generation platform',
    tonePreference = 'Authoritative yet accessible, ROI-driven',
  } = body;
  const ai = getGeminiClient();

  const prompt = `Create a hyper-detailed, psychologically accurate Customer Persona for B2B/B2C social media marketing and lead generation.
Target Industry: ${industry}
Target Role/Title: ${targetRole}
Company Size / Scale: ${companySize}
Product / Offer: ${productDescription}
Tone Preference: ${tonePreference}

Construct deep psychological profiles including core pain points, buying triggers, common objections, trigger keywords, and proven social hook angles.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction:
        'You are an expert Chief Marketing Officer and Buyer Persona Architect. Generate rich, actionable personas with high marketing utility.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: 'Descriptive persona name e.g. Growth-Focused VP Greg' },
          role: { type: Type.STRING, description: 'Job title / role' },
          companySize: { type: Type.STRING, description: 'Company size range' },
          industry: { type: Type.STRING, description: 'Industry vertical' },
          demographics: {
            type: Type.OBJECT,
            properties: {
              ageRange: { type: Type.STRING },
              location: { type: Type.STRING },
              education: { type: Type.STRING },
              incomeLevel: { type: Type.STRING },
            },
            required: ['ageRange', 'location', 'education', 'incomeLevel'],
          },
          corePainPoints: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-5 vivid business or operational frustrations',
          },
          primaryGoals: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-4 measurable business goals or career aspirations',
          },
          buyingTriggers: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-4 events or moments that cause them to seek a solution immediately',
          },
          objections: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-4 top hesitations or pushbacks during sales conversations',
          },
          preferredChannels: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Social platforms where they are most active (e.g. linkedin, twitter, instagram, youtube)',
          },
          communicationTone: {
            type: Type.STRING,
            description: 'Best communication style and tone to connect with this buyer',
          },
          triggerKeywords: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '4-6 resonant jargon terms or power words',
          },
          suggestedHooks: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3 high-converting social media hook headlines tailored to this persona',
          },
        },
        required: [
          'name',
          'role',
          'companySize',
          'industry',
          'demographics',
          'corePainPoints',
          'primaryGoals',
          'buyingTriggers',
          'objections',
          'preferredChannels',
          'communicationTone',
          'triggerKeywords',
          'suggestedHooks',
        ],
      },
    },
  });

  const parsed = JSON.parse(response.text || '{}');
  return {
    id: 'persona-' + Date.now(),
    ...parsed,
    color: '#3B82F6',
    createdAt: new Date().toISOString(),
  };
}

export async function handleTailorContent(body: {
  persona: any;
  topic: string;
  platform: string;
  goal?: string;
  tone?: string;
  baseContent?: string;
}) {
  const { persona, topic, platform, goal = 'lead_gen', tone = 'authoritative', baseContent = '' } = body;
  const ai = getGeminiClient();

  const prompt = `Write or tailor a high-converting social media post specifically targeted at the following Customer Persona:
Persona Name: ${persona?.name || 'General Buyer'}
Role: ${persona?.role || 'Executive'}
Industry: ${persona?.industry || 'B2B Tech'}
Core Pain Points: ${(persona?.corePainPoints || []).join('; ')}
Buying Triggers: ${(persona?.buyingTriggers || []).join('; ')}
Tone Preference: ${persona?.communicationTone || tone}
Trigger Keywords: ${(persona?.triggerKeywords || []).join(', ')}

Platform: ${platform}
Core Topic / Value Proposition: ${topic}
Primary Goal: ${goal}
Existing Draft (if any): "${baseContent}"

Ensure the hook directly attacks a top pain point, weaves in trigger vocabulary naturally, and ends with a frictionless call-to-action.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction:
        'You are an elite B2B Copywriter who crafts viral, high-converting social media copy strictly tuned to buyer psychology.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          tailoredContent: { type: Type.STRING, description: 'The complete social post copy formatted for the platform' },
          personaMatchScore: { type: Type.NUMBER, description: 'Resonance score 1 to 100' },
          matchExplanation: { type: Type.STRING, description: 'Why this copy specifically triggers this persona' },
          targetedHashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
          ctaSuggestion: { type: Type.STRING, description: 'Customized call to action' },
        },
        required: ['tailoredContent', 'personaMatchScore', 'matchExplanation', 'targetedHashtags', 'ctaSuggestion'],
      },
    },
  });

  return JSON.parse(response.text || '{}');
}

export async function handleModerateContent(body: {
  content: string;
  platform?: string;
  brandRules?: {
    strictness?: string;
    bannedWords?: string[];
    requireCta?: boolean;
    avoidOverpromising?: boolean;
  };
}) {
  const { content, platform = 'general', brandRules } = body;
  const ai = getGeminiClient();

  const prompt = `Perform a comprehensive AI Content Moderation & Brand Safety Audit on the following social media post/reply:
Platform: ${platform}
Content to Audit:
"""${content}"""

Audit for:
1. Brand Safety, Hate Speech, Profanity, Toxicity, or Inappropriate Content
2. Over-Promising, Unrealistic Guarantees, False Claims, or Clickbait (e.g. "make $50k in 2 days guaranteed")
3. Brand Alignment, Professional Tone, and Platform Appropriateness
4. Grammar, Syntax, Punctuation, Spelling, and Readability Level
5. Auto-Sanitization: Provide an enhanced, grammatically pristine, 100% compliant, high-converting version of the content that eliminates all flagged issues.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction: `You are an automated Enterprise Brand Safety & AI Content Moderation Engine.
Evaluate text rigorously.
Assign status:
- 'passed': Content is completely clean, compliant, grammatically correct, and on-brand.
- 'warning': Content has minor issues (e.g. mild hyperbole, punctuation typo, slightly informal tone) that can be improved.
- 'flagged': Content contains serious policy violations, severe overpromising/false claims, toxic language, or extreme grammatical issues that require rejection/correction.

Always provide an 'autoSanitizedContent' string that is ready to replace the flawed text with 1 click.`,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: {
            type: Type.STRING,
            description: "Must be 'passed', 'warning', or 'flagged'",
          },
          safetyScore: {
            type: Type.NUMBER,
            description: '0 to 100 score for brand safety & toxicity freedom (100 = perfectly safe)',
          },
          brandAlignmentScore: {
            type: Type.NUMBER,
            description: '0 to 100 score for tone professionalism and platform fit',
          },
          grammarScore: {
            type: Type.NUMBER,
            description: '0 to 100 score for grammatical and spelling correctness',
          },
          readability: {
            type: Type.STRING,
            description: "Readability tier e.g. 'Easy (Grade 6-8)', 'Standard (Grade 9-11)', 'Complex (Technical)'",
          },
          flags: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                category: {
                  type: Type.STRING,
                  description: "One of 'brand_safety', 'over_promising', 'tone_voice', 'grammar_spelling', 'regulatory', 'platform_policy'",
                },
                severity: {
                  type: Type.STRING,
                  description: "One of 'low', 'medium', 'high'",
                },
                issue: { type: Type.STRING, description: 'Explanation of the detected problem' },
                suggestion: { type: Type.STRING, description: 'Recommended fix' },
              },
              required: ['id', 'category', 'severity', 'issue', 'suggestion'],
            },
          },
          autoSanitizedContent: {
            type: Type.STRING,
            description: 'An improved, polished, 100% compliant version of the original content with all issues corrected',
          },
          summary: {
            type: Type.STRING,
            description: 'Concise 1-sentence verdict on the content quality and compliance',
          },
        },
        required: [
          'status',
          'safetyScore',
          'brandAlignmentScore',
          'grammarScore',
          'readability',
          'flags',
          'autoSanitizedContent',
          'summary',
        ],
      },
    },
  });

  const parsed = JSON.parse(response.text || '{}');
  return {
    id: 'mod-' + Date.now(),
    ...parsed,
    createdAt: new Date().toISOString(),
  };
}

export async function handleGenerateCampaign(body: {
  type?: 'organic' | 'paid';
  title: string;
  description: string;
  websiteUrl?: string;
  targetAudience: string;
  targetPersona?: any;
  goal: string;
  platforms: string[];
  budget?: number;
  customInstructions?: string;
}) {
  const {
    type = 'organic',
    title,
    description,
    websiteUrl = 'https://ai-wonderland.io',
    targetAudience,
    targetPersona,
    goal,
    platforms,
    budget = 0,
    customInstructions = '',
  } = body;
  const ai = getGeminiClient();

  const isPaid = type === 'paid';

  const prompt = `Generate an advanced Growth Campaign architecture (${isPaid ? 'PAID AD CAMPAIGN' : 'ORGANIC GROWTH CAMPAIGN'}):
Campaign Title: ${title}
Campaign Type: ${type.toUpperCase()}
Website Destination / CTA URL: ${websiteUrl}
Product / Value Proposition: ${description}
Target Audience: ${targetAudience}
Target Persona: ${targetPersona?.name ? `${targetPersona.name} (${targetPersona.role} in ${targetPersona.industry})` : 'Target Buyer'}
Persona Pain Points: ${(targetPersona?.corePainPoints || []).join('; ')}
Persona Buying Triggers: ${(targetPersona?.buyingTriggers || []).join('; ')}
Campaign Goal: ${goal}
Channels: ${platforms.join(', ')}
${isPaid ? `Total / Monthly Ad Budget: ${budget}` : 'Strategy: Viral Organic Growth Loop'}
Custom Instructions: ${customInstructions || 'High conversion, brand safe, clear website CTA, zero spam'}

Provide:
1. Complete Campaign Strategy & Persona resonance breakdown
2. 4 Coordinated Posts / Ad Variations with Day offsets, Hook Titles, Copy, Variation Labels (e.g. 'Variation A (Technical Breakdown)' vs 'Variation B (ROI Case Study)'), Hashtags, and explicit Website CTA Link inclusions
3. AI Optimization Benchmark: top performing hook, ab test insight, recommended action
4. Autonomous Conversation Guardrails: rules for how the AI acts as a sales & community assistant (not a bot blasting strangers), detects buying/signup intent, and delivers the website link safely
5. Expected Funnel Metrics for Follower -> Engaged -> Interested -> Website Visitor -> Lead -> Signup`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction:
        'You are an elite Growth Campaign Architect & Performance Marketing Director. Generate realistic, high-converting organic sequences or paid ad sets.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          campaignStrategy: { type: Type.STRING, description: 'Executive summary of campaign strategy' },
          targetPersonaResonance: { type: Type.STRING, description: 'How this campaign appeals to the target persona' },
          posts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                dayOffset: { type: Type.NUMBER, description: 'Day offset (e.g. 1, 3, 5, 7)' },
                platform: { type: Type.STRING },
                hookTitle: { type: Type.STRING },
                content: { type: Type.STRING },
                hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
                suggestedCta: { type: Type.STRING },
                variationLabel: { type: Type.STRING, description: 'e.g. Variation A (Architecture) or Ad Creative 1 (Case Study)' },
              },
              required: ['dayOffset', 'platform', 'hookTitle', 'content', 'hashtags', 'suggestedCta', 'variationLabel'],
            },
          },
          aiOptimization: {
            type: Type.OBJECT,
            properties: {
              topPerformingHook: { type: Type.STRING },
              bestPlatform: { type: Type.STRING },
              abTestInsight: { type: Type.STRING },
              recommendedAction: { type: Type.STRING },
            },
            required: ['topPerformingHook', 'bestPlatform', 'abTestInsight', 'recommendedAction'],
          },
          safetyGuardrails: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '3-4 tactical rules to prevent bot spam and enforce consultative community sales tone',
          },
          estimatedFunnel: {
            type: Type.OBJECT,
            properties: {
              followers: { type: Type.NUMBER },
              engaged: { type: Type.NUMBER },
              interested: { type: Type.NUMBER },
              websiteVisitors: { type: Type.NUMBER },
              leads: { type: Type.NUMBER },
              signups: { type: Type.NUMBER },
            },
            required: ['followers', 'engaged', 'interested', 'websiteVisitors', 'leads', 'signups'],
          },
        },
        required: ['campaignStrategy', 'targetPersonaResonance', 'posts', 'aiOptimization', 'safetyGuardrails', 'estimatedFunnel'],
      },
    },
  });

  return JSON.parse(response.text || '{}');
}

export async function handleSimulateAutonomousConversation(body: {
  commentText: string;
  authorName: string;
  platform: string;
  websiteUrl: string;
  campaignTitle: string;
  guardrails?: string[];
  buyingIntentThreshold?: number;
}) {
  const {
    commentText,
    authorName = 'Alex',
    platform = 'linkedin',
    websiteUrl = 'https://ai-wonderland.io',
    campaignTitle = 'AI-WONDERLAND Launch',
    guardrails = [
      'Act strictly as a helpful, consultative community and tech advisor, never an aggressive sales bot',
      'Detect technical questions and answer accurately',
      'Only send the website signup link when explicit interest or buying intent is detected (>80%)',
    ],
    buyingIntentThreshold = 80,
  } = body;

  const ai = getGeminiClient();

  const prompt = `Simulate an autonomous AI Social Sales/Community Assistant responding to an incoming comment:
Campaign: ${campaignTitle}
Website Link: ${websiteUrl}
Platform: ${platform}
Commenter: ${authorName}
Comment: "${commentText}"

Configured Intent Threshold for Link Delivery: ${buyingIntentThreshold}%
Active Guardrails:
${guardrails.map((g) => `- ${g}`).join('\n')}

Evaluate:
1. Intent analysis: Is the commenter just browsing, curious, skeptical, or displaying explicit buying/signup intent?
2. Calculate buying/signup intent score (1 to 100).
3. Determine if the website link should be included in this touchpoint (only if intent >= ${buyingIntentThreshold}% or explicit link request).
4. Formulate the autonomous reply upholding the consultative community assistant tone (NO spam, NO generic bot replies).
5. Recommend next action in the conversion pipeline (e.g. "Move to Lead Manager", "Continue Technical Discussion", "Deliver Website Link", "Acknowledge & Observe").`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.7-flash',
    contents: prompt,
    config: {
      systemInstruction:
        'You are an Autonomous AI Social Sales & Community Assistant. You act as a high-EQ, technical consultative partner for inbound social comments.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          intentType: {
            type: Type.STRING,
            description: "e.g. 'high_buying_intent', 'technical_inquiry', 'pricing_question', 'skeptical_objection', 'casual_interest'",
          },
          intentScore: { type: Type.NUMBER, description: '1 to 100 intent score' },
          shouldSendLink: { type: Type.BOOLEAN },
          replyText: { type: Type.STRING, description: 'The generated empathetic, conversational reply' },
          guardrailCheckPassed: { type: Type.BOOLEAN },
          guardrailNotes: { type: Type.STRING, description: 'Explanation of safety & brand alignment checks' },
          nextPipelineStep: {
            type: Type.STRING,
            description: "e.g. 'Move to Lead Manager', 'Deliver Website Link', 'Engage Technical Thread'",
          },
          detectedFunnelStage: {
            type: Type.STRING,
            description: "Must be one of: 'Follower', 'Engaged', 'Interested', 'Website Visitor', 'Lead', 'Signup'",
          },
        },
        required: [
          'intentType',
          'intentScore',
          'shouldSendLink',
          'replyText',
          'guardrailCheckPassed',
          'guardrailNotes',
          'nextPipelineStep',
          'detectedFunnelStage',
        ],
      },
    },
  });

  return JSON.parse(response.text || '{}');
}
