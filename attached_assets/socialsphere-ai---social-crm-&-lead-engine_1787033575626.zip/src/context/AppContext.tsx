import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  BrandSafetyPolicy,
  CalendarFollowUp,
  Campaign,
  CustomerPersona,
  GrowthAccountRank,
  GrowthAchievement,
  GrowthNpc,
  GrowthRankTier,
  Lead,
  ModerationReport,
  RankUpEvent,
  SentimentAnalysis,
  SentimentType,
  SocialMessage,
  SocialPlatform,
  SocialPost,
  TeamMember,
} from '../types';
import {
  analyzeSentimentApi,
  generatePersonaApi,
  moderateContentApi,
} from '../services/geminiService';
import {
  INITIAL_ACCOUNT_RANK,
  INITIAL_ACHIEVEMENTS,
  INITIAL_TOWER_NPCS,
  RANK_TIERS,
} from '../data/rpgDefaults';

export type AppView =
  | 'dashboard'
  | 'communications'
  | 'personas'
  | 'moderation'
  | 'campaigns'
  | 'leads'
  | 'calendar';

interface AppContextType {
  // Navigation
  activeView: AppView;
  setActiveView: (view: AppView) => void;

  // Social-Growth RPG & 3D Tower
  growthRank: GrowthAccountRank;
  achievements: GrowthAchievement[];
  towerNpcs: GrowthNpc[];
  rankUpEvent: RankUpEvent | null;
  setRankUpEvent: (ev: RankUpEvent | null) => void;
  isAchievementsDrawerOpen: boolean;
  setIsAchievementsDrawerOpen: (open: boolean) => void;
  addXp: (amount: number) => void;
  claimAchievement: (achId: string) => void;
  triggerFollowerSurge: () => void;
  triggerLeadArrival: (name?: string, platform?: SocialPlatform) => void;
  triggerSignupCelebration: (name?: string) => void;
  triggerPortalVisitor: () => void;
  triggerConversationBubble: (customText?: string) => void;
  simulateGrowthDip: () => void;

  // Personas
  personas: CustomerPersona[];
  activePersona: CustomerPersona | null;
  setActivePersona: (p: CustomerPersona | null) => void;
  addPersona: (p: CustomerPersona) => void;
  updatePersona: (id: string, p: Partial<CustomerPersona>) => void;
  deletePersona: (id: string) => void;
  generatePersona: (params: {
    industry: string;
    targetRole: string;
    companySize?: string;
    productDescription?: string;
    tonePreference?: string;
  }) => Promise<CustomerPersona>;

  // Social Messages & Sentiment
  messages: SocialMessage[];
  filterSentiment: SentimentType | 'all' | 'high_urgency';
  setFilterSentiment: (val: SentimentType | 'all' | 'high_urgency') => void;
  filterPlatform: SocialPlatform | 'all';
  setFilterPlatform: (val: SocialPlatform | 'all') => void;
  analyzeMessage: (messageId: string) => Promise<SentimentAnalysis | null>;
  replyToMessage: (
    messageId: string,
    replyText: string,
    isAiGenerated?: boolean
  ) => Promise<void>;
  convertMessageToLead: (messageId: string) => Lead;
  batchAnalyzeSentiment: () => Promise<void>;
  isBatchAnalyzing: boolean;

  // Moderation
  moderationReports: ModerationReport[];
  brandSafetyPolicy: BrandSafetyPolicy;
  updateBrandSafetyPolicy: (policy: Partial<BrandSafetyPolicy>) => void;
  moderateText: (
    content: string,
    platform?: SocialPlatform
  ) => Promise<ModerationReport>;
  applySanitizedFix: (reportId: string) => void;
  approveReport: (reportId: string) => void;
  rejectReport: (reportId: string) => void;

  // Posts
  posts: SocialPost[];
  addPost: (post: Omit<SocialPost, 'id' | 'createdAt'>) => SocialPost;
  updatePost: (id: string, updates: Partial<SocialPost>) => void;
  deletePost: (id: string) => void;

  // Campaigns
  campaigns: Campaign[];
  addCampaign: (campaign: Omit<Campaign, 'id'>) => Campaign;
  updateCampaign: (id: string, updates: Partial<Campaign>) => void;
  deleteCampaign: (id: string) => void;

  // Leads
  leads: Lead[];
  activeLead: Lead | null;
  setActiveLead: (l: Lead | null) => void;
  addLead: (lead: Omit<Lead, 'id'>) => Lead;
  updateLeadStatus: (id: string, status: Lead['status']) => void;
  updateLead: (id: string, updates: Partial<Lead>) => void;

  // Calendar
  followUps: CalendarFollowUp[];
  addFollowUp: (followUp: Omit<CalendarFollowUp, 'id'>) => CalendarFollowUp;
  updateFollowUpStatus: (
    id: string,
    status: CalendarFollowUp['status']
  ) => void;

  // Team
  teamMembers: TeamMember[];

  // Modals & Triggers
  isNewPostModalOpen: boolean;
  setIsNewPostModalOpen: (open: boolean) => void;
  isNewCampaignModalOpen: boolean;
  setIsNewCampaignModalOpen: (open: boolean) => void;
  isNewPersonaModalOpen: boolean;
  setIsNewPersonaModalOpen: (open: boolean) => void;
  isAutoReplyModalOpen: boolean;
  setIsAutoReplyModalOpen: (open: boolean) => void;
  selectedMessageForReply: SocialMessage | null;
  setSelectedMessageForReply: (msg: SocialMessage | null) => void;
  isScheduleModalOpen: boolean;
  setIsScheduleModalOpen: (open: boolean) => void;
  selectedLeadForSchedule: Lead | null;
  setSelectedLeadForSchedule: (lead: Lead | null) => void;
  isEmailModalOpen: boolean;
  setIsEmailModalOpen: (open: boolean) => void;
  selectedLeadForEmail: Lead | null;
  setSelectedLeadForEmail: (lead: Lead | null) => void;
  isModerationDetailModalOpen: boolean;
  setIsModerationDetailModalOpen: (open: boolean) => void;
  selectedModerationReport: ModerationReport | null;
  setSelectedModerationReport: (rep: ModerationReport | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial Mock Data
const INITIAL_PERSONAS: CustomerPersona[] = [
  {
    id: 'persona-1',
    name: 'Growth SaaS Founder (Sam)',
    role: 'Founder & CEO',
    companySize: '10 - 50 employees',
    industry: 'B2B SaaS / AI Technology',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    color: '#3B82F6',
    demographics: {
      ageRange: '28 - 42',
      location: 'San Francisco / Austin / Remote',
      education: 'B.S. Computer Science / Business',
      incomeLevel: '$150k - $280k',
    },
    corePainPoints: [
      'High SDR overhead with declining cold email reply rates',
      'Losing hot inbound leads due to slow (24hr+) social comment response times',
      'Need to scale pipeline without hiring 3 additional marketing headcount',
    ],
    primaryGoals: [
      'Book 40+ high-intent discovery calls per month through organic social channels',
      'Automate lead capture directly from LinkedIn & Twitter interactions into CRM',
      'Build founder personal brand with high-authority thought leadership',
    ],
    buyingTriggers: [
      'Just closed Seed / Series A funding round and need rapid ARR acceleration',
      'CAC exceeded $1,800 on paid Google/Meta ads',
      'Saw competitor founder generating massive inbound pipeline on LinkedIn',
    ],
    objections: [
      'Will AI auto-responses sound robotic or damage our executive credibility?',
      'How difficult is it to integrate with our current CRM and Slack notifications?',
    ],
    preferredChannels: ['linkedin', 'twitter', 'youtube'],
    communicationTone: 'Direct, data-driven, authentic, high-velocity, zero corporate fluff',
    triggerKeywords: ['Pipeline Velocity', 'CAC Reduction', 'Organic Inbound', 'SDR Automation', 'High-Intent Leads'],
    suggestedHooks: [
      'Why 85% of B2B cold emails are ignored in 2026 (and the social pipeline shift we made)',
      'We stopped running $15k/mo paid ads and replaced them with this 3-step social comment funnel',
      'How one LinkedIn post generated 42 qualified SaaS demos in 72 hours',
    ],
    isDefault: true,
    createdAt: '2026-08-01T10:00:00Z',
  },
  {
    id: 'persona-2',
    name: 'Enterprise Marketing VP (Victoria)',
    role: 'VP of Demand Generation',
    companySize: '200 - 1,500 employees',
    industry: 'Enterprise Software & Cybersecurity',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    color: '#8B5CF6',
    demographics: {
      ageRange: '38 - 52',
      location: 'New York / Chicago / London',
      education: 'MBA / Marketing & Analytics',
      incomeLevel: '$220k - $380k',
    },
    corePainPoints: [
      'Brand safety risks from rogue or non-compliant social posts across 20+ reps',
      'Fragmented attribution between multi-channel social engagement and pipeline revenue',
      'Strict corporate compliance & legal review bottlenecks that slow marketing cadence',
    ],
    primaryGoals: [
      'Enforce automated AI brand moderation and compliance gates across all channels',
      'Demonstrate clean ROI and multi-touch pipeline attribution to the Board',
      'Scale social selling consistency across 40 SDRs and Account Executives',
    ],
    buyingTriggers: [
      'Upcoming quarterly board review requiring demand generation efficiency numbers',
      'Brand safety scare or compliance audit on unvetted social claims',
      'Enterprise marketing tech consolidation initiative',
    ],
    objections: [
      'Does the platform support enterprise role-based access control and audit logging?',
      'Can we customize brand safety moderation rules to our strict legal guidelines?',
    ],
    preferredChannels: ['linkedin', 'twitter'],
    communicationTone: 'Strategic, analytical, governance-focused, enterprise-grade, ROI-proven',
    triggerKeywords: ['Enterprise Compliance', 'Brand Safety', 'Pipeline Governance', 'Attribution', 'SOC-2'],
    suggestedHooks: [
      'The Enterprise CMO Guide to Scaling Social Selling Without Brand Safety Disasters',
      'How to audit 500+ employee social posts for SEC & FTC compliance automatically',
      'The 3 demand generation metrics Fortune 500 tech boards actually care about',
    ],
    createdAt: '2026-08-05T14:30:00Z',
  },
  {
    id: 'persona-3',
    name: 'Digital Agency Growth Director (Alex)',
    role: 'Head of Client Acquisition',
    companySize: '15 - 80 employees',
    industry: 'Performance Marketing & Creative Agencies',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    color: '#10B981',
    demographics: {
      ageRange: '26 - 38',
      location: 'Los Angeles / Miami / Remote',
      education: 'B.A. Communications / Advertising',
      incomeLevel: '$110k - $190k',
    },
    corePainPoints: [
      'Managing social engagement for 15+ client accounts simultaneously is exhausting',
      'High client churn when agency cannot prove direct lead generation from social efforts',
      'Time-consuming sentiment triage across thousands of incoming DMs and comments',
    ],
    primaryGoals: [
      'Deliver turnkey automated lead qualification and sentiment tracking for all clients',
      'Increase agency retainer value by offering AI social CRM as a premium upsell',
      'Reduce response time to under 3 minutes across client social channels',
    ],
    buyingTriggers: [
      'Signed 3 new enterprise retainers and team capacity is stretched to the limit',
      'Client demanding weekly sentiment and lead attribution reports',
      'Need modern AI tech stack to win competitive client RFP pitches',
    ],
    objections: [
      'Can we manage multi-tenant client accounts and white-label reporting?',
      'What is the pricing model when scaling across 20+ social profiles?',
    ],
    preferredChannels: ['instagram', 'tiktok', 'linkedin', 'facebook'],
    communicationTone: 'Creative, fast-paced, conversion-obsessed, tactical, client-centric',
    triggerKeywords: ['Multi-Account', 'Client Retention', 'White-Label', 'Turnkey Automation', 'MRR Upsell'],
    suggestedHooks: [
      'How our agency 4x’d client retention by turning social comments into revenue dashboards',
      'The exact tech stack we use to manage 25 client social inboxes in 45 mins/day',
      'Stop reporting vanity impressions. Here is the lead CRM report our clients love.',
    ],
    createdAt: '2026-08-10T09:15:00Z',
  },
];

const INITIAL_MESSAGES: SocialMessage[] = [
  {
    id: 'msg-1',
    platform: 'linkedin',
    authorName: 'Marcus Vance',
    authorHandle: '@marcus-vance-b2b',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    authorRole: 'VP of Sales @ HyperScale Tech',
    authorCompany: 'HyperScale Cloud (Series B)',
    type: 'comment',
    content: 'We have been trying to solve comment lead routing for 6 months. How quickly can your AI qualify incoming LinkedIn leads and sync them directly into our HubSpot pipeline? We are ready to run a trial for our 12 SDRs.',
    timestamp: '15 mins ago',
    status: 'unanswered',
    associatedPostTitle: 'Why 85% of B2B cold emails are ignored in 2026',
    replies: [],
    sentimentAnalysis: {
      sentiment: 'positive',
      sentimentScore: 0.94,
      confidenceScore: 0.98,
      primaryEmotion: 'enthusiastic',
      keyThemes: ['HubSpot Integration', 'SDR Team Rollout', 'Immediate Trial Request'],
      urgencyLevel: 'critical',
      recommendedAction: 'Immediate high-intent buyer. Provide instant Calendly VIP link and highlight the 3-minute HubSpot one-click sync.',
      suggestedReplies: [
        'Hi Marcus! Our HubSpot two-way sync takes under 3 minutes to setup. Would love to spin up a sandbox trial for your 12 SDRs today: https://omnilead.ai/vip-demo',
        'Awesome to connect Marcus! We built this specifically for Series B sales teams. Let’s jump on a quick 10-minute workflow setup call: https://omnilead.ai/calendar',
        'Great question Marcus! All qualified comments, sentiment data, and contact info sync to HubSpot deals instantly in real time. Sending you a DM with trial access!',
      ],
      leadQualificationScore: 96,
      analyzedAt: '2026-08-17T08:45:00Z',
    },
  },
  {
    id: 'msg-2',
    platform: 'twitter',
    authorName: 'Elena Rostova',
    authorHandle: '@elena_growth',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    authorRole: 'Head of Marketing',
    authorCompany: 'NovaFlow Analytics',
    type: 'direct_message',
    content: 'Saw your demo video on social lead gen. Our main hesitation is brand safety. If an AI auto-replies to prospects, how do we guarantee it won’t say something misleading or off-brand during a critical discussion?',
    timestamp: '42 mins ago',
    status: 'unanswered',
    replies: [],
    sentimentAnalysis: {
      sentiment: 'neutral',
      sentimentScore: 0.15,
      confidenceScore: 0.92,
      primaryEmotion: 'skeptical',
      keyThemes: ['Brand Safety Hesitation', 'AI Hallucination Risk', 'Governance Rules'],
      urgencyLevel: 'high',
      recommendedAction: 'Address brand moderation architecture directly. Explain the multi-layer Brand Safety Filter and human-in-the-loop approval toggle.',
      suggestedReplies: [
        'Hi Elena, great question! Every generated response passes through our real-time Brand Safety Engine (strictness controls, banned claims, tone gates) and you can set all replies to require 1-click human approval.',
        'Completely understand Elena! We built custom enterprise guardrails so the AI never hallucinates claims, and you can enforce custom brand rules with 100% audit logging.',
        'Hi Elena! You have complete granular control: you can customize prohibited keywords, tone compliance, and even require manual review before anything posts.',
      ],
      leadQualificationScore: 78,
      analyzedAt: '2026-08-17T08:18:00Z',
    },
  },
  {
    id: 'msg-3',
    platform: 'linkedin',
    authorName: 'David Sterling',
    authorHandle: '@david-sterling-cmo',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    authorRole: 'Chief Marketing Officer',
    authorCompany: 'Acuity Financial Cloud',
    type: 'comment',
    content: 'Your pricing page is super confusing on enterprise tiers. We reached out to support yesterday and still haven’t heard back. Not a great first impression when evaluating a $30k tool.',
    timestamp: '2 hours ago',
    status: 'unanswered',
    associatedPostTitle: 'The Enterprise CMO Guide to Scaling Social Selling',
    replies: [],
    sentimentAnalysis: {
      sentiment: 'negative',
      sentimentScore: -0.82,
      confidenceScore: 0.96,
      primaryEmotion: 'frustrated',
      keyThemes: ['Support Delays', 'Enterprise Pricing Confusion', 'High-Value Evaluation ($30k)'],
      urgencyLevel: 'critical',
      recommendedAction: 'High-value executive prospect with negative customer experience. Issue sincere apology, prioritize instant executive escalation, and send direct private DM.',
      suggestedReplies: [
        'Hi David, deeply apologize for the delay! That is definitely not our standard. I am DMing you directly right now with our transparent Enterprise tier breakdown and my personal direct line.',
        'David, thank you for calling this out and sincere apologies. I have escalated your ticket directly to our VP of Solutions and will personally follow up via email within 5 minutes.',
        'Hi David, we take support speed very seriously and we dropped the ball here. Connecting with you right now on LinkedIn messages to answer every pricing question immediately.',
      ],
      leadQualificationScore: 82,
      analyzedAt: '2026-08-17T07:00:00Z',
    },
  },
  {
    id: 'msg-4',
    platform: 'instagram',
    authorName: 'Chloe Bennett',
    authorHandle: '@chloe_agency_media',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
    authorRole: 'Founder @ Bennett Social Studio',
    authorCompany: 'Bennett Social Studio',
    type: 'direct_message',
    content: 'Hey team! Just wanted to share that we used your Persona Builder to target SaaS founders last week and our demo conversion rate jumped from 4% to 18%! Absolutely love this platform! 🚀',
    timestamp: '3 hours ago',
    status: 'replied',
    replies: [
      {
        id: 'rep-1',
        author: 'You (AI Assistant)',
        content: 'Chloe, this is incredible news! 18% demo conversion is world-class! Would you be open to doing a quick 2-minute featured case study with us?',
        timestamp: '2 hours ago',
        isAiGenerated: true,
        moderationStatus: 'passed',
      },
    ],
    sentimentAnalysis: {
      sentiment: 'positive',
      sentimentScore: 0.99,
      confidenceScore: 0.99,
      primaryEmotion: 'appreciative',
      keyThemes: ['Persona Builder Success', '18% Demo Conversion Jump', 'Advocate & Case Study Target'],
      urgencyLevel: 'low',
      recommendedAction: 'Prime case study candidate. Thank them enthusiastically, request a testimonial or joint webinar feature.',
      suggestedReplies: [
        'Chloe, this made our week! Jumping from 4% to 18% conversion is massive. Would love to feature your agency on our homepage case studies!',
        'So thrilled to hear this Chloe! Thank you for the trust. Let us know if you need VIP access to our new multi-client agency features.',
      ],
      leadQualificationScore: 99,
      analyzedAt: '2026-08-17T06:10:00Z',
    },
  },
  {
    id: 'msg-5',
    platform: 'twitter',
    authorName: 'Brian Chen',
    authorHandle: '@brian_dev_ops',
    authorAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&auto=format&fit=crop&q=80',
    authorRole: 'Lead Engineer',
    authorCompany: 'DevSphere Labs',
    type: 'comment',
    content: 'Does the sentiment analysis support multilingual comments (e.g. Spanish, German, French) or only English? We have a global European customer base.',
    timestamp: '5 hours ago',
    status: 'unanswered',
    associatedPostTitle: 'Case Study: 3.4x Pipeline in 45 Days',
    replies: [],
    sentimentAnalysis: {
      sentiment: 'neutral',
      sentimentScore: 0.1,
      confidenceScore: 0.94,
      primaryEmotion: 'inquisitive',
      keyThemes: ['Multilingual Support', 'Global Market Expansion', 'Technical Capability'],
      urgencyLevel: 'medium',
      recommendedAction: 'Confirm full multilingual NLP support (over 40+ languages powered by Gemini) with zero latency.',
      suggestedReplies: [
        'Hi Brian! Yes, our sentiment and moderation engine natively supports 40+ languages including Spanish, German, French, and Japanese with automatic cultural context detection.',
        'Great question Brian! Full multilingual support is enabled by default across all tiers. Would you like to test a sample European dataset?',
      ],
      leadQualificationScore: 65,
      analyzedAt: '2026-08-17T04:00:00Z',
    },
  },
];

const INITIAL_MODERATION_REPORTS: ModerationReport[] = [
  {
    id: 'mod-1',
    contentId: 'post-101',
    contentType: 'post',
    content: 'Stop working 80 hours a week. Our AI software guarantees you will make $50,000 in your first 7 days with zero effort. Click the link now before this secret hack gets taken down!',
    status: 'flagged',
    safetyScore: 42,
    brandAlignmentScore: 35,
    grammarScore: 88,
    readability: 'Standard (Grade 6-8)',
    flags: [
      {
        id: 'flg-1',
        category: 'over_promising',
        severity: 'high',
        issue: 'Unrealistic income guarantee ($50,000 in 7 days with zero effort) violates consumer protection and ad policies.',
        suggestion: 'Replace fake guarantees with authentic ROI metrics and realistic trial expectations.',
      },
      {
        id: 'flg-2',
        category: 'tone_voice',
        severity: 'medium',
        issue: 'Clickbait phrasing ("before this secret hack gets taken down") degrades executive brand trust.',
        suggestion: 'Use professional, benefit-driven language tailored to business decision-makers.',
      },
    ],
    autoSanitizedContent: 'Scaling inbound revenue doesn’t require an 80-hour work week. Our AI Social Lead Engine helps B2B teams automate comment-to-CRM qualification and increase demo bookings by up to 3x. Explore our interactive workflow demo today.',
    summary: 'High-risk content: Multiple policy violations for deceptive income claims and sensationalist clickbait.',
    appliedFix: false,
    createdAt: '2026-08-17T08:30:00Z',
  },
  {
    id: 'mod-2',
    contentId: 'post-102',
    contentType: 'post',
    content: 'If your SDRs are strugling with low conversion on LinkedIn, it’s probably because their not reaching out fast enough. Speed to lead is literally everything in 2026.',
    status: 'warning',
    safetyScore: 95,
    brandAlignmentScore: 88,
    grammarScore: 64,
    readability: 'Easy (Grade 6)',
    flags: [
      {
        id: 'flg-3',
        category: 'grammar_spelling',
        severity: 'medium',
        issue: 'Spelling and grammar errors detected: "strugling" (should be "struggling") and "their not" (should be "they\'re not").',
        suggestion: 'Correct typos to preserve high professional polish.',
      },
    ],
    autoSanitizedContent: 'If your SDRs are struggling with low conversion on LinkedIn, it’s probably because they’re not reaching out fast enough. Speed to lead is everything in 2026.',
    summary: 'Safe content with minor spelling and grammatical errors.',
    appliedFix: false,
    createdAt: '2026-08-17T07:15:00Z',
  },
  {
    id: 'mod-3',
    contentId: 'post-103',
    contentType: 'post',
    content: 'The 3 demand generation metrics Fortune 500 tech boards actually care about: 1. Pipeline Velocity, 2. CAC Payback Period, 3. Net Revenue Retention. Here is our benchmark framework.',
    status: 'passed',
    safetyScore: 100,
    brandAlignmentScore: 98,
    grammarScore: 100,
    readability: 'Professional (Grade 10)',
    flags: [],
    autoSanitizedContent: 'The 3 demand generation metrics Fortune 500 tech boards actually care about: 1. Pipeline Velocity, 2. CAC Payback Period, 3. Net Revenue Retention. Here is our benchmark framework.',
    summary: 'Exceptional quality. Content is fully compliant, on-brand, and grammatically flawless.',
    appliedFix: true,
    createdAt: '2026-08-17T06:00:00Z',
  },
];

const INITIAL_POSTS: SocialPost[] = [
  {
    id: 'post-1',
    platform: 'linkedin',
    content: 'Why 85% of B2B cold emails are ignored in 2026 (and the social pipeline shift we made).\n\nWhen we audited 50 tech startups, the teams closing $100k+ deals had one common playbook: they engaged high-intent commenters within 5 minutes.\n\nHere are the 3 sentiment triggers that consistently predict closed-won revenue:\n1. Direct architecture questions\n2. Competitor feature comparisons\n3. Sandbox trial requests\n\nDrop a comment below and I will send our full Comment-to-CRM Playbook!',
    author: 'Sam Founder',
    scheduledAt: '2026-08-17T14:00:00Z',
    status: 'published',
    likes: 342,
    comments: 68,
    shares: 41,
    impressions: 12840,
    targetPersonaId: 'persona-1',
    hashtags: ['B2BGrowth', 'LeadGeneration', 'SocialSelling', 'RevenueOps'],
    createdAt: '2026-08-16T12:00:00Z',
  },
  {
    id: 'post-2',
    platform: 'twitter',
    content: 'Stop treating social comments like vanity metrics.\n\nEvery positive comment on your product is an active inbound sales opportunity.\n\nIf you aren’t routing high-sentiment comments directly into your CRM pipeline, you are leaving 30% of your revenue on the table.',
    author: 'Sam Founder',
    scheduledAt: '2026-08-18T16:30:00Z',
    status: 'scheduled',
    likes: 89,
    comments: 14,
    shares: 22,
    impressions: 4200,
    targetPersonaId: 'persona-1',
    hashtags: ['SaaS', 'SalesAutomation', 'GrowthHacking'],
    createdAt: '2026-08-17T07:00:00Z',
  },
  {
    id: 'post-3',
    platform: 'linkedin',
    content: 'The Enterprise CMO Guide to Scaling Social Selling Without Brand Safety Disasters.\n\nHow do you empower 50+ sales reps to post authentically while protecting compliance and regulatory guardrails?\n\nRead our complete enterprise governance framework.',
    author: 'Victoria CMO',
    scheduledAt: '2026-08-19T13:00:00Z',
    status: 'scheduled',
    likes: 0,
    comments: 0,
    shares: 0,
    impressions: 0,
    targetPersonaId: 'persona-2',
    hashtags: ['EnterpriseMarketing', 'BrandSafety', 'DemandGen'],
    createdAt: '2026-08-17T08:00:00Z',
  },
];

const INITIAL_LEADS: Lead[] = [
  {
    id: 'lead-1',
    name: 'Marcus Vance',
    email: 'm.vance@hyperscalecloud.io',
    company: 'HyperScale Cloud',
    role: 'VP of Sales',
    sourcePlatform: 'linkedin',
    status: 'qualified',
    leadScore: 96,
    sentimentTrend: [
      { date: '2026-08-14', sentiment: 'neutral', score: 0.2, note: 'Initial profile view and post like' },
      { date: '2026-08-16', sentiment: 'positive', score: 0.75, note: 'Asked about HubSpot sync on comment thread' },
      { date: '2026-08-17', sentiment: 'positive', score: 0.94, note: 'Requested immediate trial for 12 SDRs' },
    ],
    matchedPersonaId: 'persona-1',
    interactionCount: 5,
    estimatedValue: 24000,
    assignedTo: 'Sarah Jenkins',
    notes: 'Urgent priority. Wants 12-seat SDR rollout with HubSpot two-way sync before end of month.',
    lastContacted: '15 mins ago',
  },
  {
    id: 'lead-2',
    name: 'Elena Rostova',
    email: 'elena@novaflow.ai',
    company: 'NovaFlow Analytics',
    role: 'Head of Marketing',
    sourcePlatform: 'twitter',
    status: 'contacted',
    leadScore: 78,
    sentimentTrend: [
      { date: '2026-08-15', sentiment: 'neutral', score: 0.0, note: 'Retweeted benchmark study' },
      { date: '2026-08-17', sentiment: 'neutral', score: 0.15, note: 'Expressed hesitation around AI brand safety in DM' },
    ],
    matchedPersonaId: 'persona-2',
    interactionCount: 3,
    estimatedValue: 14500,
    assignedTo: 'Alex Rivera',
    notes: 'Evaluating for 4 marketing reps. Send Brand Safety Whitepaper and SOC-2 compliance summary.',
    lastContacted: '42 mins ago',
  },
  {
    id: 'lead-3',
    name: 'David Sterling',
    email: 'd.sterling@acuityfinancial.com',
    company: 'Acuity Financial Cloud',
    role: 'Chief Marketing Officer',
    sourcePlatform: 'linkedin',
    status: 'new',
    leadScore: 82,
    sentimentTrend: [
      { date: '2026-08-17', sentiment: 'negative', score: -0.82, note: 'Frustrated by pricing page and support delay' },
    ],
    matchedPersonaId: 'persona-2',
    interactionCount: 1,
    estimatedValue: 36000,
    assignedTo: 'Sarah Jenkins',
    notes: 'High ARR deal ($30k+). Sincere executive touch needed to repair first impression.',
    lastContacted: '2 hours ago',
  },
  {
    id: 'lead-4',
    name: 'Chloe Bennett',
    email: 'chloe@bennettsocial.co',
    company: 'Bennett Social Studio',
    role: 'Founder & CEO',
    sourcePlatform: 'instagram',
    status: 'demo_scheduled',
    leadScore: 99,
    sentimentTrend: [
      { date: '2026-08-10', sentiment: 'positive', score: 0.6, note: 'Signed up for self-serve trial' },
      { date: '2026-08-15', sentiment: 'positive', score: 0.85, note: 'Achieved 18% demo conversion jump' },
      { date: '2026-08-17', sentiment: 'positive', score: 0.99, note: 'Agreed to joint case study and agency plan upgrade' },
    ],
    matchedPersonaId: 'persona-3',
    interactionCount: 8,
    estimatedValue: 18000,
    assignedTo: 'Alex Rivera',
    notes: 'Customer advocate. Upgrading to Agency Multi-Client Tier ($1.5k/mo) on upcoming demo call.',
    lastContacted: '2 hours ago',
  },
];

const INITIAL_CAMPAIGNS: Campaign[] = [
  {
    id: 'camp-1',
    type: 'organic',
    title: 'Launch AI-WONDERLAND Growth Engine',
    description: 'Multi-platform organic viral sequence driving high-intent web developers, SaaS builders, and AI creators to visit the website, follow social hubs, and sign up for early beta access.',
    websiteUrl: 'https://ai-wonderland.io',
    targetAudience: 'Web developers, SaaS builders, AI developers',
    targetPersonaId: 'persona-1',
    goal: 'website_traffic',
    platforms: ['instagram', 'facebook', 'linkedin', 'twitter', 'tiktok'],
    status: 'active',
    startDate: '2026-08-15',
    endDate: '2026-09-14',
    budget: 0,
    leadsGenerated: 142,
    conversionRate: 18.6,
    customInstructions: 'Focus on hands-on developer experience, zero marketing fluff, speed of shipping, and direct link to interactive sandbox.',
    strategySummary: 'Autonomous organic growth loop: pair educational architecture deep-dives on LinkedIn and X with viral UI demo clips on TikTok and Instagram. The AI monitors all replies, engages technical questions, and drops the website link when high intent is detected.',
    targetMetrics: {
      websiteVisitors: 4820,
      signups: 890,
      followersGained: 2340,
      leadsCaptured: 142,
    },
    conversionFunnel: {
      followers: 2340,
      engaged: 1820,
      interested: 940,
      websiteVisitors: 4820,
      leads: 520,
      signups: 890,
    },
    autonomousConversations: {
      enabled: true,
      requireApproval: false,
      buyingIntentThreshold: 80,
      ctaLinkTrigger: true,
      monitoredInteractionsCount: 412,
      activeConversationsCount: 86,
      linksSentCount: 158,
      safetyGuardrails: [
        'Act strictly as a helpful, consultative community and tech advisor, never an aggressive sales bot',
        'Detect technical questions and answer accurately based on verified platform documentation',
        'Only send the website signup link when explicit interest or buying intent is detected (>80%)',
        'Automated brand safety and grammar pre-check before dispatching any comment reply',
      ],
    },
    aiOptimization: {
      topPerformingHook: 'Why 85% of developers struggle with AI app deployment (and the 60s fix)',
      bestPlatform: 'linkedin',
      abTestInsight: 'Post A (Technical breakdown + live code) drove 2.8x higher website traffic than Post B (General feature overview).',
      recommendedAction: 'Increase TikTok short video breakdown frequency by 40% and double down on LinkedIn developer carousels.',
      lastOptimizedAt: '2026-08-17T08:30:00Z',
    },
    posts: [
      {
        id: 'cp-1',
        dayOffset: 1,
        platform: 'linkedin',
        hookTitle: 'Why 85% of developers struggle with AI app deployment in 2026',
        content: 'Most engineering teams spend 3 weeks just wiring OAuth, database auth, and rate limiting for AI agents.\n\nWe built AI-WONDERLAND to cut that to 45 seconds with instant full-stack agent sandboxes.\n\nHere is the architecture breakdown:',
        hashtags: ['WebDev', 'AIBuilders', 'SaaSArchitecture', 'IndieHackers'],
        suggestedCta: 'Visit https://ai-wonderland.io to spin up a live agent in your browser.',
        status: 'published',
        moderationStatus: 'passed',
        variationLabel: 'Variation A (Technical Architecture)',
        clicks: 1420,
        signups: 284,
      },
      {
        id: 'cp-2',
        dayOffset: 3,
        platform: 'twitter',
        hookTitle: 'Ship a full-stack AI SaaS in 1 weekend: The 2026 Stack',
        content: '1/4 The stack modern builders are using to reach $10k MRR without writing boilerplate:\n\n• AI-WONDERLAND for instant agent backends\n• Tailwind CSS for UI polish\n• SocialSphere for automated comment conversion\n\nFull guide + free templates linked below 👇',
        hashtags: ['BuildInPublic', 'SaaS', 'DevTools'],
        suggestedCta: 'Try the playground free: https://ai-wonderland.io',
        status: 'published',
        moderationStatus: 'passed',
        variationLabel: 'Variation B (Ship In 1 Weekend)',
        clicks: 1190,
        signups: 215,
      },
      {
        id: 'cp-3',
        dayOffset: 5,
        platform: 'tiktok',
        hookTitle: 'POV: You built an entire AI web app in 3 minutes during lunch break',
        content: 'Watch me prompt an entire multi-agent workflow, connect SQLite, and deploy to Cloud Run live.\n\nNo config files. No CORS bugs.',
        hashtags: ['Coding', 'TechTok', 'WebDeveloper', 'AIApp'],
        suggestedCta: 'Link in bio -> https://ai-wonderland.io',
        status: 'scheduled',
        moderationStatus: 'passed',
        variationLabel: 'Variation C (Quick Video Demo)',
        clicks: 860,
        signups: 198,
      },
      {
        id: 'cp-4',
        dayOffset: 7,
        platform: 'instagram',
        hookTitle: 'The 5 Visual Flowcharts Every AI Developer Needs to Save',
        content: 'From token context caching to human-in-the-loop validation triggers. Save this carousel for your next build sprint! 💡',
        hashtags: ['DevelopersOfInstagram', 'CodeNewbie', 'AIProgramming'],
        suggestedCta: 'Get the full PDF pack + sandbox at https://ai-wonderland.io',
        status: 'scheduled',
        moderationStatus: 'passed',
        variationLabel: 'Variation D (Infographic Carousel)',
        clicks: 740,
        signups: 132,
      },
    ],
  },
  {
    id: 'camp-2',
    type: 'paid',
    title: 'Enterprise Social Demand Gen & Inbound Paid Ads',
    description: 'High-intent sponsored placements and carousel ad creatives across LinkedIn and Meta targeting VPs of Engineering, CROs, and Enterprise Decision Makers.',
    websiteUrl: 'https://socialsphere.ai/enterprise',
    targetAudience: 'VPs of Revenue Ops, CROs, CMOs, Enterprise Growth Directors',
    targetPersonaId: 'persona-1',
    goal: 'lead_gen',
    platforms: ['linkedin', 'facebook', 'twitter'],
    status: 'active',
    startDate: '2026-08-10',
    endDate: '2026-08-31',
    budget: 8500,
    leadsGenerated: 84,
    conversionRate: 14.8,
    customInstructions: 'Emphasize enterprise SOC2 compliance, CRM integration with Salesforce/HubSpot, and verified 3.4x ROI case study.',
    strategySummary: 'Paid acquisition targeting high-LTV B2B accounts. Focus on sponsored thought leadership with high-converting CTA leads forms and direct demo booking calendar.',
    targetMetrics: {
      websiteVisitors: 6200,
      signups: 340,
      followersGained: 810,
      leadsCaptured: 84,
      adImpressions: 48500,
      cpc: 2.14,
      cpm: 18.5,
      cpl: 42.0,
      roas: 3.4,
    },
    conversionFunnel: {
      followers: 810,
      engaged: 1450,
      interested: 620,
      websiteVisitors: 6200,
      leads: 280,
      signups: 340,
    },
    autonomousConversations: {
      enabled: true,
      requireApproval: true,
      buyingIntentThreshold: 90,
      ctaLinkTrigger: true,
      monitoredInteractionsCount: 198,
      activeConversationsCount: 42,
      linksSentCount: 78,
      safetyGuardrails: [
        'Enterprise compliance review: Never discuss contract discounts autonomously',
        'Flag pricing and security questions for immediate Senior AE triage',
        'Provide SOC2 and GDPR compliance whitepaper links upon request',
      ],
    },
    aiOptimization: {
      topPerformingHook: 'The Enterprise Guide to Scaling Social Selling Without Compliance Risk',
      bestPlatform: 'linkedin',
      abTestInsight: 'Ad Creative A (Customer Proof & Metrics) yields a $28 CPL vs $64 CPL on Creative B (Generic Product UI).',
      recommendedAction: 'Reallocate $2,000 from Meta ad sets into LinkedIn Sponsored Message sequences.',
      lastOptimizedAt: '2026-08-17T07:45:00Z',
    },
    posts: [
      {
        id: 'cp-201',
        dayOffset: 1,
        platform: 'linkedin',
        hookTitle: '[Sponsored] Stop losing 60% of social inbound pipeline to slow SDR response times',
        content: 'Enterprise revenue teams using SocialSphere automate sentiment triage, guardrail AI responses, and push qualified leads straight to Salesforce in seconds.\n\n📊 Benchmark: 3.4x demo booking increase in 30 days.',
        hashtags: ['EnterpriseSales', 'RevenueOps', 'SalesLeadership'],
        suggestedCta: 'Request Enterprise Demo: https://socialsphere.ai/enterprise',
        status: 'published',
        moderationStatus: 'passed',
        variationLabel: 'Ad Creative 1 (ROI Case Study)',
        clicks: 3400,
        signups: 190,
      },
      {
        id: 'cp-202',
        dayOffset: 4,
        platform: 'facebook',
        hookTitle: 'How Top B2B Companies Turn Comment Sections Into Revenue Engines',
        content: 'See how hyper-growth brands capture high-intent buyers directly from Instagram and Facebook conversations.',
        hashtags: ['B2BMarketing', 'DemandGen'],
        suggestedCta: 'Download Enterprise Whitepaper: https://socialsphere.ai/enterprise',
        status: 'published',
        moderationStatus: 'passed',
        variationLabel: 'Ad Creative 2 (Whitepaper Lead Magnet)',
        clicks: 2100,
        signups: 110,
      },
    ],
  },
];

const INITIAL_FOLLOWUPS: CalendarFollowUp[] = [
  {
    id: 'fup-1',
    leadId: 'lead-1',
    leadName: 'Marcus Vance (HyperScale Cloud)',
    title: 'Executive Discovery & HubSpot 12-Seat Trial Setup',
    type: 'discovery_call',
    scheduledAt: '2026-08-18T10:00:00Z',
    durationMinutes: 30,
    assignedTo: 'Sarah Jenkins',
    notes: 'Walk through HubSpot two-way comment lead sync and configure SDR routing rules.',
    status: 'scheduled',
  },
  {
    id: 'fup-2',
    leadId: 'lead-4',
    leadName: 'Chloe Bennett (Bennett Social Studio)',
    title: 'Agency Multi-Client Upgrade & Case Study Interview',
    type: 'demo',
    scheduledAt: '2026-08-19T14:30:00Z',
    durationMinutes: 45,
    assignedTo: 'Alex Rivera',
    notes: 'Showcase white-label client reporting and finalize 20-account retainer package.',
    status: 'scheduled',
  },
];

const INITIAL_TEAM: TeamMember[] = [
  {
    id: 'tm-1',
    name: 'Sarah Jenkins',
    role: 'Senior Enterprise AE',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    email: 'sarah@omnilead.ai',
    leadsAssigned: 18,
    closedRevenue: 142000,
  },
  {
    id: 'tm-2',
    name: 'Alex Rivera',
    role: 'Growth SDR & Account Manager',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    email: 'alex@omnilead.ai',
    leadsAssigned: 24,
    closedRevenue: 86000,
  },
];

const INITIAL_BRAND_POLICY: BrandSafetyPolicy = {
  strictness: 'standard',
  bannedKeywords: ['guaranteed 1000%', 'get rich quick', 'secret hack', 'risk free money'],
  prohibitGuarantees: true,
  requireDisclaimer: true,
  enforceBrandTone: true,
  preferredTone: 'Authoritative, data-driven, empathetic, enterprise-compliant',
  autoBlockFlagged: true,
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<AppView>('dashboard');
  const [personas, setPersonas] = useState<CustomerPersona[]>(INITIAL_PERSONAS);
  const [activePersona, setActivePersona] = useState<CustomerPersona | null>(INITIAL_PERSONAS[0]);
  const [messages, setMessages] = useState<SocialMessage[]>(INITIAL_MESSAGES);
  const [filterSentiment, setFilterSentiment] = useState<SentimentType | 'all' | 'high_urgency'>('all');
  const [filterPlatform, setFilterPlatform] = useState<SocialPlatform | 'all'>('all');
  const [moderationReports, setModerationReports] = useState<ModerationReport[]>(INITIAL_MODERATION_REPORTS);
  const [brandSafetyPolicy, setBrandSafetyPolicy] = useState<BrandSafetyPolicy>(INITIAL_BRAND_POLICY);
  const [posts, setPosts] = useState<SocialPost[]>(INITIAL_POSTS);
  const [campaigns, setCampaigns] = useState<Campaign[]>(INITIAL_CAMPAIGNS);
  const [leads, setLeads] = useState<Lead[]>(INITIAL_LEADS);
  const [activeLead, setActiveLead] = useState<Lead | null>(INITIAL_LEADS[0]);
  const [followUps, setFollowUps] = useState<CalendarFollowUp[]>(INITIAL_FOLLOWUPS);
  const [teamMembers] = useState<TeamMember[]>(INITIAL_TEAM);
  const [isBatchAnalyzing, setIsBatchAnalyzing] = useState<boolean>(false);

  // Social-Growth RPG & 3D Tower States
  const [growthRank, setGrowthRank] = useState<GrowthAccountRank>(INITIAL_ACCOUNT_RANK);
  const [achievements, setAchievements] = useState<GrowthAchievement[]>(INITIAL_ACHIEVEMENTS);
  const [towerNpcs, setTowerNpcs] = useState<GrowthNpc[]>(INITIAL_TOWER_NPCS);
  const [rankUpEvent, setRankUpEvent] = useState<RankUpEvent | null>(null);
  const [isAchievementsDrawerOpen, setIsAchievementsDrawerOpen] = useState(false);

  // Autonomous NPC climbing and banter animation loop
  useEffect(() => {
    const interval = setInterval(() => {
      setTowerNpcs((prevNpcs) =>
        prevNpcs.map((npc) => {
          // If npc is celebrating or in portal, small bounce
          if (npc.status === 'celebrating') {
            return npc;
          }

          // Advance climb progress
          const newProgress = npc.climbProgress + npc.speed * 4;

          // If reached 100 on floor, optionally advance to next floor if not at target
          if (newProgress >= 100 && npc.floor < npc.targetFloor) {
            return {
              ...npc,
              floor: Math.min(5, npc.floor + 1),
              climbProgress: 0,
              speechBubble:
                npc.floor + 1 === 5
                  ? 'Reaching the Summit Crown! 👑'
                  : npc.floor + 1 === 4
                  ? 'High Intent Lead Scored! 🎯'
                  : npc.floor + 1 === 3
                  ? 'Entering Portal... 🌐'
                  : npc.speechBubble,
              bubbleExpiresAt: Date.now() + 8000,
            };
          }

          // Clear expired speech bubbles
          const isBubbleExpired = npc.bubbleExpiresAt && npc.bubbleExpiresAt < Date.now();

          return {
            ...npc,
            climbProgress: Math.min(100, newProgress),
            speechBubble: isBubbleExpired ? undefined : npc.speechBubble,
          };
        })
      );
    }, 1800);

    return () => clearInterval(interval);
  }, []);

  // Add XP and check for Rank-Up
  const addXp = (amount: number) => {
    setGrowthRank((prev) => {
      const newTotalXp = prev.totalXp + amount;
      let newCurrentXp = prev.currentXp + amount;
      let newLevel = prev.level;
      let newXpForNextLevel = prev.xpForNextLevel;
      let currentTier: GrowthRankTier = prev.tier;
      let rankUpOccurred = false;
      let oldRankTitle = prev.title;

      // Check if leveled up
      while (newCurrentXp >= newXpForNextLevel) {
        newCurrentXp -= newXpForNextLevel;
        newLevel += 1;
        newXpForNextLevel = Math.round(newXpForNextLevel * 1.15);
        rankUpOccurred = true;
      }

      // Check tier progression based on newLevel
      let newTier: GrowthRankTier = 'starter';
      if (newLevel >= 50) newTier = 'legend';
      else if (newLevel >= 39) newTier = 'master';
      else if (newLevel >= 29) newTier = 'influencer';
      else if (newLevel >= 19) newTier = 'pro';
      else if (newLevel >= 11) newTier = 'builder';
      else if (newLevel >= 6) newTier = 'rising';
      else newTier = 'starter';

      const tierConfig = RANK_TIERS[newTier];

      if (rankUpOccurred) {
        setRankUpEvent({
          oldRankTitle,
          newRankTitle: tierConfig.name,
          oldTier: prev.tier,
          newTier,
          newLevel,
          badgeEmoji: tierConfig.badgeEmoji,
          badgeName: tierConfig.badgeName,
          newPerks: tierConfig.unlockedPerks,
          xpGained: amount,
        });
      }

      return {
        ...prev,
        level: newLevel,
        tier: newTier,
        title: tierConfig.name,
        badgeEmoji: tierConfig.badgeEmoji,
        badgeName: tierConfig.badgeName,
        currentXp: newCurrentXp,
        xpForNextLevel: newXpForNextLevel,
        totalXp: newTotalXp,
        campaignCapacity: tierConfig.campaignCapacity,
        towerFloors: tierConfig.towerFloors,
        unlockedAutomations: tierConfig.unlockedPerks,
      };
    });
  };

  // Claim Achievement
  const claimAchievement = (achId: string) => {
    const ach = achievements.find((a) => a.id === achId);
    if (!ach || ach.isUnlocked) return;

    setAchievements((prev) =>
      prev.map((a) =>
        a.id === achId
          ? { ...a, isUnlocked: true, unlockedAt: new Date().toISOString().split('T')[0] }
          : a
      )
    );

    addXp(ach.xpReward);
  };

  // Trigger Follower Surge (+50)
  const triggerFollowerSurge = () => {
    // 1. Update Funnel
    setCampaigns((prev) =>
      prev.map((c, i) =>
        i === 0 && c.conversionFunnel
          ? {
              ...c,
              conversionFunnel: {
                ...c.conversionFunnel,
                followers: c.conversionFunnel.followers + 50,
                engaged: c.conversionFunnel.engaged + 35,
              },
            }
          : c
      )
    );

    // 2. Spawn Climbers
    const newNpcs: GrowthNpc[] = [
      {
        id: 'surge-' + Date.now() + '-1',
        name: 'Jordan Sparks',
        avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=80&auto=format&fit=crop&q=80',
        type: 'engaged',
        platform: 'twitter',
        x: Math.floor(Math.random() * 80) + 10,
        floor: 0,
        targetFloor: 2,
        climbProgress: 10,
        speed: 1.8,
        status: 'climbing',
        speechBubble: '🚀 Viral hook reposted to 45k followers!',
        bubbleExpiresAt: Date.now() + 9000,
        createdAt: Date.now(),
      },
      {
        id: 'surge-' + Date.now() + '-2',
        name: 'Maya Vance',
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=80&auto=format&fit=crop&q=80',
        type: 'follower',
        platform: 'linkedin',
        x: Math.floor(Math.random() * 80) + 10,
        floor: 0,
        targetFloor: 1,
        climbProgress: 15,
        speed: 1.5,
        status: 'climbing',
        speechBubble: 'Joined audience from carousel post!',
        bubbleExpiresAt: Date.now() + 9000,
        createdAt: Date.now(),
      },
    ];

    setTowerNpcs((prev) => [...newNpcs, ...prev.slice(0, 14)]);

    // 3. Set health status
    setGrowthRank((prev) => ({
      ...prev,
      growthHealth: 'surging',
      healthMessage: 'Growth surge active! 1,284 climbers sprinting upward.',
    }));

    addXp(120);

    // Reset back to healthy after 6s
    setTimeout(() => {
      setGrowthRank((prev) =>
        prev.growthHealth === 'surging'
          ? {
              ...prev,
              growthHealth: 'healthy',
              healthMessage: 'Growth velocity optimal across all channels.',
            }
          : prev
      );
    }, 6000);
  };

  // Trigger Lead Arrival
  const triggerLeadArrival = (name?: string, platform?: SocialPlatform) => {
    const leadName = name || 'Enterprise VP Growth';
    const leadPlatform = platform || 'linkedin';

    setCampaigns((prev) =>
      prev.map((c, i) =>
        i === 0 && c.conversionFunnel
          ? {
              ...c,
              conversionFunnel: {
                ...c.conversionFunnel,
                leads: c.conversionFunnel.leads + 1,
                interested: c.conversionFunnel.interested + 2,
              },
            }
          : c
      )
    );

    const leadNpc: GrowthNpc = {
      id: 'lead-npc-' + Date.now(),
      name: leadName,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&auto=format&fit=crop&q=80',
      type: 'qualified_lead',
      platform: leadPlatform,
      x: 70,
      floor: 4,
      targetFloor: 4,
      climbProgress: 100,
      speed: 1.0,
      status: 'conversing',
      speechBubble: `Lead score 95/100 • Requesting pricing deck! 🎯`,
      bubbleExpiresAt: Date.now() + 12000,
      badgeMarker: '🎯',
      createdAt: Date.now(),
    };

    setTowerNpcs((prev) => [leadNpc, ...prev.slice(0, 14)]);
    addXp(250);
  };

  // Trigger Customer / Signup Celebration
  const triggerSignupCelebration = (name?: string) => {
    const champName = name || 'Rachel Green (Series A Founder)';

    setCampaigns((prev) =>
      prev.map((c, i) =>
        i === 0 && c.conversionFunnel
          ? {
              ...c,
              conversionFunnel: {
                ...c.conversionFunnel,
                signups: c.conversionFunnel.signups + 1,
              },
            }
          : c
      )
    );

    const champNpc: GrowthNpc = {
      id: 'champ-' + Date.now(),
      name: champName,
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&auto=format&fit=crop&q=80',
      type: 'customer_signup',
      platform: 'linkedin',
      x: 50,
      floor: 5,
      targetFloor: 5,
      climbProgress: 100,
      speed: 1.2,
      status: 'celebrating',
      speechBubble: `Activated Annual Enterprise Plan! 👑🎉`,
      bubbleExpiresAt: Date.now() + 15000,
      badgeMarker: '⭐',
      createdAt: Date.now(),
    };

    setTowerNpcs((prev) => [champNpc, ...prev.slice(0, 14)]);
    addXp(400);
  };

  // Trigger Portal Visitor
  const triggerPortalVisitor = () => {
    setCampaigns((prev) =>
      prev.map((c, i) =>
        i === 0 && c.conversionFunnel
          ? {
              ...c,
              conversionFunnel: {
                ...c.conversionFunnel,
                websiteVisitors: c.conversionFunnel.websiteVisitors + 1,
              },
            }
          : c
      )
    );

    const visitorNpc: GrowthNpc = {
      id: 'vis-' + Date.now(),
      name: 'Kai Takahashi',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&auto=format&fit=crop&q=80',
      type: 'visitor',
      platform: 'twitter',
      x: 35,
      floor: 3,
      targetFloor: 3,
      climbProgress: 90,
      speed: 1.6,
      status: 'entering_portal',
      speechBubble: 'Teleporting to sandbox demo... 🌀',
      bubbleExpiresAt: Date.now() + 10000,
      badgeMarker: '🌐',
      createdAt: Date.now(),
    };

    setTowerNpcs((prev) => [visitorNpc, ...prev.slice(0, 14)]);
    addXp(75);
  };

  // Trigger Inbound Banter Bubble
  const triggerConversationBubble = (customText?: string) => {
    const quotes = [
      'Does this integrate with Salesforce & HubSpot? 💬',
      'Loved the post on autonomous inbound workflows! 🔥',
      'Checking out the live sandbox right now! 🌐',
      'Our team was struggling with 24hr SDR response times! ⚡',
      'Where can I view the enterprise pricing matrix? 🎯',
      'The brand moderation guardrails look super clean! 🛡️',
    ];
    const pickedQuote = customText || quotes[Math.floor(Math.random() * quotes.length)];

    setTowerNpcs((prev) => {
      if (prev.length === 0) return prev;
      const targetIndex = Math.floor(Math.random() * Math.min(prev.length, 5));
      return prev.map((n, idx) =>
        idx === targetIndex
          ? {
              ...n,
              speechBubble: pickedQuote,
              bubbleExpiresAt: Date.now() + 12000,
            }
          : n
      );
    });
  };

  // Simulate Growth Dip (Rank badge cracks/dims, NPCs stumble)
  const simulateGrowthDip = () => {
    // 1. Dim & crack rank badge
    setGrowthRank((prev) => ({
      ...prev,
      growthHealth: 'dipping',
      healthMessage: '⚠️ Growth Dip Detected: -15% engagement. NPCs stumbling. Auto-nurture engaging...',
    }));

    // 2. Set NPCs into stumbling/sliding state
    setTowerNpcs((prev) =>
      prev.map((n) => ({
        ...n,
        status: 'stumbling',
        speechBubble: 'Whoa! Growth dip slip! 💦',
        bubbleExpiresAt: Date.now() + 6000,
      }))
    );

    // 3. Auto-recover after 6 seconds with radiant golden heal!
    setTimeout(() => {
      setGrowthRank((prev) => ({
        ...prev,
        growthHealth: 'healthy',
        healthMessage: 'Resilience verified! Autonomous campaign auto-nurture stabilized growth velocity.',
      }));

      setTowerNpcs((prev) =>
        prev.map((n) => ({
          ...n,
          status: n.floor === 5 ? 'celebrating' : 'climbing',
          speechBubble: 'Back on track! Ascending again! 🚀',
          bubbleExpiresAt: Date.now() + 7000,
        }))
      );
    }, 6000);
  };

  // Modals
  const [isNewPostModalOpen, setIsNewPostModalOpen] = useState(false);
  const [isNewCampaignModalOpen, setIsNewCampaignModalOpen] = useState(false);
  const [isNewPersonaModalOpen, setIsNewPersonaModalOpen] = useState(false);
  const [isAutoReplyModalOpen, setIsAutoReplyModalOpen] = useState(false);
  const [selectedMessageForReply, setSelectedMessageForReply] = useState<SocialMessage | null>(null);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [selectedLeadForSchedule, setSelectedLeadForSchedule] = useState<Lead | null>(null);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [selectedLeadForEmail, setSelectedLeadForEmail] = useState<Lead | null>(null);
  const [isModerationDetailModalOpen, setIsModerationDetailModalOpen] = useState(false);
  const [selectedModerationReport, setSelectedModerationReport] = useState<ModerationReport | null>(null);

  // Persona Actions
  const addPersona = (p: CustomerPersona) => {
    setPersonas((prev) => [p, ...prev]);
    setActivePersona(p);
  };

  const updatePersona = (id: string, updates: Partial<CustomerPersona>) => {
    setPersonas((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
    if (activePersona?.id === id) {
      setActivePersona((prev) => (prev ? { ...prev, ...updates } : null));
    }
  };

  const deletePersona = (id: string) => {
    setPersonas((prev) => prev.filter((p) => p.id !== id));
    if (activePersona?.id === id) {
      setActivePersona(personas.find((p) => p.id !== id) || null);
    }
  };

  const generatePersona = async (params: {
    industry: string;
    targetRole: string;
    companySize?: string;
    productDescription?: string;
    tonePreference?: string;
  }) => {
    const newPersona = await generatePersonaApi(params);
    addPersona(newPersona);
    return newPersona;
  };

  // Sentiment Analysis on a single message
  const analyzeMessage = async (messageId: string) => {
    const msg = messages.find((m) => m.id === messageId);
    if (!msg) return null;

    const analysis = await analyzeSentimentApi({
      text: msg.content,
      authorName: msg.authorName,
      platform: msg.platform,
      context: `Post: ${msg.associatedPostTitle || 'General social thread'}`,
    });

    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, sentimentAnalysis: analysis } : m))
    );

    return analysis;
  };

  // Batch analyze all unanalyzed messages
  const batchAnalyzeSentiment = async () => {
    setIsBatchAnalyzing(true);
    try {
      const unanalyzed = messages.filter((m) => !m.sentimentAnalysis);
      for (const msg of unanalyzed) {
        await analyzeMessage(msg.id);
      }
    } finally {
      setIsBatchAnalyzing(false);
    }
  };

  // Reply to a message
  const replyToMessage = async (
    messageId: string,
    replyText: string,
    isAiGenerated: boolean = false
  ) => {
    // Run content moderation on the reply first!
    const modReport = await moderateContentApi({
      content: replyText,
    });

    const newReply = {
      id: 'rep-' + Date.now(),
      author: isAiGenerated ? 'You (AI Assistant)' : 'You',
      content: replyText,
      timestamp: 'Just now',
      isAiGenerated,
      moderationStatus: modReport.status,
    };

    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? {
              ...m,
              status: 'replied',
              replies: [...m.replies, newReply],
            }
          : m
      )
    );

    if (modReport.status !== 'passed') {
      setModerationReports((prev) => [modReport, ...prev]);
    }
  };

  // Convert a message into a qualified CRM lead
  const convertMessageToLead = (messageId: string): Lead => {
    const msg = messages.find((m) => m.id === messageId);
    const existing = leads.find((l) => l.name === msg?.authorName);
    if (existing) return existing;

    const sentiment = msg?.sentimentAnalysis?.sentiment || 'positive';
    const score = msg?.sentimentAnalysis?.sentimentScore || 0.8;

    const newLead: Lead = {
      id: 'lead-' + Date.now(),
      name: msg?.authorName || 'Inbound Prospect',
      email: `${msg?.authorHandle?.replace('@', '').toLowerCase() || 'prospect'}@example.com`,
      company: msg?.authorCompany || 'Independent / Exploring',
      role: msg?.authorRole || 'Decision Maker',
      sourcePlatform: msg?.platform || 'linkedin',
      status: 'new',
      leadScore: msg?.sentimentAnalysis?.leadQualificationScore || 80,
      sentimentTrend: [
        {
          date: new Date().toISOString().split('T')[0],
          sentiment,
          score,
          note: `Captured from social ${msg?.type || 'comment'}: "${msg?.content?.slice(0, 60)}..."`,
        },
      ],
      matchedPersonaId: activePersona?.id || 'persona-1',
      interactionCount: 1,
      estimatedValue: 15000,
      assignedTo: teamMembers[0]?.name || 'Sarah Jenkins',
      notes: `Captured from social message on ${msg?.platform}. Context: ${msg?.content}`,
      lastContacted: 'Just now',
    };

    setLeads((prev) => [newLead, ...prev]);
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? { ...m, status: 'converted_to_lead', leadId: newLead.id }
          : m
      )
    );

    return newLead;
  };

  // Moderation
  const updateBrandSafetyPolicy = (updates: Partial<BrandSafetyPolicy>) => {
    setBrandSafetyPolicy((prev) => ({ ...prev, ...updates }));
  };

  const moderateText = async (content: string, platform?: SocialPlatform) => {
    const report = await moderateContentApi({
      content,
      platform,
      brandRules: brandSafetyPolicy,
    });
    setModerationReports((prev) => [report, ...prev]);
    return report;
  };

  const applySanitizedFix = (reportId: string) => {
    setModerationReports((prev) =>
      prev.map((r) => (r.id === reportId ? { ...r, status: 'passed', appliedFix: true } : r))
    );
  };

  const approveReport = (reportId: string) => {
    setModerationReports((prev) =>
      prev.map((r) =>
        r.id === reportId
          ? { ...r, status: 'passed', reviewedBy: 'Safety Admin', reviewedAt: new Date().toISOString() }
          : r
      )
    );
  };

  const rejectReport = (reportId: string) => {
    setModerationReports((prev) =>
      prev.map((r) =>
        r.id === reportId
          ? { ...r, status: 'flagged', reviewedBy: 'Safety Admin', reviewedAt: new Date().toISOString() }
          : r
      )
    );
  };

  // Post Actions
  const addPost = (postData: Omit<SocialPost, 'id' | 'createdAt'>): SocialPost => {
    const newPost: SocialPost = {
      ...postData,
      id: 'post-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setPosts((prev) => [newPost, ...prev]);
    return newPost;
  };

  const updatePost = (id: string, updates: Partial<SocialPost>) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deletePost = (id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  // Campaign Actions
  const addCampaign = (campaignData: Omit<Campaign, 'id'>): Campaign => {
    const newCamp: Campaign = {
      ...campaignData,
      id: 'camp-' + Date.now(),
    };
    setCampaigns((prev) => [newCamp, ...prev]);
    return newCamp;
  };

  const updateCampaign = (id: string, updates: Partial<Campaign>) => {
    setCampaigns((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const deleteCampaign = (id: string) => {
    setCampaigns((prev) => prev.filter((c) => c.id !== id));
  };

  // Lead Actions
  const addLead = (leadData: Omit<Lead, 'id'>): Lead => {
    const newL: Lead = {
      ...leadData,
      id: 'lead-' + Date.now(),
    };
    setLeads((prev) => [newL, ...prev]);
    setActiveLead(newL);
    return newL;
  };

  const updateLeadStatus = (id: string, status: Lead['status']) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === id ? { ...l, status } : l))
    );
  };

  const updateLead = (id: string, updates: Partial<Lead>) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...updates } : l))
    );
  };

  // Calendar Follow-Ups
  const addFollowUp = (
    data: Omit<CalendarFollowUp, 'id'>
  ): CalendarFollowUp => {
    const newF: CalendarFollowUp = {
      ...data,
      id: 'fup-' + Date.now(),
    };
    setFollowUps((prev) => [newF, ...prev]);
    return newF;
  };

  const updateFollowUpStatus = (
    id: string,
    status: CalendarFollowUp['status']
  ) => {
    setFollowUps((prev) =>
      prev.map((f) => (f.id === id ? { ...f, status } : f))
    );
  };

  return (
    <AppContext.Provider
      value={{
        activeView,
        setActiveView,
        growthRank,
        achievements,
        towerNpcs,
        rankUpEvent,
        setRankUpEvent,
        isAchievementsDrawerOpen,
        setIsAchievementsDrawerOpen,
        addXp,
        claimAchievement,
        triggerFollowerSurge,
        triggerLeadArrival,
        triggerSignupCelebration,
        triggerPortalVisitor,
        triggerConversationBubble,
        simulateGrowthDip,
        personas,
        activePersona,
        setActivePersona,
        addPersona,
        updatePersona,
        deletePersona,
        generatePersona,
        messages,
        filterSentiment,
        setFilterSentiment,
        filterPlatform,
        setFilterPlatform,
        analyzeMessage,
        replyToMessage,
        convertMessageToLead,
        batchAnalyzeSentiment,
        isBatchAnalyzing,
        moderationReports,
        brandSafetyPolicy,
        updateBrandSafetyPolicy,
        moderateText,
        applySanitizedFix,
        approveReport,
        rejectReport,
        posts,
        addPost,
        updatePost,
        deletePost,
        campaigns,
        addCampaign,
        updateCampaign,
        deleteCampaign,
        leads,
        activeLead,
        setActiveLead,
        addLead,
        updateLeadStatus,
        updateLead,
        followUps,
        addFollowUp,
        updateFollowUpStatus,
        teamMembers,
        isNewPostModalOpen,
        setIsNewPostModalOpen,
        isNewCampaignModalOpen,
        setIsNewCampaignModalOpen,
        isNewPersonaModalOpen,
        setIsNewPersonaModalOpen,
        isAutoReplyModalOpen,
        setIsAutoReplyModalOpen,
        selectedMessageForReply,
        setSelectedMessageForReply,
        isScheduleModalOpen,
        setIsScheduleModalOpen,
        selectedLeadForSchedule,
        setSelectedLeadForSchedule,
        isEmailModalOpen,
        setIsEmailModalOpen,
        selectedLeadForEmail,
        setSelectedLeadForEmail,
        isModerationDetailModalOpen,
        setIsModerationDetailModalOpen,
        selectedModerationReport,
        setSelectedModerationReport,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
