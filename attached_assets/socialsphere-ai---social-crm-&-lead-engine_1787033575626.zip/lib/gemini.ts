import { GoogleGenAI } from '@google/genai';

// Initialize server-side Google Gen AI client with telemetry user-agent
export const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});
