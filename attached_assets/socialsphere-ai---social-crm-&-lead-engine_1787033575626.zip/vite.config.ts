import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, type Plugin } from 'vite';
import {
  handleSentimentAnalysis,
  handleGeneratePersona,
  handleTailorContent,
  handleModerateContent,
  handleGenerateCampaign,
  handleSimulateAutonomousConversation,
} from './src/server/geminiApiHandler';

function geminiApiPlugin(): Plugin {
  return {
    name: 'gemini-api-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/gemini/')) {
          return next();
        }

        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: 'Method not allowed' }));
          return;
        }

        let bodyRaw = '';
        req.on('data', (chunk) => {
          bodyRaw += chunk;
        });

        req.on('end', async () => {
          try {
            const body = bodyRaw ? JSON.parse(bodyRaw) : {};
            let result: any = null;

            if (req.url === '/api/gemini/sentiment-analysis') {
              result = await handleSentimentAnalysis(body);
            } else if (req.url === '/api/gemini/generate-persona') {
              result = await handleGeneratePersona(body);
            } else if (req.url === '/api/gemini/tailor-content') {
              result = await handleTailorContent(body);
            } else if (req.url === '/api/gemini/moderate-content') {
              result = await handleModerateContent(body);
            } else if (req.url === '/api/gemini/generate-campaign') {
              result = await handleGenerateCampaign(body);
            } else if (req.url === '/api/gemini/simulate-autonomous-conversation') {
              result = await handleSimulateAutonomousConversation(body);
            } else {
              res.statusCode = 404;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ error: 'Endpoint not found' }));
              return;
            }

            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(result));
          } catch (err: any) {
            console.error('Gemini API Handler Error:', err);
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ error: err.message || 'Internal server error' }));
          }
        });
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), geminiApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
